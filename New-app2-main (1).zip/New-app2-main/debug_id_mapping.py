#!/usr/bin/env python3
"""
Debug script to investigate the ID mapping issue in mechanic dashboard
"""
import requests
import json

BASE_URL = "https://fixmeapp.preview.emergentagent.com"
API_URL = f"{BASE_URL}/api"

def debug_id_mapping():
    print("🔍 DEBUGGING ID MAPPING ISSUE")
    print("=" * 50)
    
    # Step 1: Create a test mechanic
    print("\n1. Creating test mechanic...")
    mechanic_data = {
        "name": "Debug Test Mechanic",
        "email": "debugmechanic@test.com",
        "phone": "+234-808-DEBUG-01",
        "password": "DebugTest123",
        "role": "mechanic",
        "selected_tier": "basic",
        "city": "Lagos",
        "state": "Lagos"
    }
    
    response = requests.post(f"{API_URL}/auth/register", json=mechanic_data)
    if response.status_code != 200:
        print(f"❌ Failed to create mechanic: {response.status_code}")
        return
    
    reg_data = response.json()
    user_id = reg_data['user']['id']
    print(f"✅ Mechanic created with user_id: {user_id}")
    
    # Step 2: Get mechanic profile to find profile_id
    print("\n2. Getting mechanic profile...")
    response = requests.get(f"{API_URL}/mechanics/{user_id}/profile")
    if response.status_code != 200:
        print(f"❌ Failed to get profile: {response.status_code}")
        return
    
    profile_data = response.json()
    profile_id = profile_data['profile']['id']
    print(f"✅ Mechanic profile_id: {profile_id}")
    print(f"✅ ID Mapping: user_id={user_id} → profile_id={profile_id}")
    
    # Step 3: Create a service request
    print("\n3. Creating service request...")
    request_data = {
        "customer_name": "Debug Test Customer",
        "customer_phone": "+234-801-DEBUG-02",
        "customer_address": "Debug Test Address, Lagos",
        "service_type": "Engine Repair",
        "description": "Debug test for ID mapping issue",
        "location": {
            "address": "Debug Test Address, Lagos",
            "latitude": 6.5244,
            "longitude": 3.3792,
            "state": "Lagos",
            "lga": "Lagos Island"
        }
    }
    
    response = requests.post(f"{API_URL}/service-requests", json=request_data)
    if response.status_code != 200:
        print(f"❌ Failed to create request: {response.status_code}")
        return
    
    req_data = response.json()
    request_id = req_data['request']['id']
    print(f"✅ Service request created with ID: {request_id}")
    
    # Step 4: Assign request using profile_id (current behavior)
    print("\n4. Assigning request using profile_id...")
    assignment_data = {"mechanic_id": profile_id}
    
    response = requests.put(f"{API_URL}/service-requests/{request_id}/assign-mechanic", json=assignment_data)
    if response.status_code != 200:
        print(f"❌ Failed to assign request: {response.status_code}")
        print(f"Response: {response.text}")
        return
    
    assign_data = response.json()
    print(f"✅ Request assigned successfully")
    print(f"   Assigned mechanic_id (stored in DB): {assign_data.get('mechanic_id')}")
    
    # Step 5: Check what's stored in the database
    print("\n5. Checking service request in database...")
    response = requests.get(f"{API_URL}/service-requests/all")
    if response.status_code != 200:
        print(f"❌ Failed to get all requests: {response.status_code}")
        return
    
    all_requests = response.json()['requests']
    assigned_request = None
    for req in all_requests:
        if req.get('id') == request_id:
            assigned_request = req
            break
    
    if assigned_request:
        stored_mechanic_id = assigned_request.get('mechanic_id')
        print(f"✅ Request found in database")
        print(f"   Stored mechanic_id: {stored_mechanic_id}")
        print(f"   Request status: {assigned_request.get('status')}")
    else:
        print(f"❌ Request not found in database")
        return
    
    # Step 6: Try to get mechanic requests using user_id
    print("\n6. Getting mechanic requests using user_id...")
    response = requests.get(f"{API_URL}/mechanics/{user_id}/requests")
    if response.status_code != 200:
        print(f"❌ Failed to get mechanic requests: {response.status_code}")
        return
    
    mechanic_requests = response.json()['requests']
    print(f"✅ Mechanic requests endpoint returned {len(mechanic_requests)} requests")
    
    # Check if our assigned request is in the list
    found_request = None
    for req in mechanic_requests:
        if req.get('id') == request_id:
            found_request = req
            break
    
    if found_request:
        print(f"✅ ASSIGNED REQUEST FOUND in mechanic dashboard!")
        print(f"   Request ID: {found_request.get('id')}")
        print(f"   Status: {found_request.get('status')}")
    else:
        print(f"❌ ASSIGNED REQUEST NOT FOUND in mechanic dashboard")
        print(f"   This confirms the ID mapping bug!")
    
    # Step 7: Debug the ID mapping logic
    print("\n7. Debugging ID mapping logic...")
    print(f"   user_id: {user_id}")
    print(f"   profile_id: {profile_id}")
    print(f"   stored_mechanic_id in request: {stored_mechanic_id}")
    print(f"   Are they equal? {profile_id == stored_mechanic_id}")
    
    # The mechanic requests endpoint should find requests where mechanic_id == profile_id
    # Let's verify this logic
    if profile_id == stored_mechanic_id:
        print(f"✅ ID mapping should work - profile_id matches stored mechanic_id")
        print(f"❌ But request not found - there might be another issue")
    else:
        print(f"❌ ID mapping broken - profile_id != stored mechanic_id")
    
    print("\n" + "=" * 50)
    print("🔍 DEBUG SUMMARY:")
    print(f"   User ID: {user_id}")
    print(f"   Profile ID: {profile_id}")
    print(f"   Stored Mechanic ID: {stored_mechanic_id}")
    print(f"   Requests found in dashboard: {len(mechanic_requests)}")
    print(f"   Expected request found: {'YES' if found_request else 'NO'}")

if __name__ == "__main__":
    debug_id_mapping()