#!/usr/bin/env python3
"""
Reproduce the exact bug scenario from the review request:
CRITICAL BUG REPRODUCTION - Mechanic Dashboard Crash After Admin Assignment

TESTING WORKFLOW TO REPRODUCE BUG:
1. Admin Assignment Test: Get current service requests, find unassigned request and assign it to mechanic af7f09d3-36d5-4023-99cd-f90ac7c7f49f
2. Mechanic Dashboard API Test After Assignment: Test all mechanic dashboard APIs
3. Data Format Validation: Verify data structure and formatting
4. Status Update Test: Test status progression
"""
import requests
import json

BASE_URL = "https://fixmeapp.preview.emergentagent.com"
API_URL = f"{BASE_URL}/api"

def reproduce_exact_bug():
    print("🚨 CRITICAL BUG REPRODUCTION - Mechanic Dashboard Crash After Admin Assignment")
    print("🎯 URGENT ISSUE: Mechanic dashboard crashes after admin assigns a request to them")
    print("=" * 80)
    
    target_mechanic_id = "af7f09d3-36d5-4023-99cd-f90ac7c7f49f"
    
    # Step 1: Admin Assignment Test - Get current service requests
    print("\n1️⃣ ADMIN ASSIGNMENT TEST")
    print("-" * 40)
    
    print("Getting current service requests from /api/service-requests/all...")
    response = requests.get(f"{API_URL}/service-requests/all")
    if response.status_code != 200:
        print(f"❌ Failed to get service requests: {response.status_code}")
        return False
    
    all_requests = response.json()['requests']
    print(f"✅ Found {len(all_requests)} total service requests")
    
    # Find unassigned request
    unassigned_requests = [req for req in all_requests if not req.get('mechanic_id') or req.get('status') == 'pending']
    if not unassigned_requests:
        print("No unassigned requests found. Creating one for testing...")
        # Create a new unassigned request
        request_data = {
            "customer_name": "Bug Reproduction Customer",
            "customer_phone": "+234-801-BUG-REPRO",
            "customer_address": "Bug Reproduction Address, Lagos State",
            "service_type": "Engine Repair",
            "description": "CRITICAL BUG REPRODUCTION: Mechanic dashboard crash after admin assignment",
            "location": {
                "address": "Bug Reproduction Address, Lagos State",
                "latitude": 6.5244,
                "longitude": 3.3792,
                "state": "Lagos",
                "lga": "Lagos Island"
            }
        }
        
        response = requests.post(f"{API_URL}/service-requests", json=request_data)
        if response.status_code != 200:
            print(f"❌ Failed to create test request: {response.status_code}")
            return False
        
        test_request = response.json()['request']
        print(f"✅ Created test request: {test_request['id']}")
    else:
        test_request = unassigned_requests[0]
        print(f"✅ Found unassigned request: {test_request['id']}")
    
    request_id = test_request['id']
    
    # Check if target mechanic exists
    print(f"\nChecking if target mechanic {target_mechanic_id} exists...")
    
    # First, let's check if this is a user_id or profile_id by trying to get the profile
    response = requests.get(f"{API_URL}/mechanics/{target_mechanic_id}/profile")
    if response.status_code == 200:
        print(f"✅ Target mechanic exists as user_id: {target_mechanic_id}")
        # Get the profile_id for assignment
        profile_data = response.json()
        profile_id = profile_data['profile']['id']
        print(f"✅ Mechanic profile_id: {profile_id}")
        mechanic_user_id = target_mechanic_id
        mechanic_profile_id = profile_id
    else:
        # Maybe it's a profile_id, let's search for it
        print(f"Target mechanic not found as user_id. Searching in mechanic profiles...")
        response = requests.get(f"{API_URL}/mechanics/search?latitude=6.5244&longitude=3.3792&radius=10000")
        if response.status_code != 200:
            print(f"❌ Failed to search mechanics: {response.status_code}")
            return False
        
        mechanics = response.json()['mechanics']
        target_mechanic = None
        for mechanic in mechanics:
            if mechanic.get('id') == target_mechanic_id:
                target_mechanic = mechanic
                break
        
        if target_mechanic:
            print(f"✅ Found target mechanic as profile_id: {target_mechanic_id}")
            mechanic_profile_id = target_mechanic_id
            mechanic_user_id = target_mechanic.get('user_id', 'unknown')
            print(f"✅ Mechanic user_id: {mechanic_user_id}")
        else:
            print(f"❌ Target mechanic {target_mechanic_id} not found anywhere")
            print("Using first available mechanic instead...")
            if mechanics:
                target_mechanic = mechanics[0]
                mechanic_profile_id = target_mechanic['id']
                mechanic_user_id = target_mechanic.get('user_id', 'unknown')
                print(f"✅ Using mechanic: {mechanic_profile_id} (user_id: {mechanic_user_id})")
            else:
                print("❌ No mechanics available for testing")
                return False
    
    # Assign request to mechanic using profile_id
    print(f"\nAssigning request {request_id} to mechanic {mechanic_profile_id}...")
    assignment_data = {"mechanic_id": mechanic_profile_id}
    
    response = requests.put(f"{API_URL}/service-requests/{request_id}/assign-mechanic", json=assignment_data)
    if response.status_code != 200:
        print(f"❌ Failed to assign request: {response.status_code}")
        print(f"Response: {response.text}")
        return False
    
    assign_data = response.json()
    print(f"✅ Assignment successful!")
    print(f"   Request ID: {request_id}")
    print(f"   Mechanic Profile ID: {mechanic_profile_id}")
    print(f"   Mechanic User ID: {mechanic_user_id}")
    print(f"   Mechanic Name: {assign_data.get('mechanic_name', 'Unknown')}")
    
    # Verify assignment was successful
    response = requests.get(f"{API_URL}/service-requests/all")
    if response.status_code == 200:
        all_requests = response.json()['requests']
        assigned_request = None
        for req in all_requests:
            if req.get('id') == request_id:
                assigned_request = req
                break
        
        if assigned_request:
            print(f"✅ Assignment verified in database")
            print(f"   Status: {assigned_request.get('status')}")
            print(f"   Assigned mechanic_id: {assigned_request.get('mechanic_id')}")
        else:
            print(f"❌ Assignment verification failed - request not found")
    
    # Step 2: Mechanic Dashboard API Test After Assignment
    print(f"\n2️⃣ MECHANIC DASHBOARD API TEST AFTER ASSIGNMENT")
    print("-" * 50)
    
    # Test GET /api/mechanics/{user_id}/requests
    print(f"Testing GET /api/mechanics/{mechanic_user_id}/requests...")
    response = requests.get(f"{API_URL}/mechanics/{mechanic_user_id}/requests")
    if response.status_code != 200:
        print(f"❌ CRITICAL BUG CONFIRMED: Mechanic requests endpoint failing")
        print(f"   Status Code: {response.status_code}")
        print(f"   Response: {response.text}")
        return False
    
    mechanic_requests = response.json()['requests']
    assigned_request_found = None
    for req in mechanic_requests:
        if req.get('id') == request_id:
            assigned_request_found = req
            break
    
    if not assigned_request_found:
        print(f"❌ CRITICAL BUG CONFIRMED: Assigned request NOT found in mechanic dashboard")
        print(f"   Expected request ID: {request_id}")
        print(f"   Mechanic requests found: {len(mechanic_requests)}")
        print(f"   Request IDs in dashboard: {[req.get('id') for req in mechanic_requests]}")
        return False
    
    print(f"✅ Assigned request found in mechanic dashboard")
    print(f"   Request ID: {assigned_request_found.get('id')}")
    print(f"   Status: {assigned_request_found.get('status')}")
    print(f"   Customer: {assigned_request_found.get('customer_name')}")
    
    # Test GET /api/mechanics/{user_id}/profile
    print(f"\nTesting GET /api/mechanics/{mechanic_user_id}/profile...")
    response = requests.get(f"{API_URL}/mechanics/{mechanic_user_id}/profile")
    if response.status_code != 200:
        print(f"❌ CRITICAL BUG: Mechanic profile endpoint failing")
        print(f"   Status Code: {response.status_code}")
        print(f"   Response: {response.text}")
        return False
    
    profile_data = response.json()['profile']
    print(f"✅ Mechanic profile endpoint working")
    print(f"   Business Name: {profile_data.get('business_name')}")
    print(f"   Tier: {profile_data.get('tier')}")
    
    # Test GET /api/mechanics/{user_id}/stats
    print(f"\nTesting GET /api/mechanics/{mechanic_user_id}/stats...")
    response = requests.get(f"{API_URL}/mechanics/{mechanic_user_id}/stats")
    if response.status_code != 200:
        print(f"❌ CRITICAL BUG: Mechanic stats endpoint failing")
        print(f"   Status Code: {response.status_code}")
        print(f"   Response: {response.text}")
        return False
    
    stats_data = response.json()['stats']
    print(f"✅ Mechanic stats endpoint working")
    print(f"   Total Requests: {stats_data.get('total_requests')}")
    print(f"   Monthly Limit: {stats_data.get('monthly_limit')}")
    print(f"   Tier: {stats_data.get('tier')}")
    
    # Step 3: Data Format Validation
    print(f"\n3️⃣ DATA FORMAT VALIDATION")
    print("-" * 30)
    
    # Verify assigned request data structure
    required_fields = ['id', 'status', 'customer_name', 'customer_phone', 'customer_address', 'service_type', 'description']
    missing_fields = []
    null_fields = []
    
    for field in required_fields:
        if field not in assigned_request_found:
            missing_fields.append(field)
        elif assigned_request_found[field] is None:
            null_fields.append(field)
    
    if missing_fields:
        print(f"❌ CRITICAL DATA ISSUE: Missing required fields: {missing_fields}")
        return False
    
    if null_fields:
        print(f"❌ CRITICAL DATA ISSUE: Null values in required fields: {null_fields}")
        return False
    
    print(f"✅ All required fields present and non-null")
    
    # Verify date formatting
    date_fields = ['created_at', 'updated_at']
    for field in date_fields:
        if field in assigned_request_found:
            date_value = assigned_request_found[field]
            if date_value and not isinstance(date_value, str):
                print(f"❌ CRITICAL DATA ISSUE: {field} is not a string: {type(date_value)}")
                return False
            print(f"✅ {field} properly formatted: {date_value}")
    
    # Step 4: Status Update Test
    print(f"\n4️⃣ STATUS UPDATE TEST")
    print("-" * 25)
    
    status_flow = ['accepted', 'in_progress', 'completed']
    
    for status in status_flow:
        print(f"Updating status to {status}...")
        response = requests.put(f"{API_URL}/mechanics/requests/{request_id}/status", json={"status": status})
        if response.status_code != 200:
            print(f"❌ CRITICAL BUG: Cannot update status to {status} after assignment")
            print(f"   Status Code: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
        
        print(f"✅ Status update to {status} successful")
    
    # Final Summary
    print(f"\n🎉 BUG REPRODUCTION TEST RESULTS")
    print("=" * 40)
    print(f"✅ Admin assignment: WORKING")
    print(f"✅ Mechanic dashboard APIs after assignment: WORKING")
    print(f"✅ Data format validation: PASSED")
    print(f"✅ Status updates after assignment: WORKING")
    print(f"✅ Request ID: {request_id}")
    print(f"✅ Mechanic User ID: {mechanic_user_id}")
    print(f"✅ Mechanic Profile ID: {mechanic_profile_id}")
    
    print(f"\n🚨 CONCLUSION: MECHANIC DASHBOARD CRASH BUG NOT REPRODUCED")
    print(f"   The mechanic dashboard APIs are working correctly after admin assignment.")
    print(f"   The backend is functioning properly. If the frontend is crashing,")
    print(f"   the issue is likely in the frontend code, not the backend API responses.")
    
    return True

if __name__ == "__main__":
    success = reproduce_exact_bug()
    if success:
        print(f"\n✅ Bug reproduction test completed successfully")
    else:
        print(f"\n❌ Bug reproduction test failed")