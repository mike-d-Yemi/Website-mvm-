import requests
import sys
import json
from datetime import datetime

class CompleteUserJourneyTester:
    def __init__(self, base_url="https://fixmeapp.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.tests_run = 0
        self.tests_passed = 0
        self.customer_token = None
        self.mechanic_token = None
        self.mechanic_id = None
        self.customer_id = None

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=15)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=15)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    return True, response_data
                except:
                    return True, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {json.dumps(error_data, indent=2)}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_customer_registration_mary(self):
        """Test customer registration for Mary Okonkwo"""
        timestamp = datetime.now().strftime('%H%M%S')
        test_data = {
            "name": "Mary Okonkwo",
            "email": f"mary.okonkwo{timestamp}@gmail.com",
            "phone": "+234-801-123-4567",
            "password": "TestCustomer123",
            "role": "customer"
        }
        
        success, response = self.run_test(
            "Customer Registration (Mary Okonkwo)",
            "POST",
            "/auth/register",
            200,
            data=test_data
        )
        
        if success and 'token' in response:
            self.customer_token = response['token']
            self.customer_id = response['user']['id']
            print(f"   ✅ Mary Okonkwo registered successfully")
            print(f"   ✅ Customer ID: {self.customer_id}")
            return True
        return False

    def test_customer_login_mary(self):
        """Test customer login for Mary Okonkwo"""
        timestamp = datetime.now().strftime('%H%M%S')
        test_data = {
            "email": f"mary.okonkwo{timestamp}@gmail.com",
            "password": "TestCustomer123"
        }
        
        success, response = self.run_test(
            "Customer Login (Mary Okonkwo)",
            "POST",
            "/auth/login",
            200,
            data=test_data
        )
        
        if success and 'token' in response:
            print(f"   ✅ Mary Okonkwo logged in successfully")
            return True
        return False

    def test_mechanic_registration_lagos_pro(self):
        """Test mechanic registration for Lagos Pro Motors"""
        timestamp = datetime.now().strftime('%H%M%S')
        test_data = {
            "name": "Lagos Pro Motors",
            "email": f"lagospro{timestamp}@gmail.com",
            "phone": "+234-808-765-4321",
            "password": "MechanicTest456",
            "role": "mechanic"
        }
        
        success, response = self.run_test(
            "Mechanic Registration (Lagos Pro Motors)",
            "POST",
            "/auth/register",
            200,
            data=test_data
        )
        
        if success and 'token' in response:
            self.mechanic_token = response['token']
            self.mechanic_id = response['user']['id']
            print(f"   ✅ Lagos Pro Motors registered successfully")
            print(f"   ✅ Mechanic ID: {self.mechanic_id}")
            return True
        return False

    def test_mechanic_profile_creation(self):
        """Test creating mechanic profile"""
        if not self.mechanic_id:
            print("   ❌ No mechanic ID available")
            return False
            
        test_data = {
            "business_name": "Lagos Pro Motors",
            "description": "Professional automotive repair services in Lagos",
            "location": {
                "address": "Victoria Island, Lagos, Nigeria",
                "latitude": 6.4281,
                "longitude": 3.4219,
                "state": "Lagos",
                "lga": "Lagos Island"
            },
            "services": ["Engine Repair", "Brake Service", "Oil Change", "Tire Service"],
            "contact_info": {
                "phone": "+234-808-765-4321",
                "whatsapp": "+234-808-765-4321",
                "email": "lagospro@gmail.com"
            },
            "years_experience": 10,
            "certifications": ["ASE Certified", "Toyota Certified"],
            "working_hours": {
                "monday": "8:00-18:00",
                "tuesday": "8:00-18:00",
                "wednesday": "8:00-18:00",
                "thursday": "8:00-18:00",
                "friday": "8:00-18:00",
                "saturday": "9:00-16:00"
            }
        }
        
        success, response = self.run_test(
            "Mechanic Profile Creation",
            "POST",
            f"/mechanics/profile?user_id={self.mechanic_id}",
            200,
            data=test_data
        )
        
        if success:
            print(f"   ✅ Mechanic profile created successfully")
            return True
        return False

    def test_mechanic_search_lagos(self):
        """Test searching for mechanics in Lagos"""
        params = "?latitude=6.5244&longitude=3.3792&radius=50"
        success, response = self.run_test(
            "Mechanic Search (Lagos)",
            "GET",
            f"/mechanics/search{params}",
            200
        )
        
        if success and 'mechanics' in response:
            mechanics = response['mechanics']
            print(f"   ✅ Found {len(mechanics)} mechanics in Lagos")
            
            # Check if our registered mechanic appears
            for mechanic in mechanics:
                if mechanic.get('business_name') == 'Lagos Pro Motors':
                    print(f"   ✅ Lagos Pro Motors found in search results")
                    print(f"   ✅ Tier: {mechanic.get('tier', 'N/A')}")
                    print(f"   ✅ Distance: {mechanic.get('distance', 'N/A')} km")
                    break
            return True
        return False

    def test_service_request_creation(self):
        """Test creating a service request"""
        if not self.mechanic_id:
            print("   ❌ No mechanic ID available")
            return False
            
        test_data = {
            "mechanic_id": self.mechanic_id,
            "service_type": "Engine Repair",
            "description": "My car engine is making strange noises and needs inspection",
            "location": {
                "address": "Ikoyi, Lagos",
                "latitude": 6.4541,
                "longitude": 3.4316,
                "state": "Lagos",
                "lga": "Lagos Island"
            }
        }
        
        success, response = self.run_test(
            "Service Request Creation",
            "POST",
            "/service-requests",
            200,
            data=test_data
        )
        
        if success:
            print(f"   ✅ Service request created successfully")
            return True
        return False

    def test_tier_pricing(self):
        """Test tier pricing endpoint"""
        success, response = self.run_test(
            "Tier Pricing",
            "GET",
            "/payments/tiers",
            200
        )
        
        if success and 'tiers' in response:
            tiers = response['tiers']
            print(f"   ✅ Found {len(tiers)} pricing tiers")
            for tier in tiers:
                print(f"   ✅ {tier['name']}: ₦{tier['price']}/year")
            return True
        return False

    def test_payment_initialization_premium(self):
        """Test payment initialization for Premium tier"""
        if not self.mechanic_id:
            print("   ❌ No mechanic ID available")
            return False
            
        test_data = {
            "tier": "premium",
            "mechanic_id": self.mechanic_id
        }
        
        success, response = self.run_test(
            "Payment Initialization (Premium)",
            "POST",
            "/payments/initialize",
            200,
            data=test_data
        )
        
        if success and 'authorization_url' in response:
            print(f"   ✅ Paystack URL generated successfully")
            print(f"   ✅ Amount: ₦{response.get('amount', 'N/A')}")
            print(f"   ✅ Reference: {response.get('reference', 'N/A')}")
            print(f"   ✅ URL: {response['authorization_url'][:80]}...")
            return True
        return False

    def test_payment_initialization_pro(self):
        """Test payment initialization for Pro tier"""
        if not self.mechanic_id:
            print("   ❌ No mechanic ID available")
            return False
            
        test_data = {
            "tier": "pro",
            "mechanic_id": self.mechanic_id
        }
        
        success, response = self.run_test(
            "Payment Initialization (Pro)",
            "POST",
            "/payments/initialize",
            200,
            data=test_data
        )
        
        if success and 'authorization_url' in response:
            print(f"   ✅ Paystack URL generated successfully")
            print(f"   ✅ Amount: ₦{response.get('amount', 'N/A')}")
            print(f"   ✅ Reference: {response.get('reference', 'N/A')}")
            return True
        return False

def main():
    print("🚀 Starting Complete User Journey Tests")
    print("Testing the full Nigerian Mechanic Finder App workflow")
    print("=" * 70)
    
    tester = CompleteUserJourneyTester()
    
    # Complete user journey test sequence
    tests = [
        ("1. Customer Registration (Mary)", tester.test_customer_registration_mary),
        ("2. Mechanic Registration (Lagos Pro)", tester.test_mechanic_registration_lagos_pro),
        ("3. Mechanic Profile Creation", tester.test_mechanic_profile_creation),
        ("4. Mechanic Search (Lagos)", tester.test_mechanic_search_lagos),
        ("5. Service Request Creation", tester.test_service_request_creation),
        ("6. Tier Pricing", tester.test_tier_pricing),
        ("7. Payment Init (Premium)", tester.test_payment_initialization_premium),
        ("8. Payment Init (Pro)", tester.test_payment_initialization_pro),
    ]
    
    # Run all tests in sequence
    for test_name, test_func in tests:
        try:
            result = test_func()
            if not result:
                print(f"   ⚠️  {test_name} failed - continuing with next test")
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {str(e)}")
    
    # Print final results
    print("\n" + "=" * 70)
    print(f"📊 COMPLETE USER JOURNEY TEST RESULTS")
    print(f"Tests Run: {tester.tests_run}")
    print(f"Tests Passed: {tester.tests_passed}")
    print(f"Tests Failed: {tester.tests_run - tester.tests_passed}")
    print(f"Success Rate: {(tester.tests_passed/tester.tests_run)*100:.1f}%")
    
    if tester.tests_passed >= 6:  # At least 75% success rate
        print("🎉 User journey tests mostly successful!")
        print("✅ Backend APIs are working correctly")
        print("✅ Payment system is functional with real Paystack keys")
        return 0
    else:
        print("⚠️  Some critical user journey tests failed.")
        return 1

if __name__ == "__main__":
    sys.exit(main())