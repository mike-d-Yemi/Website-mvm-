import requests
import sys
import json
from datetime import datetime

class AuthenticationFlowTester:
    def __init__(self, base_url="https://fixmeapp.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.tests_run = 0
        self.tests_passed = 0
        self.customer_token = None
        self.mechanic_token = None
        self.customer_data = None
        self.mechanic_data = None

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=10)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    return True, response_data
                except:
                    return True, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {json.dumps(error_data, indent=2)}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_customer_registration(self):
        """Test customer registration with exact test data"""
        test_data = {
            "name": "John Adebayo",
            "email": "john.adebayo@gmail.com",
            "phone": "+234-801-123-4567",
            "password": "TestPassword123",
            "role": "customer"
        }
        
        success, response = self.run_test(
            "Customer Registration",
            "POST",
            "/auth/register",
            200,
            data=test_data
        )
        
        if success and 'token' in response and 'user' in response:
            self.customer_token = response['token']
            self.customer_data = response['user']
            print(f"   ✅ Customer registered successfully")
            print(f"   ✅ User ID: {self.customer_data.get('id')}")
            print(f"   ✅ Role: {self.customer_data.get('role')}")
            return True
        return False

    def test_mechanic_registration(self):
        """Test mechanic registration with exact test data"""
        test_data = {
            "name": "Ahmed Garage Services",
            "email": "ahmed.garage@gmail.com",
            "phone": "+234-802-987-6543",
            "password": "MechanicPass456",
            "role": "mechanic"
        }
        
        success, response = self.run_test(
            "Mechanic Registration",
            "POST",
            "/auth/register",
            200,
            data=test_data
        )
        
        if success and 'token' in response and 'user' in response:
            self.mechanic_token = response['token']
            self.mechanic_data = response['user']
            print(f"   ✅ Mechanic registered successfully")
            print(f"   ✅ User ID: {self.mechanic_data.get('id')}")
            print(f"   ✅ Role: {self.mechanic_data.get('role')}")
            return True
        return False

    def test_customer_login(self):
        """Test customer login with registered credentials"""
        test_data = {
            "email": "john.adebayo@gmail.com",
            "password": "TestPassword123"
        }
        
        success, response = self.run_test(
            "Customer Login",
            "POST",
            "/auth/login",
            200,
            data=test_data
        )
        
        if success and 'token' in response and 'user' in response:
            print(f"   ✅ Customer login successful")
            print(f"   ✅ Role: {response['user'].get('role')}")
            return True
        return False

    def test_mechanic_login(self):
        """Test mechanic login with registered credentials"""
        test_data = {
            "email": "ahmed.garage@gmail.com",
            "password": "MechanicPass456"
        }
        
        success, response = self.run_test(
            "Mechanic Login",
            "POST",
            "/auth/login",
            200,
            data=test_data
        )
        
        if success and 'token' in response and 'user' in response:
            print(f"   ✅ Mechanic login successful")
            print(f"   ✅ Role: {response['user'].get('role')}")
            return True
        return False

    def test_invalid_login_attempts(self):
        """Test invalid login attempts"""
        # Test with wrong password
        test_data1 = {
            "email": "john.adebayo@gmail.com",
            "password": "WrongPassword"
        }
        
        success1, _ = self.run_test(
            "Invalid Login (Wrong Password)",
            "POST",
            "/auth/login",
            401,
            data=test_data1
        )
        
        # Test with non-existent email
        test_data2 = {
            "email": "nonexistent@gmail.com",
            "password": "TestPassword123"
        }
        
        success2, _ = self.run_test(
            "Invalid Login (Non-existent Email)",
            "POST",
            "/auth/login",
            401,
            data=test_data2
        )
        
        return success1 and success2

    def test_duplicate_registration(self):
        """Test duplicate registration attempts"""
        # Try to register customer again
        test_data = {
            "name": "John Adebayo",
            "email": "john.adebayo@gmail.com",
            "phone": "+234-801-123-4567",
            "password": "TestPassword123",
            "role": "customer"
        }
        
        success, response = self.run_test(
            "Duplicate Customer Registration",
            "POST",
            "/auth/register",
            400,
            data=test_data
        )
        
        if success and response.get('detail') == 'Email already registered':
            print(f"   ✅ Duplicate registration properly rejected")
            return True
        return False

    def test_jwt_token_validation(self):
        """Test JWT token structure and validation"""
        if not self.customer_token:
            print("❌ No customer token available for validation")
            return False
            
        try:
            # Basic JWT structure validation (3 parts separated by dots)
            parts = self.customer_token.split('.')
            if len(parts) != 3:
                print("❌ Invalid JWT structure")
                return False
                
            # Try to decode payload (without verification for testing)
            import base64
            import json
            
            # Add padding if needed
            payload = parts[1]
            payload += '=' * (4 - len(payload) % 4)
            
            decoded_payload = json.loads(base64.b64decode(payload))
            
            print(f"   ✅ JWT token structure valid")
            print(f"   ✅ Token contains user_id: {decoded_payload.get('user_id')}")
            print(f"   ✅ Token contains email: {decoded_payload.get('email')}")
            print(f"   ✅ Token contains role: {decoded_payload.get('role')}")
            
            return True
            
        except Exception as e:
            print(f"❌ JWT validation failed: {str(e)}")
            return False

def main():
    print("🚀 Starting Authentication Flow Tests")
    print("Testing with specific user data as requested")
    print("=" * 60)
    
    tester = AuthenticationFlowTester()
    
    # Test sequence
    tests = [
        ("Customer Registration", tester.test_customer_registration),
        ("Mechanic Registration", tester.test_mechanic_registration),
        ("Customer Login", tester.test_customer_login),
        ("Mechanic Login", tester.test_mechanic_login),
        ("Invalid Login Attempts", tester.test_invalid_login_attempts),
        ("Duplicate Registration", tester.test_duplicate_registration),
        ("JWT Token Validation", tester.test_jwt_token_validation),
    ]
    
    # Run all tests
    for test_name, test_func in tests:
        try:
            test_func()
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {str(e)}")
    
    # Print final results
    print("\n" + "=" * 60)
    print(f"📊 AUTHENTICATION FLOW TEST RESULTS")
    print(f"Tests Run: {tester.tests_run}")
    print(f"Tests Passed: {tester.tests_passed}")
    print(f"Tests Failed: {tester.tests_run - tester.tests_passed}")
    print(f"Success Rate: {(tester.tests_passed/tester.tests_run)*100:.1f}%")
    
    # Print user data summary
    if tester.customer_data:
        print(f"\n👤 CUSTOMER DATA:")
        print(f"   Name: {tester.customer_data.get('name')}")
        print(f"   Email: {tester.customer_data.get('email')}")
        print(f"   Role: {tester.customer_data.get('role')}")
        print(f"   ID: {tester.customer_data.get('id')}")
    
    if tester.mechanic_data:
        print(f"\n🔧 MECHANIC DATA:")
        print(f"   Name: {tester.mechanic_data.get('name')}")
        print(f"   Email: {tester.mechanic_data.get('email')}")
        print(f"   Role: {tester.mechanic_data.get('role')}")
        print(f"   ID: {tester.mechanic_data.get('id')}")
    
    if tester.tests_passed == tester.tests_run:
        print("\n🎉 All authentication tests passed!")
        return 0
    else:
        print("\n⚠️  Some authentication tests failed. Check the details above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())