import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { 
  Wrench, DollarSign, FileText, Clock, CheckCircle, AlertCircle,
  TrendingUp, Users, Calendar, Star, Shield, MapPin, Phone,
  RefreshCw, Eye, Settings, LogOut, MessageCircle
} from 'lucide-react';

const MechanicDashboard = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [dashboardData, setDashboardData] = useState({
    requests: [],
    stats: {
      total_requests: 0,
      accepted_requests: 0,
      completed_requests: 0,
      pending_requests: 0,
      total_revenue: 0,
      this_month_requests: 0,
      monthly_limit: 50,
      tier: 'basic'
    },
    profile: {
      business_name: 'Your Workshop',
      tier: 'basic',
      description: 'Professional automotive services',
      location: { address: 'Not specified' },
      services: ['General Maintenance'],
      years_experience: 0
    },
    subscription: {
      status: 'trial',
      tier: 'basic',
      can_receive_requests: true,
      monthly_usage: 0,
      trial_end_date: null,
      current_period_end: null
    }
  });

  const navigate = useNavigate();

  useEffect(() => {
    checkAuthentication();
  }, []);

  const checkAuthentication = () => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (!token || !userData) {
      navigate('/mechanic-login');
      return;
    }

    try {
      const parsedUser = JSON.parse(userData);
      if (parsedUser.role !== 'mechanic') {
        navigate('/mechanic-login');
        return;
      }
      
      setUser(parsedUser);
      fetchDashboardData(parsedUser.id, token);
    } catch (error) {
      console.error('Auth error:', error);
      navigate('/mechanic-login');
    }
  };

  const fetchDashboardData = async (userId, token) => {
    setLoading(true);
    try {
      // Set default data structure first
      let dashboardDataNew = {
        requests: [],
        stats: {
          total_requests: 0,
          accepted_requests: 0,
          completed_requests: 0,
          pending_requests: 0,
          total_revenue: 0,
          this_month_requests: 0,
          monthly_limit: 50,
          tier: 'basic'
        },
        profile: {
          business_name: `${user?.name || 'Your'} Workshop`,
          tier: 'basic',
          description: 'Professional automotive services',
          location: { address: 'Not specified' },
          services: ['General Maintenance'],
          years_experience: 0
        }
      };

      // Fetch data with individual error handling using fetch API
      try {
        const requestsResponse = await fetch(`/api/mechanics/${userId}/requests`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (requestsResponse.ok) {
          const requestsData = await requestsResponse.json();
          dashboardDataNew.requests = requestsData.requests || [];
        }
      } catch (error) {
        console.warn('Could not fetch requests:', error);
      }

      try {
        const profileResponse = await fetch(`/api/mechanics/${userId}/profile`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (profileResponse.ok) {
          const profileData = await profileResponse.json();
          if (profileData.profile) {
            dashboardDataNew.profile = { ...dashboardDataNew.profile, ...profileData.profile };
          }
        }
      } catch (error) {
        console.warn('Could not fetch profile:', error);
      }

      try {
        const statsResponse = await fetch(`/api/mechanics/${userId}/stats`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (statsResponse.ok) {
          const statsData = await statsResponse.json();
          if (statsData.stats) {
            dashboardDataNew.stats = { ...dashboardDataNew.stats, ...statsData.stats };
          }
        }
      } catch (error) {
        console.warn('Could not fetch stats:', error);
      }

      // Fetch subscription data
      try {
        const subscriptionResponse = await fetch(`/api/subscriptions/user/${userId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (subscriptionResponse.ok) {
          const subscriptionData = await subscriptionResponse.json();
          if (subscriptionData.subscription) {
            dashboardDataNew.subscription = {
              ...dashboardDataNew.subscription,
              ...subscriptionData
            };
          }
        }
      } catch (error) {
        console.warn('Could not fetch subscription:', error);
      }

      setDashboardData(dashboardDataNew);

    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      // Keep default data even on complete failure
    } finally {
      setLoading(false);
    }
  };

  const updateRequestStatus = async (requestId, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/mechanics/requests/${requestId}/status`, {
        method: 'PUT',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status: newStatus })
      });

      if (response.ok) {
        // Refresh dashboard data
        fetchDashboardData(user.id, token);
      } else {
        throw new Error('Failed to update status');
      }
    } catch (error) {
      console.error('Error updating request status:', error);
      alert('Failed to update request status');
    }
  };

  const acceptRequest = async (requestId) => {
    await updateRequestStatus(requestId, 'accepted');
  };

  const handleUpgradePlan = (tier) => {
    const plans = {
      basic: 'https://paystack.shop/pay/b-rg582t-v',
      premium: 'https://paystack.shop/pay/oqglvsd3re',
      pro: '/api/subscriptions/create' // Will use plan code
    };
    
    if (plans[tier]) {
      if (tier === 'pro') {
        // Handle Pro plan via API
        createSubscription(tier);
      } else {
        // Redirect to Paystack checkout for Basic and Premium
        window.open(plans[tier], '_blank');
      }
    }
  };

  const createSubscription = async (tier) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/subscriptions/create', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          user_id: user.id, 
          tier: tier 
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.payment_url) {
          window.open(data.payment_url, '_blank');
        } else {
          // Refresh dashboard to show updated subscription
          fetchDashboardData(user.id, token);
        }
      }
    } catch (error) {
      console.error('Error creating subscription:', error);
      alert('Failed to create subscription');
    }
  };

  const getSubscriptionStatus = () => {
    const subscription = dashboardData.subscription || {};
    
    if (!subscription.subscription) {
      return { 
        status: 'no_subscription', 
        message: 'No active subscription',
        color: 'bg-red-100 text-red-800'
      };
    }

    switch (subscription.subscription_status) {
      case 'trial':
        const daysLeft = subscription.subscription?.trial_end_date 
          ? Math.max(0, Math.ceil((new Date(subscription.subscription.trial_end_date) - new Date()) / (1000 * 60 * 60 * 24)))
          : 0;
        return { 
          status: 'trial', 
          message: `${daysLeft} days left in trial`,
          color: 'bg-yellow-100 text-yellow-800'
        };
      case 'active':
        return { 
          status: 'active', 
          message: 'Subscription active',
          color: 'bg-green-100 text-green-800'
        };
      case 'expired':
        return { 
          status: 'expired', 
          message: 'Subscription expired',
          color: 'bg-red-100 text-red-800'
        };
      case 'attention':
        return { 
          status: 'attention', 
          message: 'Payment attention required',
          color: 'bg-orange-100 text-orange-800'
        };
      default:
        return { 
          status: 'unknown', 
          message: 'Status unknown',
          color: 'bg-gray-100 text-gray-800'
        };
    }
  };

  const getTierInfo = (tier) => {
    const tiers = {
      basic: { 
        label: 'Basic', 
        color: 'bg-gray-500', 
        limit: 50,
        price: '₦2,000/month',
        features: ['Up to 50 requests/month', '3-day free trial', 'Basic support', 'Standard listing'] 
      },
      pro: { 
        label: 'Pro', 
        color: 'bg-blue-500', 
        limit: 100,
        price: '₦5,000/month', 
        features: ['Up to 100 requests/month', 'Priority support', 'Featured listing', 'Advanced analytics'] 
      },
      premium: { 
        label: 'Premium', 
        color: 'bg-orange-500', 
        limit: 'unlimited',
        price: '₦8,900/month',
        features: ['Unlimited requests', 'Premium support', 'Top listing', 'Revenue tracking', 'Direct customer contact'] 
      }
    };
    return tiers[tier] || tiers.basic;
  };

  const getStatusBadgeColor = (status) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800 border border-yellow-300',
      assigned: 'bg-blue-100 text-blue-800 border border-blue-300',
      accepted: 'bg-green-100 text-green-800 border border-green-300', 
      in_progress: 'bg-purple-100 text-purple-800 border border-purple-300',
      completed: 'bg-green-500 text-white border border-green-600',
      cancelled: 'bg-red-100 text-red-800 border border-red-300'
    };
    return colors[status] || 'bg-gray-100 text-gray-800 border border-gray-300';
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-orange-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const tierInfo = getTierInfo(dashboardData.profile?.tier || 'basic');
  const monthlyProgress = tierInfo.limit === 'unlimited' ? 100 : 
    Math.min(((dashboardData.stats?.this_month_requests || 0) / (tierInfo.limit || 50)) * 100, 100);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Wrench className="h-8 w-8 text-orange-600" />
                <div>
                  <span className="text-2xl font-bold text-gray-900">MechFinder</span>
                  <p className="text-sm text-gray-500">Mechanic Dashboard</p>
                </div>
              </div>
              <Badge className={`${tierInfo.color} text-white`}>
                {tierInfo.label} Plan
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{user?.name}</p>
                <p className="text-xs text-gray-500">{dashboardData.profile?.business_name}</p>
              </div>
              <Button
                onClick={() => fetchDashboardData(user.id, localStorage.getItem('token'))}
                variant="outline"
                size="sm"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button onClick={handleLogout} variant="outline" size="sm">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {/* Total Requests */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <FileText className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Requests</p>
                  <p className="text-2xl font-bold text-gray-900">{dashboardData.stats.total_requests}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Accepted Requests */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <CheckCircle className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Accepted</p>
                  <p className="text-2xl font-bold text-gray-900">{dashboardData.stats.accepted_requests}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* This Month Requests */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Calendar className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">This Month</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {dashboardData.stats.this_month_requests}
                    {tierInfo.limit !== 'unlimited' && (
                      <span className="text-sm text-gray-500">/{tierInfo.limit}</span>
                    )}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Revenue */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-orange-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                  <p className="text-2xl font-bold text-gray-900">₦{dashboardData.stats.total_revenue?.toLocaleString() || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Monthly Limit Progress */}
        {tierInfo.limit !== 'unlimited' && (
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Monthly Request Limit</h3>
                <Badge variant={monthlyProgress > 80 ? 'destructive' : 'outline'}>
                  {dashboardData.stats.this_month_requests}/{tierInfo.limit} used
                </Badge>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full transition-all ${monthlyProgress > 80 ? 'bg-red-500' : 'bg-green-500'}`}
                  style={{ width: `${Math.min(monthlyProgress, 100)}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                {monthlyProgress > 80 ? '⚠️ Approaching monthly limit' : '✅ Within monthly limit'}
              </p>
            </CardContent>
          </Card>
        )}

        {/* Subscription Status */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center">
                <Shield className="h-5 w-5 mr-2" />
                Subscription Status
              </h3>
              <Badge className={getSubscriptionStatus().color}>
                {getSubscriptionStatus().message}
              </Badge>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Current Plan */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Current Plan</h4>
                <p className="text-2xl font-bold text-gray-900">{tierInfo.label}</p>
                <p className="text-sm text-gray-600">{tierInfo.price}</p>
                <ul className="mt-2 space-y-1">
                  {tierInfo.features.slice(0, 2).map((feature, index) => (
                    <li key={index} className="text-xs text-gray-600 flex items-center">
                      <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Usage This Month */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Monthly Usage</h4>
                <p className="text-2xl font-bold text-gray-900">
                  {(dashboardData.subscription && dashboardData.subscription.monthly_usage) || dashboardData.stats.this_month_requests}
                </p>
                <p className="text-sm text-gray-600">
                  {tierInfo.limit === 'unlimited' ? 'Unlimited' : `of ${tierInfo.limit} requests`}
                </p>
              </div>

              {/* Subscription Actions */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Manage Plan</h4>
                <div className="space-y-2">
                  {(dashboardData.subscription && dashboardData.subscription.subscription_status === 'trial') && (
                    <Button 
                      onClick={() => handleUpgradePlan('basic')}
                      className="w-full bg-green-600 hover:bg-green-700 text-sm"
                    >
                      Activate Basic Plan
                    </Button>
                  )}
                  
                  {(!dashboardData.subscription || dashboardData.subscription.tier !== 'premium') && (
                    <Button 
                      onClick={() => handleUpgradePlan('premium')}
                      variant="outline" 
                      className="w-full text-sm"
                    >
                      Upgrade to Premium
                    </Button>
                  )}
                  
                  {(dashboardData.subscription && dashboardData.subscription.tier === 'basic') && (
                    <Button 
                      onClick={() => handleUpgradePlan('pro')}
                      variant="outline" 
                      className="w-full text-sm"
                    >
                      Upgrade to Pro
                    </Button>
                  )}
                </div>
              </div>
            </div>

            {/* Trial Warning */}
            {(dashboardData.subscription && dashboardData.subscription.subscription_status === 'trial') && (
              <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-center">
                  <AlertCircle className="h-5 w-5 text-yellow-600 mr-2" />
                  <div>
                    <p className="text-sm font-medium text-yellow-800">Free Trial Active</p>
                    <p className="text-xs text-yellow-600">
                      Your free trial will end soon. Subscribe to continue receiving service requests.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Expired Warning */}
            {(dashboardData.subscription && dashboardData.subscription.subscription_status === 'expired') && (
              <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center">
                  <AlertCircle className="h-5 w-5 text-red-600 mr-2" />
                  <div>
                    <p className="text-sm font-medium text-red-800">Subscription Expired</p>
                    <p className="text-xs text-red-600">
                      Your subscription has ended. Renew to continue receiving service requests.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Main Dashboard */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="requests">My Requests</TabsTrigger>
            <TabsTrigger value="profile">Profile & Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Plan Details */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Star className="h-5 w-5 mr-2" />
                    Your {tierInfo.label} Plan
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {tierInfo.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-4 space-y-2">
                    {(!dashboardData.subscription || dashboardData.subscription.tier !== 'premium') && (
                      <Button 
                        onClick={() => handleUpgradePlan('premium')}
                        className="w-full"
                      >
                        Upgrade to Premium
                      </Button>
                    )}
                    
                    {(dashboardData.subscription && dashboardData.subscription.tier === 'basic') && (
                      <Button 
                        onClick={() => handleUpgradePlan('pro')}
                        variant="outline" 
                        className="w-full"
                      >
                        Upgrade to Pro
                      </Button>
                    )}
                    
                    {(dashboardData.subscription && dashboardData.subscription.subscription_status === 'trial') && (
                      <Button 
                        onClick={() => handleUpgradePlan('basic')}
                        variant="outline"
                        className="w-full"
                      >
                        Activate Basic Plan
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="h-5 w-5 mr-2" />
                    Recent Requests
                  </CardTitle>
                  <CardDescription>Quick status management for your latest assignments</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardData.requests.slice(0, 3).map((request, index) => (
                      <div key={request.id || index} className="bg-gray-50 rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <p className="font-medium text-sm">{request.service_type}</p>
                            <p className="text-xs text-gray-500">{request.customer_name}</p>
                          </div>
                          <Badge className={getStatusBadgeColor(request.status)}>
                            {request.status?.toUpperCase() || 'PENDING'}
                          </Badge>
                        </div>
                        
                        {/* Quick Status Update Buttons */}
                        <div className="flex space-x-2 mt-2">
                          {(request.status === 'pending' || request.status === 'assigned') && (
                            <Button 
                              onClick={() => updateRequestStatus(request.id, 'accepted')}
                              size="sm"
                              className="bg-green-600 hover:bg-green-700 text-xs px-2 py-1"
                            >
                              ✅ Accept
                            </Button>
                          )}
                          
                          {request.status === 'accepted' && (
                            <Button 
                              onClick={() => updateRequestStatus(request.id, 'in_progress')}
                              size="sm"
                              className="bg-blue-600 hover:bg-blue-700 text-xs px-2 py-1"
                            >
                              🔧 Start
                            </Button>
                          )}
                          
                          {request.status === 'in_progress' && (
                            <Button 
                              onClick={() => updateRequestStatus(request.id, 'completed')}
                              size="sm"
                              className="bg-orange-600 hover:bg-orange-700 text-xs px-2 py-1"
                            >
                              🎉 Complete
                            </Button>
                          )}
                          
                          {request.status === 'completed' && (
                            <span className="text-green-600 text-xs font-medium">✅ Job Done!</span>
                          )}
                        </div>
                      </div>
                    ))}
                    {dashboardData.requests.length === 0 && (
                      <div className="text-center py-4">
                        <FileText className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                        <p className="text-gray-500 text-sm">No requests yet</p>
                        <p className="text-xs text-gray-400">New assignments will appear here</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Requests Tab */}
          <TabsContent value="requests" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Service Requests</CardTitle>
                <CardDescription>Manage your assigned service requests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {dashboardData.requests.map((request, index) => (
                    <div key={request.id || index} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-semibold text-lg">{request.service_type}</h4>
                          <p className="text-sm text-gray-600">Customer: {request.customer_name}</p>
                          <p className="text-sm text-gray-600">Phone: {request.customer_phone}</p>
                          <p className="text-sm text-gray-600">Location: {request.customer_address}</p>
                        </div>
                        <div className="text-right">
                          <Badge className={getStatusBadgeColor(request.status)}>
                            {request.status?.toUpperCase() || 'PENDING'}
                          </Badge>
                          <p className="text-xs text-gray-500 mt-1">
                            Assigned: {request.created_at ? (() => {
                              try {
                                return new Date(request.created_at).toLocaleDateString();
                              } catch (e) {
                                return 'Unknown date';
                              }
                            })() : 'Unknown'}
                          </p>
                        </div>
                      </div>
                      
                      <p className="text-sm mb-4 bg-gray-50 p-3 rounded-lg">{request.description}</p>
                      
                      {/* Enhanced Status Management Section */}
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                        <h5 className="font-semibold text-blue-800 mb-3">🎯 Request Status Management</h5>
                        
                        <div className="grid md:grid-cols-2 gap-4">
                          {/* Current Status Display */}
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Current Status:</label>
                            <div className="flex items-center space-x-2">
                              <Badge className={getStatusBadgeColor(request.status)}>
                                {request.status?.toUpperCase() || 'PENDING'}
                              </Badge>
                              {request.status === 'completed' && (
                                <span className="text-green-600 text-lg">✅</span>
                              )}
                            </div>
                          </div>

                          {/* Status Change Controls */}
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Update Status:</label>
                            <div className="space-y-2">
                              {/* Show appropriate buttons based on current status */}
                              {(request.status === 'pending' || request.status === 'assigned') && (
                                <Button 
                                  onClick={() => updateRequestStatus(request.id, 'accepted')}
                                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                                  size="sm"
                                >
                                  ✅ Accept Request
                                </Button>
                              )}
                              
                              {request.status === 'accepted' && (
                                <Button 
                                  onClick={() => updateRequestStatus(request.id, 'in_progress')}
                                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                                  size="sm"
                                >
                                  🔧 Start Work
                                </Button>
                              )}
                              
                              {request.status === 'in_progress' && (
                                <Button 
                                  onClick={() => updateRequestStatus(request.id, 'completed')}
                                  className="w-full bg-orange-600 hover:bg-orange-700 text-white"
                                  size="sm"
                                >
                                  🎉 Mark Completed
                                </Button>
                              )}

                              {request.status === 'completed' && (
                                <div className="bg-green-100 border border-green-300 rounded-lg p-3 text-center">
                                  <span className="text-green-800 font-semibold">🎉 Job Completed!</span>
                                  <p className="text-xs text-green-600 mt-1">Great work! Payment should be collected from customer.</p>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Status Progress Indicator */}
                        <div className="mt-4">
                          <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                            <span>Pending</span>
                            <span>Accepted</span>
                            <span>In Progress</span>
                            <span>Completed</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="h-2 rounded-full transition-all bg-gradient-to-r from-yellow-400 via-blue-500 via-purple-500 to-green-500"
                              style={{ 
                                width: 
                                  request.status === 'pending' || request.status === 'assigned' ? '25%' :
                                  request.status === 'accepted' ? '50%' :
                                  request.status === 'in_progress' ? '75%' :
                                  request.status === 'completed' ? '100%' : '25%'
                              }}
                            ></div>
                          </div>
                        </div>
                      </div>

                      {/* Contact Customer Section */}
                      <div className="flex items-center space-x-3">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => window.open(`tel:${request.customer_phone}`)}
                          className="flex-1"
                        >
                          <Phone className="h-4 w-4 mr-1" />
                          Call Customer
                        </Button>
                        
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => window.open(`https://wa.me/${request.customer_phone?.replace(/[^0-9]/g, '')}`)}
                          className="flex-1"
                        >
                          <MessageCircle className="h-4 w-4 mr-1" />
                          WhatsApp
                        </Button>
                      </div>
                    </div>
                  ))}
                  
                  {dashboardData.requests.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No service requests assigned yet</p>
                      <p className="text-sm">Check back later for new assignments</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Profile Info */}
              <Card>
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                </CardHeader>
                <CardContent>
                  {dashboardData.profile ? (
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium text-gray-600">Business Name</label>
                        <p className="font-semibold">{dashboardData.profile.business_name}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-600">Location</label>
                        <p>{dashboardData.profile.location?.address}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-600">Services</label>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {dashboardData.profile.services?.map((service, index) => (
                            <Badge key={index} variant="outline">{service}</Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-600">Experience</label>
                        <p>{dashboardData.profile.years_experience} years</p>
                      </div>
                    </div>
                  ) : (
                    <p className="text-gray-500">Profile information not available</p>
                  )}
                </CardContent>
              </Card>

              {/* Settings */}
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Button className="w-full" variant="outline">
                      <Settings className="h-4 w-4 mr-2" />
                      Edit Profile
                    </Button>
                    <Button className="w-full" variant="outline">
                      <Shield className="h-4 w-4 mr-2" />
                      Change Password
                    </Button>
                    <Button className="w-full" variant="outline">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      Upgrade Plan
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default MechanicDashboard;