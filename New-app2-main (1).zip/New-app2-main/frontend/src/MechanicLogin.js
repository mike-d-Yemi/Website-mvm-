import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Wrench, AlertCircle, CheckCircle, Eye, EyeOff } from 'lucide-react';

const MechanicLogin = () => {
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  const navigate = useNavigate();

  const handleInputChange = (field, value) => {
    setLoginData(prev => ({ ...prev, [field]: value }));
    if (error) setError(''); // Clear error when user starts typing
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      console.log('🔐 Mechanic Login Attempt:', loginData.email);
      
      // Use fetch instead of axios to avoid import issues
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: loginData.email,
          password: loginData.password
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('✅ Login Response:', data);
      
      // Check if user is a mechanic
      if (data.user.role !== 'mechanic') {
        setError('❌ This login is for mechanics only. Please use the customer service request form.');
        setLoading(false);
        return;
      }

      // Store authentication data
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      
      console.log('✅ Auth data stored, redirecting to dashboard...');
      
      setSuccess('✅ Login successful! Redirecting to your dashboard...');
      
      // Redirect to mechanic dashboard immediately
      setTimeout(() => {
        navigate('/mechanic-dashboard');
      }, 1500);
      
    } catch (error) {
      console.error('❌ Login Error:', error);
      
      if (error.message.includes('401')) {
        setError('❌ Invalid email or password. Please check your credentials.');
      } else {
        setError('❌ Login failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-blue-50 flex items-center justify-center">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-white bg-opacity-50"></div>
      
      {/* Login Card */}
      <div className="relative z-10 w-full max-w-md mx-4">
        <Card className="shadow-2xl border-0 bg-white backdrop-blur">
          <CardHeader className="text-center pb-8">
            {/* Mechanic Logo */}
            <div className="flex items-center justify-center space-x-3 mb-6">
              <div className="bg-orange-600 p-4 rounded-full">
                <Wrench className="h-10 w-10 text-white" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-3xl font-bold text-gray-900">MechFinder</span>
                </div>
                <p className="text-sm text-orange-600 font-semibold">MECHANIC LOGIN</p>
              </div>
            </div>
            
            <CardTitle className="text-2xl font-bold text-gray-900">
              Welcome Back, Mechanic!
            </CardTitle>
            <CardDescription className="text-gray-600">
              Access your dashboard to manage service requests
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            {/* Success/Error Messages */}
            {(error || success) && (
              <div className={`mb-6 p-4 rounded-lg border-l-4 ${
                success 
                  ? 'bg-green-50 border-green-500 text-green-700'
                  : 'bg-red-50 border-red-500 text-red-700'
              }`}>
                <div className="flex items-center">
                  {success ? <CheckCircle className="h-5 w-5 mr-2" /> : <AlertCircle className="h-5 w-5 mr-2" />}
                  <span>{success || error}</span>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Email Field */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">
                  Your Email Address
                </label>
                <Input
                  type="email"
                  value={loginData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="Enter your email"
                  required
                  className="h-12 bg-gray-50 border-gray-300 focus:border-orange-500 focus:ring-orange-500"
                />
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">
                  Password
                </label>
                <div className="relative">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={loginData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    placeholder="Enter your password"
                    required
                    className="h-12 bg-gray-50 border-gray-300 focus:border-orange-500 focus:ring-orange-500 pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Login Button */}
              <Button
                type="submit"
                disabled={loading}
                className="w-full h-12 bg-orange-600 hover:bg-orange-700 text-white font-semibold text-lg"
              >
                {loading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Signing In...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <Wrench className="h-5 w-5" />
                    <span>Access Dashboard</span>
                  </div>
                )}
              </Button>
            </form>

            {/* Test Credentials */}
            <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="text-sm font-semibold text-blue-800 mb-2">🧪 Test Credentials</h4>
              <div className="text-xs text-blue-700 space-y-1">
                <p><strong>Email:</strong> fixedtest@mechanic.ng</p>
                <p><strong>Password:</strong> fixed123</p>
                <p><strong>Tier:</strong> Premium (Unlimited requests)</p>
              </div>
            </div>

            {/* Links */}
            <div className="mt-6 space-y-3 text-center">
              <button
                onClick={() => navigate('/auth')}
                className="text-sm text-orange-600 hover:text-orange-700 underline block"
              >
                Need to register as a mechanic? →
              </button>
              <button
                onClick={() => navigate('/')}
                className="text-sm text-gray-500 hover:text-gray-700 underline block"
              >
                ← Back to Main Site
              </button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <div className="absolute bottom-4 left-0 right-0 text-center">
        <p className="text-gray-500 text-sm">
          MechFinder Mechanic Portal • Secure Access to Your Dashboard
        </p>
      </div>
    </div>
  );
};

export default MechanicLogin;