import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Textarea } from './components/ui/textarea';
import { 
  Wrench, Users, Star, Shield, Clock, MapPin, Phone, 
  Mail, User, Building, AlertCircle, CheckCircle, Eye, EyeOff 
} from 'lucide-react';

const MechanicRegistration = () => {
  const [activeTab, setActiveTab] = useState('register');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [citiesData, setCitiesData] = useState([]);
  const [availableCities, setAvailableCities] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Registration form data
  const [formData, setFormData] = useState({
    // User account details
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    
    // Business details
    business_name: '',
    description: '',
    address: '',
    state: '',
    city: '',
    
    // Services and pricing
    services: [],
    tier: 'basic',
    years_experience: '',
    
    // Contact details
    whatsapp: '',
    
    // Agreement
    agree_terms: false
  });

  // Login form data
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  });

  const navigate = useNavigate();

  useEffect(() => {
    fetchCitiesData();
  }, []);

  const fetchCitiesData = async () => {
    try {
      const response = await axios.get('/api/cities');
      setCitiesData(response.data.cities_by_state || []);
    } catch (error) {
      console.error('Error fetching cities:', error);
    }
  };

  const handleStateChange = (state) => {
    setFormData(prev => ({ 
      ...prev, 
      state: state, 
      city: '' // Reset city when state changes
    }));

    // Find cities for selected state
    const stateData = citiesData.find(item => item.state === state);
    setAvailableCities(stateData ? stateData.cities : []);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (error) setError(''); // Clear error when user starts typing
  };

  const handleLoginChange = (field, value) => {
    setLoginData(prev => ({ ...prev, [field]: value }));
    if (error) setError('');
  };

  const handleServiceToggle = (service) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(service)
        ? prev.services.filter(s => s !== service)
        : [...prev.services, service]
    }));
  };

  const validateForm = () => {
    if (!formData.name || !formData.email || !formData.phone || !formData.password) {
      setError('Please fill in all required personal details');
      return false;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return false;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return false;
    }

    if (!formData.business_name || !formData.description) {
      setError('Please provide business name and description');
      return false;
    }

    if (!formData.state || !formData.city) {
      setError('Please select your state and city');
      return false;
    }

    if (formData.services.length === 0) {
      setError('Please select at least one service you offer');
      return false;
    }

    if (!formData.agree_terms) {
      setError('Please agree to the terms and conditions');
      return false;
    }

    return true;
  };

  const handleRegistration = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (!validateForm()) {
      setLoading(false);
      return;
    }

    try {
      console.log('Registering mechanic:', formData);
      
      const response = await axios.post('/api/auth/register', {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        password: formData.password,
        role: 'mechanic',
        selected_tier: formData.tier,
        city: formData.city,
        state: formData.state,
        address: formData.address
      });

      console.log('Registration successful:', response.data);
      
      // Store token and user data
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));
      
      setSuccess('Registration successful! Welcome to MechFinder. Redirecting to your dashboard...');
      
      // Redirect to mechanic dashboard after short delay
      setTimeout(() => {
        navigate('/mechanic-dashboard');
      }, 2000);
      
    } catch (error) {
      console.error('Registration error:', error);
      
      if (error.response?.data?.detail) {
        setError(error.response.data.detail);
      } else {
        setError('Registration failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      console.log('Logging in mechanic:', loginData.email);
      
      const response = await axios.post('/api/auth/login', loginData);
      
      // Check if user is a mechanic
      if (response.data.user.role !== 'mechanic') {
        setError('This login is for mechanics only. Please use the customer service request form.');
        setLoading(false);
        return;
      }

      console.log('Login successful:', response.data);
      
      // Store token and user data
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));
      
      setSuccess('Login successful! Redirecting to your dashboard...');
      
      // Redirect to mechanic dashboard
      setTimeout(() => {
        navigate('/mechanic-dashboard');
      }, 1000);
      
    } catch (error) {
      console.error('Login error:', error);
      
      if (error.response?.status === 401) {
        setError('Invalid email or password');
      } else {
        setError('Login failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const serviceOptions = [
    'Engine Repair', 'Oil Change', 'Brake Service', 'Battery Service',
    'Tire Service', 'Electrical Repair', 'AC Repair', 'General Maintenance',
    'Transmission Repair', 'Suspension Repair', 'Emergency Roadside'
  ];

  const tierOptions = [
    { value: 'basic', label: 'Basic', price: 'Free', features: ['Basic listing', 'Customer contact', 'Up to 5 services'] },
    { value: 'premium', label: 'Premium', price: '₦5,000/month', features: ['Featured listing', 'Priority support', 'Unlimited services', 'Customer reviews'] },
    { value: 'pro', label: 'Pro', price: '₦10,000/month', features: ['Top listing', '24/7 support', 'Analytics dashboard', 'Marketing tools'] }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Wrench className="h-8 w-8 text-orange-600" />
              <span className="text-2xl font-bold text-gray-900">MechFinder</span>
              <Badge className="bg-orange-100 text-orange-800">For Mechanics</Badge>
            </div>
            <Button onClick={() => navigate('/')} variant="outline">
              ← Back to Main Site
            </Button>
          </div>
        </div>
      </header>

      {/* Success/Error Messages */}
      {(error || success) && (
        <div className="max-w-2xl mx-auto px-4 mt-4">
          <div className={`p-4 rounded-lg border-l-4 ${
            success 
              ? 'bg-green-50 border-green-500 text-green-700'
              : 'bg-red-50 border-red-500 text-red-700'
          }`}>
            <div className="flex items-center">
              {success ? <CheckCircle className="h-5 w-5 mr-2" /> : <AlertCircle className="h-5 w-5 mr-2" />}
              <span>{success || error}</span>
            </div>
            {(error || success) && (
              <button 
                onClick={() => { setError(''); setSuccess(''); }}
                className="ml-auto font-bold hover:opacity-75"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Join MechFinder as a Professional Mechanic</h1>
          <p className="text-xl text-gray-600">Connect with customers across Nigeria and grow your business</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="register">Register New Account</TabsTrigger>
            <TabsTrigger value="login">Login Existing Account</TabsTrigger>
          </TabsList>

          {/* Registration Tab */}
          <TabsContent value="register">
            <Card>
              <CardHeader>
                <CardTitle>Create Your Mechanic Account</CardTitle>
                <CardDescription>Join thousands of professional mechanics on MechFinder</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleRegistration} className="space-y-6">
                  {/* Personal Details */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h3 className="text-lg font-semibold text-blue-800 mb-4">👤 Personal Details</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Full Name *
                        </label>
                        <Input
                          type="text"
                          value={formData.name}
                          onChange={(e) => handleInputChange('name', e.target.value)}
                          placeholder="Enter your full name"
                          required
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Phone Number *
                        </label>
                        <Input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => handleInputChange('phone', e.target.value)}
                          placeholder="+234-XXX-XXX-XXXX"
                          required
                        />
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email Address *
                        </label>
                        <Input
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleInputChange('email', e.target.value)}
                          placeholder="your@email.com"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Password *
                        </label>
                        <div className="relative">
                          <Input
                            type={showPassword ? 'text' : 'password'}
                            value={formData.password}
                            onChange={(e) => handleInputChange('password', e.target.value)}
                            placeholder="Minimum 6 characters"
                            required
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Confirm Password *
                        </label>
                        <Input
                          type="password"
                          value={formData.confirmPassword}
                          onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                          placeholder="Confirm your password"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Business Details */}
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h3 className="text-lg font-semibold text-green-800 mb-4">🏢 Business Details</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Business/Workshop Name *
                        </label>
                        <Input
                          type="text"
                          value={formData.business_name}
                          onChange={(e) => handleInputChange('business_name', e.target.value)}
                          placeholder="e.g., Lagos Auto Experts"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Business Description *
                        </label>
                        <Textarea
                          value={formData.description}
                          onChange={(e) => handleInputChange('description', e.target.value)}
                          placeholder="Describe your services and experience..."
                          rows={3}
                          required
                        />
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Years of Experience
                          </label>
                          <Input
                            type="number"
                            value={formData.years_experience}
                            onChange={(e) => handleInputChange('years_experience', e.target.value)}
                            placeholder="e.g., 5"
                            min="0"
                            max="50"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            WhatsApp Number
                          </label>
                          <Input
                            type="tel"
                            value={formData.whatsapp}
                            onChange={(e) => handleInputChange('whatsapp', e.target.value)}
                            placeholder="+234-XXX-XXX-XXXX"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Location */}
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                    <h3 className="text-lg font-semibold text-orange-800 mb-4">📍 Location</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          State *
                        </label>
                        <select
                          value={formData.state}
                          onChange={(e) => handleStateChange(e.target.value)}
                          required
                          className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                        >
                          <option value="">Select your state</option>
                          {citiesData.map((stateItem) => (
                            <option key={stateItem.state} value={stateItem.state}>
                              {stateItem.state}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          City/Area *
                        </label>
                        <select
                          value={formData.city}
                          onChange={(e) => handleInputChange('city', e.target.value)}
                          disabled={!formData.state}
                          required
                          className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500 disabled:bg-gray-100"
                        >
                          <option value="">
                            {formData.state ? 'Select city/area' : 'Select state first'}
                          </option>
                          {availableCities.map((city) => (
                            <option key={city} value={city}>
                              {city}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Workshop Address
                        </label>
                        <Input
                          type="text"
                          value={formData.address}
                          onChange={(e) => handleInputChange('address', e.target.value)}
                          placeholder="Enter your workshop address"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Services */}
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <h3 className="text-lg font-semibold text-purple-800 mb-4">🔧 Services Offered *</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {serviceOptions.map((service) => (
                        <label key={service} className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formData.services.includes(service)}
                            onChange={() => handleServiceToggle(service)}
                            className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                          />
                          <span className="text-sm text-gray-700">{service}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Subscription Tier */}
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h3 className="text-lg font-semibold text-yellow-800 mb-4">⭐ Choose Your Plan</h3>
                    <div className="grid md:grid-cols-3 gap-4">
                      {tierOptions.map((tier) => (
                        <div 
                          key={tier.value}
                          className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                            formData.tier === tier.value 
                              ? 'border-orange-500 bg-orange-50' 
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          onClick={() => handleInputChange('tier', tier.value)}
                        >
                          <div className="flex items-center space-x-2 mb-2">
                            <input
                              type="radio"
                              name="tier"
                              value={tier.value}
                              checked={formData.tier === tier.value}
                              onChange={() => handleInputChange('tier', tier.value)}
                              className="text-orange-600 focus:ring-orange-500"
                            />
                            <span className="font-semibold">{tier.label}</span>
                            <Badge variant="outline">{tier.price}</Badge>
                          </div>
                          <ul className="text-sm text-gray-600 space-y-1">
                            {tier.features.map((feature, index) => (
                              <li key={index} className="flex items-center">
                                <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
                                {feature}
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Terms Agreement */}
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                    <label className="flex items-start space-x-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.agree_terms}
                        onChange={(e) => handleInputChange('agree_terms', e.target.checked)}
                        className="mt-1 rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                        required
                      />
                      <span className="text-sm text-gray-700">
                        I agree to the <a href="#" className="text-orange-600 hover:underline">Terms of Service</a> and 
                        <a href="#" className="text-orange-600 hover:underline ml-1">Privacy Policy</a>. 
                        I understand that MechFinder will verify my credentials and may contact me for additional information.
                      </span>
                    </label>
                  </div>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 text-lg"
                  >
                    {loading ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Creating Account...</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <Wrench className="h-5 w-5" />
                        <span>Create Mechanic Account</span>
                      </div>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Login Tab */}
          <TabsContent value="login">
            <Card>
              <CardHeader>
                <CardTitle>Welcome Back!</CardTitle>
                <CardDescription>Sign in to your mechanic account</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleLogin} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address
                    </label>
                    <Input
                      type="email"
                      value={loginData.email}
                      onChange={(e) => handleLoginChange('email', e.target.value)}
                      placeholder="your@email.com"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Password
                    </label>
                    <Input
                      type="password"
                      value={loginData.password}
                      onChange={(e) => handleLoginChange('password', e.target.value)}
                      placeholder="Enter your password"
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 text-lg"
                  >
                    {loading ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Signing In...</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <User className="h-5 w-5" />
                        <span>Sign In to Dashboard</span>
                      </div>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Why Join Section */}
        <div className="mt-12 bg-white rounded-xl p-8 shadow-lg">
          <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">Why Join MechFinder?</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">More Customers</h3>
              <p className="text-gray-600">Connect with thousands of car owners across Nigeria</p>
            </div>
            
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Build Reputation</h3>
              <p className="text-gray-600">Get reviews and build your professional reputation</p>
            </div>
            
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Verified Platform</h3>
              <p className="text-gray-600">Join a trusted platform with verified mechanics</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MechanicRegistration;