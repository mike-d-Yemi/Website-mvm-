import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Textarea } from './components/ui/textarea';
import { Wrench, MessageCircle, AlertCircle } from 'lucide-react';

const SimpleRequestForm = () => {
  const [formData, setFormData] = useState({
    customer_name: '',
    customer_phone: '',
    customer_address: '',
    service_type: '',
    description: '',
    preferred_state: '',
    preferred_city: ''
  });
  
  const [citiesData, setCitiesData] = useState([]);
  const [availableCities, setAvailableCities] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [requestStatus, setRequestStatus] = useState({ show: false, type: '', message: '', mechanic: '' });
  const navigate = useNavigate();

  useEffect(() => {
    fetchCitiesData();
  }, []);

  const fetchCitiesData = async () => {
    try {
      const response = await axios.get('/api/cities');
      setCitiesData(response.data.cities_by_state || []);
    } catch (error) {
      console.error('Error fetching cities:', error);
    }
  };

  const handleStateChange = (state) => {
    setFormData(prev => ({ 
      ...prev, 
      preferred_state: state, 
      preferred_city: '' // Reset city when state changes
    }));

    // Find cities for selected state
    const stateData = citiesData.find(item => item.state === state);
    setAvailableCities(stateData ? stateData.cities : []);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Validate required fields - only state and city are required
    if (!formData.preferred_state || !formData.preferred_city) {
      setRequestStatus({
        show: true,
        type: 'error',
        message: '❌ Please select your state and city location.',
        mechanic: 'N/A'
      });
      setIsSubmitting(false);
      return;
    }

    // Use default coordinates based on state or fallback to Lagos
    const stateCoordinates = {
      'Lagos': [6.5244, 3.3792],
      'Abuja': [9.0579, 7.4951],
      'Kano': [12.0022, 8.5919],
      'Rivers': [4.8156, 7.0498],
      'Oyo': [7.8056, 3.9470]
    };
    
    const coordinates = stateCoordinates[formData.preferred_state] || [6.5244, 3.3792];

    const requestData = {
      customer_name: formData.customer_name || 'Customer',
      customer_phone: formData.customer_phone || 'Not provided',
      customer_address: formData.customer_address || `${formData.preferred_city}, ${formData.preferred_state}`,
      service_type: formData.service_type || 'General Service',
      description: formData.description || 'Service requested',
      location: {
        address: `${formData.preferred_city}, ${formData.preferred_state}`,
        coordinates: coordinates,
        preferred_state: formData.preferred_state,
        preferred_city: formData.preferred_city
      },
      mechanic_id: null // No specific mechanic required
    };

    try {
      console.log('=== SIMPLIFIED FORM SUBMISSION START ===');
      console.log('Request Data:', JSON.stringify(requestData, null, 2));

      const response = await fetch('/api/service-requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(requestData)
      });

      console.log('Response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const responseData = await response.json();
      console.log('✅ SUCCESS:', responseData);

      setRequestStatus({
        show: true,
        type: 'success',
        message: `🎉 Request sent successfully! We will find a qualified mechanic in ${formData.preferred_city}, ${formData.preferred_state} to help you.`,
        mechanic: 'Auto-assigned'
      });

      // Reset form
      setFormData({
        customer_name: '',
        customer_phone: '',
        customer_address: '',
        service_type: '',
        description: '',
        preferred_state: '',
        preferred_city: ''
      });
      setAvailableCities([]);

    } catch (error) {
      console.error('❌ SUBMISSION FAILED:', error);
      setRequestStatus({
        show: true,
        type: 'error',
        message: `❌ Failed to send request: ${error.message}`,
        mechanic: 'Unknown'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Wrench className="h-8 w-8 text-orange-600" />
              <span className="text-2xl font-bold text-gray-900">MechFinder</span>
            </div>
            <Button onClick={() => navigate('/')} variant="outline">
              ← Back to Home
            </Button>
          </div>
        </div>
      </header>

      {/* Success/Error Notification */}
      {requestStatus.show && (
        <div className={`mx-4 mt-4 p-4 rounded-lg shadow-lg border-l-4 ${
          requestStatus.type === 'success' 
            ? 'bg-gradient-to-r from-green-100 to-green-200 border-green-500 text-green-800'
            : 'bg-gradient-to-r from-red-100 to-red-200 border-red-500 text-red-800'
        }`}>
          <div className="flex items-start justify-between">
            <div className="flex items-start">
              <div className={`rounded-full p-2 mr-3 ${
                requestStatus.type === 'success' ? 'bg-green-500 animate-bounce' : 'bg-red-500'
              }`}>
                {requestStatus.type === 'success' 
                  ? <MessageCircle className="h-5 w-5 text-white" />
                  : <AlertCircle className="h-5 w-5 text-white" />
                }
              </div>
              <div>
                <p className="font-bold text-lg">
                  {requestStatus.type === 'success' ? '✅ Request Sent Successfully!' : '❌ Request Failed'}
                </p>
                <p className="text-sm mt-1">{requestStatus.message}</p>
              </div>
            </div>
            <button 
              onClick={() => setRequestStatus({ show: false, type: '', message: '', mechanic: '' })}
              className="font-bold text-xl hover:opacity-75"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center">🔧 Request Mechanic Service</CardTitle>
            <CardDescription className="text-center">
              Simply select your location and we'll find a qualified mechanic in your area
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Location Section - REQUIRED */}
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
                <h3 className="text-lg font-semibold text-orange-800 mb-3">📍 Your Location (Required)</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {/* State Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      State *
                    </label>
                    <select
                      value={formData.preferred_state}
                      onChange={(e) => handleStateChange(e.target.value)}
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                    >
                      <option value="">Select your state</option>
                      {citiesData.map((stateItem) => (
                        <option key={stateItem.state} value={stateItem.state}>
                          {stateItem.state}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* City Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      City/Area *
                    </label>
                    <select
                      value={formData.preferred_city}
                      onChange={(e) => handleInputChange('preferred_city', e.target.value)}
                      disabled={!formData.preferred_state}
                      required
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500 disabled:bg-gray-100"
                    >
                      <option value="">
                        {formData.preferred_state ? 'Select city/area' : 'Select state first'}
                      </option>
                      {availableCities.map((city) => (
                        <option key={city} value={city}>
                          {city}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Optional Details */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-700">Additional Information (Optional)</h3>
                
                {/* Customer Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Your Name
                  </label>
                  <Input
                    type="text"
                    value={formData.customer_name}
                    onChange={(e) => handleInputChange('customer_name', e.target.value)}
                    placeholder="Enter your name"
                    className="w-full"
                  />
                </div>

                {/* Phone Number */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number
                  </label>
                  <Input
                    type="tel"
                    value={formData.customer_phone}
                    onChange={(e) => handleInputChange('customer_phone', e.target.value)}
                    placeholder="+234-XXX-XXX-XXXX"
                    className="w-full"
                  />
                </div>

                {/* Address */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Specific Address
                  </label>
                  <Input
                    type="text"
                    value={formData.customer_address}
                    onChange={(e) => handleInputChange('customer_address', e.target.value)}
                    placeholder="Enter your specific address"
                    className="w-full"
                  />
                </div>

                {/* Service Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Service Type
                  </label>
                  <select
                    value={formData.service_type}
                    onChange={(e) => handleInputChange('service_type', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                  >
                    <option value="">Select service type</option>
                    <option value="Engine Repair">Engine Repair</option>
                    <option value="Oil Change">Oil Change</option>
                    <option value="Brake Service">Brake Service</option>
                    <option value="Battery Service">Battery Service</option>
                    <option value="Tire Service">Tire Service</option>
                    <option value="Electrical Repair">Electrical Repair</option>
                    <option value="AC Repair">AC Repair</option>
                    <option value="General Maintenance">General Maintenance</option>
                  </select>
                </div>

                {/* Problem Description */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Describe the Problem
                  </label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    placeholder="Please describe your car's problem..."
                    rows={3}
                    className="w-full"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 text-lg"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-3"></div>
                      Sending Request...
                    </>
                  ) : (
                    '🚀 Send Service Request'
                  )}
                </Button>
              </div>
            </form>

            {/* Information Box */}
            <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-800 mb-2">What happens next?</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• We'll find qualified mechanics in {formData.preferred_city && formData.preferred_state ? `${formData.preferred_city}, ${formData.preferred_state}` : 'your area'}</li>
                <li>• A mechanic will contact you within 30 minutes</li>
                <li>• Get a transparent quote for the service</li>
                <li>• Schedule a convenient time for repair</li>
                <li>• Pay the mechanic directly after service completion</li>
                <li>• No upfront payment required • Quality guaranteed</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SimpleRequestForm;