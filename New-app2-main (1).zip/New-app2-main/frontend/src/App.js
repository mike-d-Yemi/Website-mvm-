import React, { useState, useEffect } from 'react';
import './App.css';
import { HashRouter, Routes, Route, Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './components/ui/dialog';
import { Label } from './components/ui/label';
import { Textarea } from './components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Star, MapPin, Phone, MessageCircle, Search, Wrench, Users, Award, Clock, Shield, AlertCircle } from 'lucide-react';
import SimpleRequestForm from './SimpleRequestForm';
import AdminDashboard from './AdminDashboard';
import AdminLogin from './AdminLogin';
import MechanicRegistration from './MechanicRegistration';
import MechanicDashboard from './MechanicDashboard';
import MechanicLogin from './MechanicLogin';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || '';
const API = BACKEND_URL ? `${BACKEND_URL}/api` : '/api';

// Context for user authentication
const AuthContext = React.createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));

  useEffect(() => {
    if (token) {
      // Decode token to get user info
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        setUser({ id: payload.user_id, email: payload.email, userType: payload.user_type });
      } catch (error) {
        console.error('Invalid token:', error);
        localStorage.removeItem('token');
        setToken(null);
      }
    }
  }, [token]);

  const login = (token, userData) => {
    localStorage.setItem('token', token);
    setToken(token);
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

// Main App Component
function App() {
  return (
    <AuthProvider>
      <div className="App">
        <HashRouter>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/auth" element={<MechanicRegistration />} />
            <Route path="/mechanic-login" element={<MechanicLogin />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/request-service" element={<SimpleRequestForm />} />
            <Route path="/mechanic-dashboard" element={<MechanicDashboard />} />
            <Route path="/payment-success" element={<PaymentSuccess />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin-login" element={<AdminLogin />} />
            <Route path="/admin-panel" element={<AdminDashboard />} />
            <Route path="/requests" element={<ServiceRequestsPage />} />
          </Routes>
        </HashRouter>
      </div>
    </AuthProvider>
  );
}

// Landing Page Component
const LandingPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [mechanics, setMechanics] = useState([]);
  const [userLocation, setUserLocation] = useState(null);
  const [filters, setFilters] = useState({
    service: 'all',
    tier: 'all',
    radius: '50'
  });
  const [requestStatus, setRequestStatus] = useState({ show: false, type: '', message: '', mechanic: '' });
  const [showServiceRequest, setShowServiceRequest] = useState(false);
  const [selectedMechanic, setSelectedMechanic] = useState(null);
  const navigate = useNavigate();

  const searchMechanics = async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    try {
      // Simple coordinates lookup for major Nigerian cities
      const cityCoordinates = {
        'lagos': { lat: 6.5244, lng: 3.3792 },
        'abuja': { lat: 9.0579, lng: 7.4951 },
        'kano': { lat: 12.0022, lng: 8.5919 },
        'ibadan': { lat: 7.3775, lng: 3.9470 },
        'port harcourt': { lat: 4.8156, lng: 7.0498 },
        'benin': { lat: 6.3350, lng: 5.6037 },
        'maiduguri': { lat: 11.8311, lng: 13.1510 },
        'zaria': { lat: 11.1115, lng: 7.7006 },
        'aba': { lat: 5.1066, lng: 7.3667 },
        'jos': { lat: 9.9280, lng: 8.8921 }
      };
      
      const city = searchQuery.toLowerCase();
      const coords = cityCoordinates[city] || cityCoordinates['lagos']; // Default to Lagos
      
      setUserLocation(coords);
      
      const response = await axios.get(`${API}/mechanics/search`, {
        params: {
          latitude: coords.lat,
          longitude: coords.lng,
          radius: parseInt(filters.radius),
          service: filters.service !== 'all' ? filters.service : undefined,
          tier: filters.tier !== 'all' ? filters.tier : undefined
        }
      });
      
      setMechanics(response.data.mechanics || []);
    } catch (error) {
      console.error('Error searching mechanics:', error);
      setMechanics([]);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceRequest = async (requestData) => {
    console.log('=== DIRECT API SUBMISSION START ===');
    console.log('Request Data:', JSON.stringify(requestData, null, 2));
    
    // Create a direct service request that exactly matches our successful curl tests
    const directRequestData = {
      customer_name: requestData.customer_name,
      customer_phone: requestData.customer_phone,
      customer_address: requestData.customer_address,
      service_type: requestData.service_type,
      description: requestData.description,
      location: {
        address: requestData.customer_address,
        coordinates: [6.5244, 3.3792] // Default Lagos coordinates
      },
      mechanic_id: requestData.mechanic_id
    };
    
    console.log('Direct API Data:', JSON.stringify(directRequestData, null, 2));
    
    try {
      // Make the request exactly like our successful curl tests
      const fullUrl = window.location.origin + '/api/service-requests';
      console.log('Making request to:', fullUrl);
      
      const response = await fetch(fullUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Cache-Control': 'no-cache'
        },
        body: JSON.stringify(directRequestData)
      });

      console.log('Response received:', response.status, response.statusText);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('API Error Response:', errorText);
        throw new Error(`API Error ${response.status}: ${errorText}`);
      }

      const successData = await response.json();
      console.log('✅ SUCCESS - API Response:', successData);
      console.log('=== DIRECT API SUBMISSION SUCCESS ===');
      
      // Show success notification with mechanic details
      setRequestStatus({
        show: true,
        type: 'success',
        message: `🎉 SUCCESS! Your request was sent to ${successData.mechanic_contact?.business_name || 'the mechanic'}. They will contact you at ${requestData.customer_phone} within 30 minutes.`,
        mechanic: successData.mechanic_contact?.business_name || 'Mechanic'
      });
      
      setShowServiceRequest(false);
      
      // Auto-hide after 10 seconds
      setTimeout(() => {
        setRequestStatus({ show: false, type: '', message: '', mechanic: '' });
      }, 10000);
      
    } catch (error) {
      console.error('=== DIRECT API SUBMISSION FAILED ===');
      console.error('Network Error:', error);
      
      // Show error with specific details
      setRequestStatus({
        show: true,
        type: 'error',
        message: `❌ SUBMISSION FAILED: ${error.message}. Please try again or contact support.`,
        mechanic: selectedMechanic?.business_name || 'Unknown'
      });
      
      // Auto-hide error after 15 seconds
      setTimeout(() => {
        setRequestStatus({ show: false, type: '', message: '', mechanic: '' });
      }, 15000);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <Wrench className="h-8 w-8 text-orange-600" />
              <span className="text-2xl font-bold text-gray-900">MechFinder</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <Link to="/search" className="text-gray-600 hover:text-orange-600 font-medium">Find Mechanic</Link>
              <Link to="/auth" className="text-gray-600 hover:text-orange-600 font-medium">Mechanic Login</Link>
              <Link to="/auth" className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 font-medium">Register Business</Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Success/Error Status */}
      {requestStatus.show && (
        <div className={`mx-4 mt-4 p-4 rounded-lg shadow-lg border-l-4 ${
          requestStatus.type === 'success' 
            ? 'bg-gradient-to-r from-green-100 to-green-200 border-green-500 text-green-800'
            : 'bg-gradient-to-r from-red-100 to-red-200 border-red-500 text-red-800'
        }`}>
          <div className="flex items-start justify-between">
            <div className="flex items-start">
              <div className={`rounded-full p-2 mr-3 ${
                requestStatus.type === 'success' ? 'bg-green-500 animate-bounce' : 'bg-red-500'
              }`}>
                {requestStatus.type === 'success' 
                  ? <MessageCircle className="h-5 w-5 text-white" />
                  : <AlertCircle className="h-5 w-5 text-white" />
                }
              </div>
              <div>
                <p className="font-bold text-lg">
                  {requestStatus.type === 'success' ? '✅ Request Sent Successfully!' : '❌ Request Failed'}
                </p>
                <p className="text-sm mt-1">{requestStatus.message}</p>
              </div>
            </div>
            <button 
              onClick={() => setRequestStatus({ show: false, type: '', message: '', mechanic: '' })}
              className="font-bold text-xl hover:opacity-75"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-orange-600 to-orange-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold mb-6">
                Get Your Car <span className="text-orange-200">Fixed Fast</span> in Nigeria
              </h1>
              <p className="text-xl mb-8 text-orange-100">
                Request professional automotive service from verified mechanics near you. 
                No registration needed - just tell us your car problem and get connected instantly.
              </p>
              
              <div className="bg-white p-6 rounded-xl shadow-lg">
                <h3 className="text-gray-900 text-lg font-semibold mb-4">Need a mechanic? Get help instantly!</h3>
                <div className="flex space-x-3 mb-4">
                  <Input
                    placeholder="Enter your location (e.g., Lagos, Abuja, Port Harcourt)"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && searchMechanics()}
                    className="flex-1 h-12 text-gray-900"
                  />
                  <Button 
                    onClick={() => searchMechanics()} 
                    className="h-12 px-8 bg-orange-600 hover:bg-orange-700"
                    disabled={loading}
                  >
                    {loading ? (
                      <div className="spinner mr-2" />
                    ) : (
                      <Search className="mr-2 h-5 w-5" />
                    )}
                    Find Mechanics
                  </Button>
                </div>
                <div className="flex items-center space-x-6 text-sm text-gray-600">
                  <div className="flex items-center">
                    <span className="text-red-600 mr-1">●</span>
                    No registration required
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 mr-1" />
                    Direct mechanic contact
                  </div>
                  <div className="flex items-center">
                    <span className="text-green-600 mr-1">⚡</span>
                    Fast response
                  </div>
                </div>
              </div>
            </div>
            
            <div className="hidden lg:block">
              <div className="grid grid-cols-1 gap-6">
                {/* Female Mechanic Image */}
                <img 
                  src="https://customer-assets.emergentagent.com/job_naijamech/artifacts/p0nwd4xe_Nigerian%20mechanic.jpeg" 
                  alt="Professional Nigerian Female Mechanic"
                  className="rounded-lg shadow-2xl h-64 w-full object-cover"
                />
                {/* Male Mechanic Image */}
                <img 
                  src="https://customer-assets.emergentagent.com/job_naijamech/artifacts/9dgtzp2s_IMG_5999.jpeg" 
                  alt="Professional Nigerian Male Mechanic"
                  className="rounded-lg shadow-2xl h-64 w-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-orange-600 mb-2">500+</div>
              <div className="text-gray-600">Verified Mechanics</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-orange-600 mb-2">50k+</div>
              <div className="text-gray-600">Cars Fixed</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-orange-600 mb-2">24/7</div>
              <div className="text-gray-600">Emergency Service</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search Results */}
      {loading ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <div className="spinner mx-auto mb-4" />
            <p className="text-gray-600">Searching for mechanics...</p>
          </div>
        </div>
      ) : mechanics.length > 0 ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">
            Found {mechanics.length} mechanics near {searchQuery}
          </h2>
          <div className="grid gap-6">
            {mechanics.map((mechanic) => (
              <MechanicCard 
                key={mechanic.id} 
                mechanic={mechanic} 
                onContact={() => {
                  // Navigate to simplified service request page
                  navigate(`/request-service?mechanic=${mechanic.id}&name=${encodeURIComponent(mechanic.business_name)}`);
                }}
                userLocation={userLocation}
              />
            ))}
          </div>
        </div>
      ) : searchQuery && !loading ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center bg-white rounded-xl p-12">
            <Wrench className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No mechanics found</h3>
            <p className="text-gray-600 mb-6">Try expanding your search radius or changing the location</p>
            <Button onClick={() => searchMechanics()} className="bg-orange-600 hover:bg-orange-700">
              Search Again
            </Button>
          </div>
        </div>
      ) : null}

      {/* Why Choose Us Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose MechFinder?</h2>
            <p className="text-xl text-gray-600">Connecting you with Nigeria's best automotive professionals</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Verified Professionals</h3>
              <p className="text-gray-600">All mechanics are background-checked and certified for quality service</p>
            </div>
            
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Location-Based</h3>
              <p className="text-gray-600">Find mechanics near you for quick and convenient service</p>
            </div>
            
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">24/7 Support</h3>
              <p className="text-gray-600">Emergency roadside assistance available round the clock</p>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Mechanics Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Meet Our Professional Mechanics</h2>
            <p className="text-xl text-gray-600">Skilled Nigerian automotive experts ready to serve you</p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Female Mechanic */}
            <div className="text-center">
              <div className="mb-6">
                <img 
                  src="https://customer-assets.emergentagent.com/job_naijamech/artifacts/p0nwd4xe_Nigerian%20mechanic.jpeg" 
                  alt="Professional Nigerian Female Mechanic"
                  className="rounded-lg shadow-xl mx-auto h-80 w-80 object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Expert Female Mechanics</h3>
              <p className="text-gray-600">
                Empowering women in automotive repair with professional skills and dedication to excellence
              </p>
            </div>

            {/* Male Mechanic */}
            <div className="text-center">
              <div className="mb-6">
                <img 
                  src="https://customer-assets.emergentagent.com/job_naijamech/artifacts/9dgtzp2s_IMG_5999.jpeg" 
                  alt="Professional Nigerian Male Mechanic"
                  className="rounded-lg shadow-xl mx-auto h-80 w-80 object-cover"
                />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Experienced Male Mechanics</h3>
              <p className="text-gray-600">
                Years of experience in automotive repair, bringing expertise and reliability to every job
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-orange-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Get Your Car Fixed?</h2>
          <p className="text-xl mb-8 text-orange-100">Join thousands of satisfied customers across Nigeria</p>
          <div className="space-x-4">
            <Button 
              onClick={() => navigate('/request-service')}
              className="bg-white text-orange-600 hover:bg-gray-100 px-8 py-3 text-lg"
            >
              Request Service Now
            </Button>
            <Button 
              onClick={() => navigate('/auth')}
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-orange-600 px-8 py-3 text-lg"
            >
              Join as Mechanic
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Mechanic Card Component
const MechanicCard = ({ mechanic, onContact, userLocation }) => {
  const getTierBadge = (tier) => {
    const badges = {
      'pro': { label: 'Pro', className: 'bg-orange-700 text-white' },
      'premium': { label: 'Premium', className: 'bg-orange-500 text-white' },
      'basic': { label: 'Basic', className: 'bg-gray-500 text-white' }
    };
    return badges[tier] || badges.basic;
  };

  const tierBadge = getTierBadge(mechanic.tier);

  return (
    <Card className="card-hover">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Profile Image */}
          <div className="flex-shrink-0">
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center">
              {mechanic.profile_image_url ? (
                <img 
                  src={mechanic.profile_image_url} 
                  alt={mechanic.business_name}
                  className="w-24 h-24 rounded-full object-cover"
                />
              ) : (
                <Wrench className="h-12 w-12 text-gray-400" />
              )}
            </div>
          </div>

          {/* Main Info */}
          <div className="flex-1 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-xl font-bold text-gray-900">{mechanic.business_name}</h3>
                  <Badge className={tierBadge.className}>{tierBadge.label}</Badge>
                  {mechanic.is_verified && (
                    <Badge variant="outline" className="text-green-600 border-green-600">
                      <Shield className="h-3 w-3 mr-1" />
                      Verified
                    </Badge>
                  )}
                </div>
                <p className="text-gray-600">{mechanic.description}</p>
              </div>
            </div>

            {/* Location & Distance */}
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-1" />
                {mechanic.location?.address || 'Location not specified'}
              </div>
              {mechanic.distance && (
                <div className="flex items-center">
                  <span className="text-orange-600 font-semibold">{mechanic.distance} km away</span>
                </div>
              )}
            </div>

            {/* Rating & Experience */}
            <div className="flex items-center space-x-6 text-sm">
              {mechanic.rating > 0 && (
                <div className="flex items-center">
                  <Star className="h-4 w-4 text-yellow-400 mr-1" />
                  <span className="font-medium">{mechanic.rating}</span>
                  <span className="text-gray-500 ml-1">({mechanic.review_count || 0} reviews)</span>
                </div>
              )}
              {mechanic.years_experience && (
                <div className="flex items-center">
                  <Award className="h-4 w-4 text-blue-500 mr-1" />
                  <span>{mechanic.years_experience} years experience</span>
                </div>
              )}
            </div>

            {/* Services */}
            {mechanic.services && mechanic.services.length > 0 && (
              <div>
                <p className="text-sm text-gray-500 mb-2">Services:</p>
                <div className="flex flex-wrap gap-2">
                  {mechanic.services.slice(0, 4).map((service, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {service}
                    </Badge>
                  ))}
                  {mechanic.services.length > 4 && (
                    <Badge variant="outline" className="text-xs">
                      +{mechanic.services.length - 4} more
                    </Badge>
                  )}
                </div>
              </div>
            )}

            {/* Contact Button */}
            <div className="pt-2">
              <Button
                onClick={onContact}
                className="bg-orange-600 hover:bg-orange-700 text-white"
              >
                <MessageCircle className="h-4 w-4 mr-2" />
                Request Service
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Placeholder components - you'll need to implement these
const SearchPage = () => <div>Search Page - To be implemented</div>;
const PaymentSuccess = () => <div>Payment Success - To be implemented</div>;
const ServiceRequestsPage = () => <div>Service Requests - To be implemented</div>;

export default App;