import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { 
  Wrench, Users, FileText, DollarSign, MapPin, Phone, 
  MessageCircle, Search, Filter, Download, RefreshCw,
  Shield, Award, Clock, AlertCircle, CheckCircle, XCircle
} from 'lucide-react';

const AdminDashboard = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  
  // Data states
  const [stats, setStats] = useState({
    totalMechanics: 0,
    totalRequests: 0,
    pendingRequests: 0,
    totalRevenue: 0
  });
  const [mechanics, setMechanics] = useState([]);
  const [mechanicsByState, setMechanicsByState] = useState({});
  const [requests, setRequests] = useState([]);
  const [filteredRequests, setFilteredRequests] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  const navigate = useNavigate();

  // Simple admin authentication
  const handleAdminLogin = () => {
    // Simple password check - in production, use proper authentication
    if (adminPassword === 'mechfinder2024' || adminPassword === 'admin123') {
      setIsAuthenticated(true);
      localStorage.setItem('adminAuth', 'true');
      fetchAllData();
    } else {
      alert('❌ Invalid admin password');
    }
  };

  // Check if already authenticated
  useEffect(() => {
    const adminAuth = localStorage.getItem('adminAuth');
    if (adminAuth === 'true') {
      setIsAuthenticated(true);
      fetchAllData();
    }
  }, []);

  // Fetch all data
  const fetchAllData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        fetchMechanics(),
        fetchServiceRequests(),
        fetchStats()
      ]);
    } catch (error) {
      console.error('Error fetching admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch mechanics and organize by state
  const fetchMechanics = async () => {
    try {
      const response = await axios.get('/api/mechanics/search', {
        params: {
          latitude: 6.5244,
          longitude: 3.3792,
          radius: 10000 // Large radius to get all mechanics
        }
      });
      
      const mechanicsData = response.data.mechanics || [];
      setMechanics(mechanicsData);
      
      // Organize mechanics by state
      const byState = {};
      mechanicsData.forEach(mechanic => {
        const state = mechanic.location?.state || 'Unknown State';
        if (!byState[state]) {
          byState[state] = [];
        }
        byState[state].push(mechanic);
      });
      
      setMechanicsByState(byState);
    } catch (error) {
      console.error('Error fetching mechanics:', error);
    }
  };

  // Fetch service requests
  const fetchServiceRequests = async () => {
    try {
      const response = await axios.get('/api/service-requests/all');
      const requestsData = response.data.requests || [];
      setRequests(requestsData);
      setFilteredRequests(requestsData);
    } catch (error) {
      console.error('Error fetching service requests:', error);
    }
  };

  // Fetch dashboard stats
  const fetchStats = async () => {
    try {
      // Calculate stats from existing data
      const mechanicsResponse = await axios.get('/api/mechanics/search', {
        params: { latitude: 6.5244, longitude: 3.3792, radius: 10000 }
      });
      const requestsResponse = await axios.get('/api/service-requests/all');
      
      const mechanicsData = mechanicsResponse.data.mechanics || [];
      const requestsData = requestsResponse.data.requests || [];
      
      const pendingCount = requestsData.filter(req => req.status === 'pending').length;
      
      setStats({
        totalMechanics: mechanicsData.length,
        totalRequests: requestsData.length,
        pendingRequests: pendingCount,
        totalRevenue: 0 // Would need payment data
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  // Filter requests
  useEffect(() => {
    let filtered = requests;
    
    if (searchTerm) {
      filtered = filtered.filter(req => 
        req.customer_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        req.service_type?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        req.customer_address?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(req => req.status === statusFilter);
    }
    
    setFilteredRequests(filtered);
  }, [requests, searchTerm, statusFilter]);

  // Update service request status
  const updateRequestStatus = async (requestId, newStatus) => {
    try {
      const response = await axios.put(`/api/service-requests/${requestId}/status`, {
        status: newStatus
      });
      
      // Update local state
      setRequests(prevRequests => 
        prevRequests.map(req => 
          req.id === requestId ? { ...req, status: newStatus } : req
        )
      );
      
      // Refresh stats
      await fetchStats();
      
      console.log('Status updated successfully:', response.data);
    } catch (error) {
      console.error('Error updating status:', error);
      alert('Failed to update status. Please try again.');
    }
  };

  // Assign request to mechanic
  const assignRequestToMechanic = async (requestId, mechanicId) => {
    try {
      const response = await axios.post('/api/admin/assign-request', {
        request_id: requestId,
        mechanic_id: mechanicId
      });
      
      // Update local state
      setRequests(prevRequests => 
        prevRequests.map(req => 
          req.id === requestId ? { ...req, status: 'assigned', mechanic_id: mechanicId } : req
        )
      );
      
      // Refresh stats
      await fetchStats();
      
      console.log('Assignment successful:', response.data);
      alert(`Request assigned successfully to ${response.data.mechanic_name}`);
    } catch (error) {
      console.error('Error assigning request:', error);
      alert(error.response?.data?.detail || 'Failed to assign request. Please try again.');
    }
  };

  // Logout
  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('adminAuth');
    setAdminPassword('');
    navigate('/');
  };

  // Login screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Wrench className="h-8 w-8 text-orange-600" />
              <span className="text-2xl font-bold text-gray-900">MechFinder</span>
            </div>
            <CardTitle>Admin Access</CardTitle>
            <CardDescription>Enter admin password to access dashboard</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Input
                type="password"
                placeholder="Admin password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAdminLogin()}
              />
            </div>
            <Button 
              onClick={handleAdminLogin} 
              className="w-full bg-orange-600 hover:bg-orange-700"
            >
              Access Dashboard
            </Button>
            <div className="text-sm text-gray-500 text-center">
              <p>Test passwords: <code>mechfinder2024</code> or <code>admin123</code></p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Wrench className="h-8 w-8 text-orange-600" />
                <span className="text-2xl font-bold text-gray-900">MechFinder Admin</span>
              </div>
              <Badge className="bg-green-100 text-green-800">Admin Panel</Badge>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                onClick={fetchAllData}
                variant="outline"
                size="sm"
                disabled={loading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Button onClick={() => navigate('/')} variant="outline" size="sm">
                ← Back to Site
              </Button>
              <Button onClick={handleLogout} variant="outline" size="sm">
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Mechanics</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalMechanics}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <FileText className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Requests</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalRequests}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Clock className="h-8 w-8 text-orange-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Pending Requests</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.pendingRequests}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Revenue</p>
                  <p className="text-2xl font-bold text-gray-900">₦{stats.totalRevenue.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="mechanics">Mechanics by State</TabsTrigger>
            <TabsTrigger value="requests">Service Requests</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Requests */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Service Requests</CardTitle>
                  <CardDescription>Last 5 service requests</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {requests.slice(-5).reverse().map((request, index) => (
                      <div key={request.id || index} className="flex items-center justify-between border-b pb-2">
                        <div>
                          <p className="font-medium">{request.customer_name || 'Anonymous'}</p>
                          <p className="text-sm text-gray-600">{request.service_type || 'General Service'}</p>
                          <p className="text-xs text-gray-500">{request.location?.preferred_city}, {request.location?.preferred_state}</p>
                        </div>
                        <Badge variant={
                          request.status === 'pending' ? 'secondary' :
                          request.status === 'completed' ? 'default' :
                          'outline'
                        }>
                          {request.status || 'pending'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* State Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle>Mechanics by State</CardTitle>
                  <CardDescription>Distribution across Nigerian states</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(mechanicsByState)
                      .sort(([,a], [,b]) => b.length - a.length)
                      .slice(0, 8)
                      .map(([state, stateData]) => (
                      <div key={state} className="flex items-center justify-between">
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 text-orange-600 mr-2" />
                          <span className="font-medium">{state}</span>
                        </div>
                        <Badge variant="outline">{stateData.length} mechanics</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Mechanics by State Tab */}
          <TabsContent value="mechanics" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Mechanics Organized by State</CardTitle>
                <CardDescription>
                  All registered mechanics grouped by their location state
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {Object.entries(mechanicsByState)
                    .sort(([,a], [,b]) => b.length - a.length)
                    .map(([state, stateData]) => (
                    <div key={state}>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                        <MapPin className="h-5 w-5 text-orange-600 mr-2" />
                        {state}
                        <Badge variant="outline" className="ml-2">
                          {stateData.length} mechanics
                        </Badge>
                      </h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {stateData.map((mechanic, index) => (
                          <Card key={mechanic.id || index} className="border-l-4 border-l-orange-500">
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between mb-2">
                                <h4 className="font-medium text-gray-900">{mechanic.business_name}</h4>
                                <Badge className={
                                  mechanic.tier === 'pro' ? 'bg-orange-700' :
                                  mechanic.tier === 'premium' ? 'bg-orange-500' :
                                  'bg-gray-500'
                                }>
                                  {mechanic.tier?.toUpperCase() || 'BASIC'}
                                </Badge>
                              </div>
                              
                              <div className="space-y-1 text-sm text-gray-600">
                                <div className="flex items-center">
                                  <Phone className="h-3 w-3 mr-1" />
                                  {mechanic.contact_info?.phone || 'No phone'}
                                </div>
                                <div className="flex items-center">
                                  <MapPin className="h-3 w-3 mr-1" />
                                  {mechanic.location?.address || 'No address'}
                                </div>
                                {mechanic.years_experience && (
                                  <div className="flex items-center">
                                    <Award className="h-3 w-3 mr-1" />
                                    {mechanic.years_experience} years experience
                                  </div>
                                )}
                                {mechanic.is_verified && (
                                  <div className="flex items-center text-green-600">
                                    <Shield className="h-3 w-3 mr-1" />
                                    Verified
                                  </div>
                                )}
                              </div>
                              
                              {mechanic.services && mechanic.services.length > 0 && (
                                <div className="mt-2">
                                  <div className="flex flex-wrap gap-1">
                                    {mechanic.services.slice(0, 3).map((service, idx) => (
                                      <Badge key={idx} variant="outline" className="text-xs">
                                        {service}
                                      </Badge>
                                    ))}
                                    {mechanic.services.length > 3 && (
                                      <Badge variant="outline" className="text-xs">
                                        +{mechanic.services.length - 3}
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                
                {Object.keys(mechanicsByState).length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No mechanics registered yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Service Requests Tab */}
          <TabsContent value="requests" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Service Requests Management</CardTitle>
                <CardDescription>View and manage all service requests</CardDescription>
              </CardHeader>
              <CardContent>
                {/* Filters */}
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <div className="flex-1">
                    <Input
                      placeholder="Search requests..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
                  >
                    <option value="all">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="accepted">Accepted</option>
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                {/* Requests Table */}
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Customer
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Service
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Location
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Assigned Mechanic
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredRequests.map((request, index) => (
                        <tr key={request.id || index} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900">
                                {request.customer_name || 'Anonymous'}
                              </div>
                              <div className="text-sm text-gray-500">
                                {request.customer_phone || 'No phone'}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {request.service_type || 'General Service'}
                            </div>
                            <div className="text-sm text-gray-500 max-w-xs truncate">
                              {request.description || 'No description'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {request.location?.preferred_city}, {request.location?.preferred_state}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {request.mechanic_id ? (
                              <div>
                                <Badge variant="outline" className="text-green-600">
                                  Assigned
                                </Badge>
                                <p className="text-xs text-gray-500 mt-1">
                                  Mechanic ID: {request.mechanic_id.substring(0, 8)}...
                                </p>
                              </div>
                            ) : (
                              <select
                                onChange={(e) => {
                                  if (e.target.value) {
                                    assignRequestToMechanic(request.id, e.target.value);
                                    e.target.value = ''; // Reset dropdown
                                  }
                                }}
                                className="px-2 py-1 border border-gray-300 rounded text-xs focus:ring-orange-500 focus:border-orange-500"
                              >
                                <option value="">Assign Mechanic</option>
                                {Object.entries(mechanicsByState).map(([state, stateData]) => 
                                  stateData
                                    .filter(mechanic => request.location?.preferred_state === state)
                                    .map(mechanic => (
                                      <option key={mechanic.id} value={mechanic.user_id || mechanic.id}>
                                        {mechanic.business_name} ({mechanic.tier})
                                      </option>
                                    ))
                                )}
                              </select>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <Badge variant={
                              request.status === 'pending' ? 'secondary' :
                              request.status === 'assigned' ? 'outline' :
                              request.status === 'accepted' ? 'outline' :
                              request.status === 'in_progress' ? 'outline' :
                              request.status === 'completed' ? 'default' :
                              request.status === 'cancelled' ? 'destructive' :
                              'secondary'
                            }>
                              {request.status || 'pending'}
                            </Badge>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {request.created_at ? new Date(request.created_at).toLocaleDateString() : 'Unknown'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <select
                              value={request.status || 'pending'}
                              onChange={(e) => updateRequestStatus(request.id, e.target.value)}
                              className="px-3 py-1 border border-gray-300 rounded-md text-sm focus:ring-orange-500 focus:border-orange-500"
                            >
                              <option value="pending">Pending</option>
                              <option value="assigned">Assigned</option>
                              <option value="accepted">Accepted</option>
                              <option value="in_progress">In Progress</option>
                              <option value="completed">Completed</option>
                              <option value="cancelled">Cancelled</option>
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {filteredRequests.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No service requests found</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;