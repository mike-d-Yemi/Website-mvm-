import requests
import sys
import json
from datetime import datetime
import random

class FreshAuthenticationTester:
    def __init__(self, base_url="https://fixmeapp.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.tests_run = 0
        self.tests_passed = 0
        self.customer_token = None
        self.mechanic_token = None
        self.customer_data = None
        self.mechanic_data = None
        
        # Generate unique emails to avoid conflicts
        self.timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.random_id = random.randint(1000, 9999)

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=10)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    return True, response_data
                except:
                    return True, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {json.dumps(error_data, indent=2)}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_customer_registration(self):
        """Test customer registration with fresh email"""
        test_data = {
            "name": "John Adebayo",
            "email": f"john.adebayo.{self.timestamp}.{self.random_id}@gmail.com",
            "phone": "+234-801-123-4567",
            "password": "TestPassword123",
            "role": "customer"
        }
        
        success, response = self.run_test(
            "Customer Registration (Fresh Email)",
            "POST",
            "/auth/register",
            200,
            data=test_data
        )
        
        if success and 'token' in response and 'user' in response:
            self.customer_token = response['token']
            self.customer_data = response['user']
            self.customer_email = test_data['email']
            self.customer_password = test_data['password']
            print(f"   ✅ Customer registered successfully")
            print(f"   ✅ Email: {self.customer_email}")
            print(f"   ✅ User ID: {self.customer_data.get('id')}")
            print(f"   ✅ Role: {self.customer_data.get('role')}")
            return True
        return False

    def test_mechanic_registration(self):
        """Test mechanic registration with fresh email"""
        test_data = {
            "name": "Ahmed Garage Services",
            "email": f"ahmed.garage.{self.timestamp}.{self.random_id}@gmail.com",
            "phone": "+234-802-987-6543",
            "password": "MechanicPass456",
            "role": "mechanic"
        }
        
        success, response = self.run_test(
            "Mechanic Registration (Fresh Email)",
            "POST",
            "/auth/register",
            200,
            data=test_data
        )
        
        if success and 'token' in response and 'user' in response:
            self.mechanic_token = response['token']
            self.mechanic_data = response['user']
            self.mechanic_email = test_data['email']
            self.mechanic_password = test_data['password']
            print(f"   ✅ Mechanic registered successfully")
            print(f"   ✅ Email: {self.mechanic_email}")
            print(f"   ✅ User ID: {self.mechanic_data.get('id')}")
            print(f"   ✅ Role: {self.mechanic_data.get('role')}")
            return True
        return False

    def test_customer_login(self):
        """Test customer login with registered credentials"""
        if not hasattr(self, 'customer_email'):
            print("❌ No customer email available for login test")
            return False
            
        test_data = {
            "email": self.customer_email,
            "password": self.customer_password
        }
        
        success, response = self.run_test(
            "Customer Login",
            "POST",
            "/auth/login",
            200,
            data=test_data
        )
        
        if success and 'token' in response and 'user' in response:
            print(f"   ✅ Customer login successful")
            print(f"   ✅ Role: {response['user'].get('role')}")
            return True
        return False

    def test_mechanic_login(self):
        """Test mechanic login with registered credentials"""
        if not hasattr(self, 'mechanic_email'):
            print("❌ No mechanic email available for login test")
            return False
            
        test_data = {
            "email": self.mechanic_email,
            "password": self.mechanic_password
        }
        
        success, response = self.run_test(
            "Mechanic Login",
            "POST",
            "/auth/login",
            200,
            data=test_data
        )
        
        if success and 'token' in response and 'user' in response:
            print(f"   ✅ Mechanic login successful")
            print(f"   ✅ Role: {response['user'].get('role')}")
            return True
        return False

def main():
    print("🚀 Starting Fresh Authentication Flow Tests")
    print("Testing with unique email addresses to avoid conflicts")
    print("=" * 60)
    
    tester = FreshAuthenticationTester()
    
    # Test sequence
    tests = [
        ("Customer Registration", tester.test_customer_registration),
        ("Mechanic Registration", tester.test_mechanic_registration),
        ("Customer Login", tester.test_customer_login),
        ("Mechanic Login", tester.test_mechanic_login),
    ]
    
    # Run all tests
    for test_name, test_func in tests:
        try:
            test_func()
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {str(e)}")
    
    # Print final results
    print("\n" + "=" * 60)
    print(f"📊 FRESH AUTHENTICATION TEST RESULTS")
    print(f"Tests Run: {tester.tests_run}")
    print(f"Tests Passed: {tester.tests_passed}")
    print(f"Tests Failed: {tester.tests_run - tester.tests_passed}")
    print(f"Success Rate: {(tester.tests_passed/tester.tests_run)*100:.1f}%")
    
    if tester.tests_passed == tester.tests_run:
        print("\n🎉 All fresh authentication tests passed!")
        return 0
    else:
        print("\n⚠️  Some authentication tests failed. Check the details above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())