#!/usr/bin/env python3

import requests
import json
from datetime import datetime

def debug_assignment_issue():
    """Debug the assignment issue step by step"""
    base_url = "https://fixmeapp.preview.emergentagent.com"
    api_url = f"{base_url}/api"
    
    print("🔍 DEBUGGING ASSIGNMENT ISSUE")
    print("=" * 50)
    
    # Step 1: Create a test service request
    print("\n1. Creating test service request...")
    request_data = {
        "customer_name": "Debug Test Customer",
        "customer_phone": "+234-801-DEBUG-001",
        "customer_address": "Debug Test Address, Lagos",
        "service_type": "Engine Repair",
        "description": "Debug assignment issue test",
        "location": {
            "address": "Debug Test Address, Lagos",
            "latitude": 6.5244,
            "longitude": 3.3792,
            "state": "Lagos",
            "lga": "Lagos Island"
        }
    }
    
    response = requests.post(f"{api_url}/service-requests", json=request_data)
    if response.status_code != 200:
        print(f"❌ Failed to create request: {response.status_code}")
        return
    
    request_id = response.json()['request']['id']
    print(f"✅ Created request: {request_id}")
    
    # Step 2: Find a mechanic
    print("\n2. Finding available mechanic...")
    response = requests.get(f"{api_url}/mechanics/search?latitude=6.5244&longitude=3.3792&radius=100")
    if response.status_code != 200:
        print(f"❌ Failed to search mechanics: {response.status_code}")
        return
    
    mechanics = response.json().get('mechanics', [])
    if not mechanics:
        print("❌ No mechanics found")
        return
    
    mechanic = mechanics[0]
    mechanic_profile_id = mechanic['id']
    mechanic_user_id = mechanic.get('user_id')
    business_name = mechanic.get('business_name', 'Unknown')
    
    print(f"✅ Found mechanic: {business_name}")
    print(f"   - Profile ID: {mechanic_profile_id}")
    print(f"   - User ID: {mechanic_user_id}")
    
    # Step 3: Assign request to mechanic
    print("\n3. Assigning request to mechanic...")
    assignment_data = {"mechanic_id": mechanic_profile_id}
    response = requests.put(f"{api_url}/service-requests/{request_id}/assign-mechanic", json=assignment_data)
    if response.status_code != 200:
        print(f"❌ Failed to assign: {response.status_code} - {response.text}")
        return
    
    print(f"✅ Assignment successful")
    print(f"   Response: {response.json()}")
    
    # Step 4: Check if request appears in admin dashboard
    print("\n4. Checking admin dashboard...")
    response = requests.get(f"{api_url}/service-requests/all")
    if response.status_code != 200:
        print(f"❌ Failed to get admin requests: {response.status_code}")
        return
    
    admin_requests = response.json().get('requests', [])
    assigned_request = None
    for req in admin_requests:
        if req.get('id') == request_id:
            assigned_request = req
            break
    
    if assigned_request:
        print(f"✅ Request found in admin dashboard")
        print(f"   - Status: {assigned_request.get('status')}")
        print(f"   - Mechanic ID: {assigned_request.get('mechanic_id')}")
    else:
        print(f"❌ Request NOT found in admin dashboard")
        return
    
    # Step 5: Check mechanic dashboard using user_id
    print(f"\n5. Checking mechanic dashboard (user_id: {mechanic_user_id})...")
    response = requests.get(f"{api_url}/mechanics/{mechanic_user_id}/requests")
    if response.status_code != 200:
        print(f"❌ Failed to get mechanic requests: {response.status_code} - {response.text}")
        return
    
    mechanic_requests = response.json().get('requests', [])
    found_request = None
    for req in mechanic_requests:
        if req.get('id') == request_id:
            found_request = req
            break
    
    if found_request:
        print(f"✅ Request found in mechanic dashboard")
        print(f"   - Status: {found_request.get('status')}")
        print(f"   - Customer: {found_request.get('customer_name')}")
    else:
        print(f"❌ Request NOT found in mechanic dashboard")
        print(f"   - Total requests in mechanic dashboard: {len(mechanic_requests)}")
        if mechanic_requests:
            print(f"   - Request IDs in dashboard: {[req.get('id') for req in mechanic_requests]}")
    
    # Step 6: Debug - Check what mechanic_id is stored in the service request
    print(f"\n6. Debug - Checking stored mechanic_id...")
    print(f"   - Assigned mechanic_id in service request: {assigned_request.get('mechanic_id')}")
    print(f"   - Mechanic profile_id: {mechanic_profile_id}")
    print(f"   - Mechanic user_id: {mechanic_user_id}")
    print(f"   - Match profile_id? {assigned_request.get('mechanic_id') == mechanic_profile_id}")
    
    # Step 7: Check mechanic profile to verify ID mapping
    print(f"\n7. Verifying mechanic profile ID mapping...")
    response = requests.get(f"{api_url}/mechanics/{mechanic_user_id}/profile")
    if response.status_code == 200:
        profile = response.json().get('profile', {})
        profile_id_from_profile = profile.get('id')
        print(f"   - Profile ID from profile endpoint: {profile_id_from_profile}")
        print(f"   - Match with search result? {profile_id_from_profile == mechanic_profile_id}")
    else:
        print(f"   ❌ Failed to get profile: {response.status_code}")

if __name__ == "__main__":
    debug_assignment_issue()