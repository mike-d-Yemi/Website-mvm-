#!/usr/bin/env python3
"""
FOCUSED SERVICE REQUEST TESTING
Based on user report: Service requests from UI form are not working/not appearing in admin dashboard
"""

import requests
import json
import sys
from datetime import datetime

class ServiceRequestFocusedTester:
    def __init__(self, base_url="https://fixmeapp.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.tests_run = 0
        self.tests_passed = 0
        self.created_request_id = None

    def log_test(self, name, success, details=""):
        """Log test results"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name}")
            if details:
                print(f"   {details}")
        else:
            print(f"❌ {name}")
            if details:
                print(f"   {details}")

    def test_mechanics_loading_for_dropdown(self):
        """Test that mechanics are loading properly for the dropdown"""
        print("\n🔍 TESTING: Mechanics Loading for Dropdown")
        
        try:
            # Test mechanic search endpoint (used by frontend dropdown)
            url = f"{self.api_url}/mechanics/search"
            params = {
                "latitude": 6.5244,  # Lagos coordinates
                "longitude": 3.3792,
                "radius": 1000  # Large radius to get all mechanics
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                mechanics = data.get('mechanics', [])
                total = data.get('total', 0)
                
                if len(mechanics) > 0:
                    self.log_test(
                        "Mechanics Loading for Dropdown", 
                        True, 
                        f"Found {len(mechanics)} mechanics available for selection"
                    )
                    
                    # Show sample mechanics for verification
                    print("   📋 Sample mechanics available:")
                    for i, mechanic in enumerate(mechanics[:5]):  # Show first 5
                        business_name = mechanic.get('business_name', 'Unknown')
                        tier = mechanic.get('tier', 'unknown')
                        location = mechanic.get('location', {})
                        city = location.get('city', 'Unknown')
                        state = location.get('state', 'Unknown')
                        print(f"      {i+1}. {business_name} ({tier}) - {city}, {state}")
                    
                    if len(mechanics) > 5:
                        print(f"      ... and {len(mechanics) - 5} more mechanics")
                    
                    return True, mechanics
                else:
                    self.log_test(
                        "Mechanics Loading for Dropdown", 
                        False, 
                        "No mechanics found - dropdown will be empty"
                    )
                    return False, []
            else:
                self.log_test(
                    "Mechanics Loading for Dropdown", 
                    False, 
                    f"API returned status {response.status_code}: {response.text}"
                )
                return False, []
                
        except Exception as e:
            self.log_test(
                "Mechanics Loading for Dropdown", 
                False, 
                f"Exception occurred: {str(e)}"
            )
            return False, []

    def test_service_request_creation(self, mechanics):
        """Test service request creation endpoint directly"""
        print("\n🔍 TESTING: Service Request Creation (POST /api/service-requests)")
        
        if not mechanics:
            self.log_test(
                "Service Request Creation", 
                False, 
                "No mechanics available for testing"
            )
            return False, None
        
        # Use the first available mechanic
        target_mechanic = mechanics[0]
        mechanic_id = target_mechanic['id']
        mechanic_name = target_mechanic.get('business_name', 'Unknown')
        
        print(f"   🎯 Testing with mechanic: {mechanic_name} (ID: {mechanic_id})")
        
        # Create realistic service request data
        timestamp = datetime.now().strftime('%H%M%S')
        service_request_data = {
            "mechanic_id": mechanic_id,
            "customer_name": f"Test Customer {timestamp}",
            "customer_phone": "+234-801-555-1234",
            "customer_address": "123 Test Street, Victoria Island, Lagos",
            "service_type": "Engine Repair",
            "description": "My car engine is making strange noises and needs urgent inspection. The problem started this morning.",
            "location": {
                "address": "123 Test Street, Victoria Island, Lagos",
                "latitude": 6.4281,
                "longitude": 3.4219,
                "state": "Lagos",
                "lga": "Lagos Island"
            }
        }
        
        try:
            url = f"{self.api_url}/service-requests"
            headers = {'Content-Type': 'application/json'}
            
            response = requests.post(url, json=service_request_data, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                # Extract request ID for later verification
                if 'request' in data and 'id' in data['request']:
                    self.created_request_id = data['request']['id']
                
                self.log_test(
                    "Service Request Creation", 
                    True, 
                    f"Request created successfully. Message: {data.get('message', 'No message')}"
                )
                
                # Verify response contains expected fields
                print("   📋 Response verification:")
                if 'request' in data:
                    print(f"      ✅ Request object present with ID: {data['request'].get('id', 'Missing')}")
                if 'mechanic_contact' in data:
                    contact = data['mechanic_contact']
                    print(f"      ✅ Mechanic contact: {contact.get('business_name', 'Unknown')} - {contact.get('phone', 'No phone')}")
                if 'whatsapp_notification' in data:
                    whatsapp = data['whatsapp_notification']
                    if whatsapp and 'whatsapp_url' in whatsapp:
                        print(f"      ✅ WhatsApp notification generated")
                    else:
                        print(f"      ⚠️  WhatsApp notification incomplete")
                
                return True, data
            else:
                error_text = response.text
                try:
                    error_data = response.json()
                    error_text = json.dumps(error_data, indent=2)
                except:
                    pass
                
                self.log_test(
                    "Service Request Creation", 
                    False, 
                    f"API returned status {response.status_code}: {error_text}"
                )
                return False, None
                
        except Exception as e:
            self.log_test(
                "Service Request Creation", 
                False, 
                f"Exception occurred: {str(e)}"
            )
            return False, None

    def test_service_request_retrieval_admin(self):
        """Test service request retrieval for admin dashboard"""
        print("\n🔍 TESTING: Service Request Retrieval (GET /api/service-requests/all)")
        
        try:
            url = f"{self.api_url}/service-requests/all"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                requests_list = data.get('requests', [])
                total = data.get('total', 0)
                
                self.log_test(
                    "Service Request Retrieval (Admin Dashboard)", 
                    True, 
                    f"Retrieved {len(requests_list)} service requests (total: {total})"
                )
                
                # Verify our created request appears in the list
                if self.created_request_id:
                    found_our_request = False
                    for req in requests_list:
                        if req.get('id') == self.created_request_id:
                            found_our_request = True
                            print(f"      ✅ Our test request found in admin dashboard!")
                            print(f"         Customer: {req.get('customer_name', 'Unknown')}")
                            print(f"         Service: {req.get('service_type', 'Unknown')}")
                            print(f"         Status: {req.get('status', 'Unknown')}")
                            print(f"         Created: {req.get('created_at', 'Unknown')}")
                            break
                    
                    if not found_our_request:
                        print(f"      ⚠️  Our test request (ID: {self.created_request_id}) not found in admin dashboard")
                        print(f"      🔍 This could indicate a sync issue between creation and retrieval")
                
                # Show sample requests for verification
                if len(requests_list) > 0:
                    print("   📋 Sample requests in admin dashboard:")
                    for i, req in enumerate(requests_list[:3]):  # Show first 3
                        customer = req.get('customer_name', 'Unknown')
                        service = req.get('service_type', 'Unknown')
                        status = req.get('status', 'Unknown')
                        created = req.get('created_at', 'Unknown')
                        print(f"      {i+1}. {customer} - {service} ({status}) - {created}")
                
                return True, requests_list
            else:
                error_text = response.text
                try:
                    error_data = response.json()
                    error_text = json.dumps(error_data, indent=2)
                except:
                    pass
                
                self.log_test(
                    "Service Request Retrieval (Admin Dashboard)", 
                    False, 
                    f"API returned status {response.status_code}: {error_text}"
                )
                return False, []
                
        except Exception as e:
            self.log_test(
                "Service Request Retrieval (Admin Dashboard)", 
                False, 
                f"Exception occurred: {str(e)}"
            )
            return False, []

    def test_service_request_filtering(self):
        """Test service request filtering by status"""
        print("\n🔍 TESTING: Service Request Filtering by Status")
        
        statuses_to_test = ['pending', 'accepted', 'in_progress', 'completed', 'cancelled']
        
        for status in statuses_to_test:
            try:
                url = f"{self.api_url}/service-requests/all"
                params = {'status': status}
                response = requests.get(url, params=params, timeout=10)
                
                if response.status_code == 200:
                    data = response.json()
                    requests_list = data.get('requests', [])
                    
                    print(f"   ✅ Status '{status}': {len(requests_list)} requests")
                    
                    # Verify all returned requests have the correct status
                    if requests_list:
                        wrong_status_count = 0
                        for req in requests_list:
                            if req.get('status') != status:
                                wrong_status_count += 1
                        
                        if wrong_status_count > 0:
                            print(f"      ⚠️  {wrong_status_count} requests have incorrect status")
                        else:
                            print(f"      ✅ All requests have correct status")
                else:
                    print(f"   ❌ Status '{status}': API returned {response.status_code}")
                    
            except Exception as e:
                print(f"   ❌ Status '{status}': Exception - {str(e)}")

    def test_complete_flow(self):
        """Test the complete flow: create service request → verify it appears in admin dashboard"""
        print("\n🔍 TESTING: Complete Flow (Create → Verify in Admin Dashboard)")
        
        # Step 1: Load mechanics
        mechanics_success, mechanics = self.test_mechanics_loading_for_dropdown()
        if not mechanics_success:
            return False
        
        # Step 2: Create service request
        creation_success, creation_data = self.test_service_request_creation(mechanics)
        if not creation_success:
            return False
        
        # Step 3: Verify it appears in admin dashboard
        retrieval_success, requests_list = self.test_service_request_retrieval_admin()
        if not retrieval_success:
            return False
        
        # Step 4: Test filtering
        self.test_service_request_filtering()
        
        # Final verification
        if self.created_request_id:
            found_in_dashboard = any(req.get('id') == self.created_request_id for req in requests_list)
            if found_in_dashboard:
                self.log_test(
                    "Complete Flow Verification", 
                    True, 
                    "Service request successfully created and appears in admin dashboard"
                )
                return True
            else:
                self.log_test(
                    "Complete Flow Verification", 
                    False, 
                    "Service request created but does NOT appear in admin dashboard"
                )
                return False
        else:
            self.log_test(
                "Complete Flow Verification", 
                False, 
                "Could not track created request through the flow"
            )
            return False

def main():
    print("🚨 FOCUSED SERVICE REQUEST TESTING")
    print("🎯 INVESTIGATING: Service requests from UI form not working/not appearing in admin dashboard")
    print("=" * 80)
    
    tester = ServiceRequestFocusedTester()
    
    # Run the complete flow test
    flow_success = tester.test_complete_flow()
    
    # Print results
    print("\n" + "=" * 80)
    print(f"📊 SERVICE REQUEST FOCUSED TEST RESULTS")
    print(f"Tests Run: {tester.tests_run}")
    print(f"Tests Passed: {tester.tests_passed}")
    print(f"Tests Failed: {tester.tests_run - tester.tests_passed}")
    print(f"Success Rate: {(tester.tests_passed/tester.tests_run)*100:.1f}%")
    
    if flow_success:
        print("\n🎉 SERVICE REQUEST FUNCTIONALITY IS WORKING!")
        print("✅ Mechanics load properly for dropdown")
        print("✅ Service requests can be created via POST /api/service-requests")
        print("✅ Service requests appear in admin dashboard via GET /api/service-requests/all")
        print("✅ Complete flow from creation to admin dashboard works")
        return 0
    else:
        print("\n⚠️  SERVICE REQUEST ISSUES FOUND!")
        print("❌ There are problems with the service request functionality")
        print("❌ Check the detailed test output above for specific issues")
        return 1

if __name__ == "__main__":
    sys.exit(main())