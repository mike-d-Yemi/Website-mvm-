import requests
import sys
import json
from datetime import datetime
import time

class MechanicAdminTester:
    def __init__(self, base_url="https://fixmeapp.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.tests_run = 0
        self.tests_passed = 0
        self.test_results = []

    def log_result(self, test_name, success, details=""):
        """Log test result"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
        
        result = {
            "test": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        
        status = "✅ PASSED" if success else "❌ FAILED"
        print(f"{status} - {test_name}")
        if details:
            print(f"   Details: {details}")

    def make_request(self, method, endpoint, data=None, expected_status=200):
        """Make API request with error handling"""
        url = f"{self.api_url}{endpoint}"
        headers = {'Content-Type': 'application/json'}
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=15)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=15)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=headers, timeout=15)
            
            success = response.status_code == expected_status
            
            try:
                response_data = response.json()
            except:
                response_data = {"raw_response": response.text}
            
            return success, response_data, response.status_code
            
        except requests.exceptions.Timeout:
            return False, {"error": "Request timeout"}, 0
        except requests.exceptions.ConnectionError:
            return False, {"error": "Connection error"}, 0
        except Exception as e:
            return False, {"error": str(e)}, 0

    def test_mechanic_count_before_registration(self):
        """Test 1: Get current mechanic count via /api/mechanics/search"""
        print("\n🔍 TEST 1: Getting current mechanic count...")
        
        # Use Lagos coordinates to search for mechanics
        success, response, status_code = self.make_request(
            'GET', 
            '/mechanics/search?latitude=6.5244&longitude=3.3792&radius=1000'
        )
        
        if success:
            mechanics = response.get('mechanics', [])
            total_count = response.get('total', len(mechanics))
            
            self.initial_mechanic_count = total_count
            details = f"Found {total_count} mechanics before registration"
            self.log_result("Get Initial Mechanic Count", True, details)
            
            # Show some mechanic details
            if mechanics:
                print(f"   Sample mechanics found:")
                for i, mechanic in enumerate(mechanics[:3]):  # Show first 3
                    name = mechanic.get('business_name', 'Unknown')
                    tier = mechanic.get('tier', 'unknown')
                    state = mechanic.get('location', {}).get('state', 'unknown')
                    print(f"   {i+1}. {name} ({tier} tier) - {state}")
            
            return True, total_count
        else:
            self.log_result("Get Initial Mechanic Count", False, f"Status: {status_code}, Response: {response}")
            return False, 0

    def test_mechanic_registration(self):
        """Test 2: POST new mechanic registration via /api/auth/register"""
        print("\n🔍 TEST 2: Registering new mechanic 'Test Backend Mechanic'...")
        
        timestamp = datetime.now().strftime('%H%M%S')
        test_data = {
            "name": "Test Backend Mechanic",
            "email": f"testbackendmechanic{timestamp}@example.com",
            "phone": "+234-808-TEST-001",
            "password": "TestBackend123!",
            "role": "mechanic",
            "selected_tier": "basic",
            "city": "Lagos",
            "state": "Lagos",
            "address": "Test Backend Address, Lagos State"
        }
        
        success, response, status_code = self.make_request(
            'POST', 
            '/auth/register', 
            data=test_data
        )
        
        if success:
            user_data = response.get('user', {})
            token = response.get('token', '')
            
            self.test_mechanic_id = user_data.get('id')
            self.test_mechanic_email = test_data['email']
            
            details = f"Registered mechanic ID: {self.test_mechanic_id}, Role: {user_data.get('role')}"
            self.log_result("Register Test Backend Mechanic", True, details)
            
            print(f"   ✅ Mechanic registered successfully")
            print(f"   ✅ User ID: {self.test_mechanic_id}")
            print(f"   ✅ Email: {self.test_mechanic_email}")
            print(f"   ✅ Role: {user_data.get('role')}")
            print(f"   ✅ Token received: {token[:20]}...")
            
            return True, response
        else:
            self.log_result("Register Test Backend Mechanic", False, f"Status: {status_code}, Response: {response}")
            return False, {}

    def test_mechanic_count_after_registration(self):
        """Test 3: Verify mechanic count increases after registration"""
        print("\n🔍 TEST 3: Verifying mechanic count increased...")
        
        # Wait a moment for database consistency
        time.sleep(2)
        
        success, response, status_code = self.make_request(
            'GET', 
            '/mechanics/search?latitude=6.5244&longitude=3.3792&radius=1000'
        )
        
        if success:
            mechanics = response.get('mechanics', [])
            new_total_count = response.get('total', len(mechanics))
            
            count_increased = new_total_count > self.initial_mechanic_count
            increase_amount = new_total_count - self.initial_mechanic_count
            
            details = f"Before: {self.initial_mechanic_count}, After: {new_total_count}, Increase: {increase_amount}"
            self.log_result("Verify Mechanic Count Increase", count_increased, details)
            
            if count_increased:
                print(f"   ✅ Mechanic count increased from {self.initial_mechanic_count} to {new_total_count}")
                print(f"   ✅ New mechanics added: {increase_amount}")
                
                # Try to find our newly registered mechanic
                test_mechanic_found = False
                for mechanic in mechanics:
                    if mechanic.get('business_name') == 'Test Backend Mechanic':
                        test_mechanic_found = True
                        print(f"   ✅ Found our test mechanic in search results")
                        print(f"   ✅ Mechanic tier: {mechanic.get('tier')}")
                        print(f"   ✅ Mechanic location: {mechanic.get('location', {}).get('state')}")
                        break
                
                if not test_mechanic_found:
                    print(f"   ⚠️  Test mechanic not found in search results (may need time to index)")
                
            else:
                print(f"   ❌ Mechanic count did not increase: {self.initial_mechanic_count} -> {new_total_count}")
            
            return count_increased, new_total_count
        else:
            self.log_result("Verify Mechanic Count Increase", False, f"Status: {status_code}, Response: {response}")
            return False, 0

    def test_get_all_service_requests(self):
        """Test 4: GET all service requests via /api/service-requests/all"""
        print("\n🔍 TEST 4: Getting all service requests...")
        
        success, response, status_code = self.make_request(
            'GET', 
            '/service-requests/all'
        )
        
        if success:
            requests_data = response.get('requests', [])
            total_requests = len(requests_data)
            
            self.service_requests = requests_data
            details = f"Found {total_requests} service requests"
            self.log_result("Get All Service Requests", True, details)
            
            print(f"   ✅ Retrieved {total_requests} service requests")
            
            # Show status distribution
            status_counts = {}
            for req in requests_data:
                status = req.get('status', 'unknown')
                status_counts[status] = status_counts.get(status, 0) + 1
            
            print(f"   Status distribution:")
            for status, count in status_counts.items():
                print(f"   - {status}: {count}")
            
            # Store a request ID for status update testing
            if requests_data:
                self.test_request_id = requests_data[0].get('id')
                self.test_request_current_status = requests_data[0].get('status')
                print(f"   ✅ Selected request for status testing: {self.test_request_id}")
                print(f"   ✅ Current status: {self.test_request_current_status}")
            
            return True, requests_data
        else:
            self.log_result("Get All Service Requests", False, f"Status: {status_code}, Response: {response}")
            return False, []

    def test_service_request_status_updates(self):
        """Test 5: PUT status update via /api/service-requests/{id}/status"""
        print("\n🔍 TEST 5: Testing service request status updates...")
        
        if not hasattr(self, 'test_request_id') or not self.test_request_id:
            self.log_result("Test Status Updates", False, "No service request ID available for testing")
            return False
        
        # Test all status values: pending, assigned, in_progress, completed, cancelled
        test_statuses = ['assigned', 'in_progress', 'completed', 'cancelled', 'pending']
        successful_updates = 0
        
        for status in test_statuses:
            print(f"\n   Testing status update to: {status}")
            
            success, response, status_code = self.make_request(
                'PUT',
                f'/service-requests/{self.test_request_id}/status',
                data={'status': status}
            )
            
            if success:
                successful_updates += 1
                print(f"   ✅ Successfully updated to {status}")
                print(f"   ✅ Response: {response.get('message', 'No message')}")
                
                # Verify the update by checking the response
                if response.get('new_status') == status:
                    print(f"   ✅ Status confirmed in response: {status}")
                
            else:
                print(f"   ❌ Failed to update to {status}: Status {status_code}")
                print(f"   ❌ Error: {response}")
            
            # Small delay between updates
            time.sleep(1)
        
        all_successful = successful_updates == len(test_statuses)
        details = f"Successfully updated {successful_updates}/{len(test_statuses)} statuses"
        self.log_result("Test All Status Updates", all_successful, details)
        
        return all_successful, successful_updates

    def test_admin_dashboard_integration(self):
        """Test 6: Verify admin dashboard integration"""
        print("\n🔍 TEST 6: Testing admin dashboard integration...")
        
        # Test analytics overview (admin dashboard data)
        success1, response1, status_code1 = self.make_request(
            'GET', 
            '/data/analytics/overview'
        )
        
        dashboard_working = False
        if success1:
            summary = response1.get('summary', {})
            total_mechanics = summary.get('total_mechanics', 0)
            total_service_requests = summary.get('total_service_requests', 0)
            
            print(f"   ✅ Analytics overview retrieved")
            print(f"   ✅ Total mechanics in dashboard: {total_mechanics}")
            print(f"   ✅ Total service requests in dashboard: {total_service_requests}")
            
            # Check if our new mechanic is reflected
            if hasattr(self, 'initial_mechanic_count'):
                expected_min = self.initial_mechanic_count + 1
                if total_mechanics >= expected_min:
                    print(f"   ✅ Dashboard reflects new mechanic registration")
                    dashboard_working = True
                else:
                    print(f"   ⚠️  Dashboard may not reflect latest mechanic count")
            
            # Check tier distribution
            tier_distribution = response1.get('tier_distribution', [])
            if tier_distribution:
                print(f"   ✅ Tier distribution available:")
                for tier_data in tier_distribution:
                    tier_name = tier_data.get('_id', 'unknown')
                    count = tier_data.get('count', 0)
                    print(f"   - {tier_name}: {count} mechanics")
            
            dashboard_working = True
        
        # Test service requests in dashboard context
        success2, response2, status_code2 = self.make_request(
            'GET', 
            '/service-requests/all'
        )
        
        if success2:
            current_requests = response2.get('requests', [])
            print(f"   ✅ Service requests accessible for dashboard: {len(current_requests)}")
            
            # Check if status updates are reflected
            if hasattr(self, 'test_request_id'):
                updated_request = None
                for req in current_requests:
                    if req.get('id') == self.test_request_id:
                        updated_request = req
                        break
                
                if updated_request:
                    current_status = updated_request.get('status')
                    print(f"   ✅ Test request found with current status: {current_status}")
                    print(f"   ✅ Status changes are reflected in dashboard data")
        
        details = f"Analytics: {success1}, Service Requests: {success2}"
        self.log_result("Admin Dashboard Integration", dashboard_working and success2, details)
        
        return dashboard_working and success2

    def test_real_time_data_accuracy(self):
        """Test 7: Confirm real-time data accuracy"""
        print("\n🔍 TEST 7: Testing real-time data accuracy...")
        
        # Create a new service request to test real-time updates
        timestamp = datetime.now().strftime('%H%M%S')
        test_service_request = {
            "customer_name": f"Test Customer {timestamp}",
            "customer_phone": "+234-801-REAL-TIME",
            "customer_address": "Real-time Test Address, Lagos",
            "service_type": "Engine Repair",
            "description": "Testing real-time data accuracy for admin dashboard",
            "location": {
                "address": "Real-time Test Address, Lagos",
                "latitude": 6.5244,
                "longitude": 3.3792,
                "state": "Lagos",
                "lga": "Lagos Island"
            }
        }
        
        # Get count before creating request
        success_before, response_before, _ = self.make_request('GET', '/service-requests/all')
        count_before = len(response_before.get('requests', [])) if success_before else 0
        
        # Create new service request
        success_create, response_create, status_code_create = self.make_request(
            'POST',
            '/service-requests',
            data=test_service_request
        )
        
        if success_create:
            print(f"   ✅ Created test service request")
            new_request_id = response_create.get('request', {}).get('id')
            
            # Wait a moment for consistency
            time.sleep(2)
            
            # Get count after creating request
            success_after, response_after, _ = self.make_request('GET', '/service-requests/all')
            count_after = len(response_after.get('requests', [])) if success_after else 0
            
            count_increased = count_after > count_before
            print(f"   Service requests before: {count_before}, after: {count_after}")
            
            if count_increased:
                print(f"   ✅ Real-time data update confirmed - count increased")
                
                # Test immediate status update
                if new_request_id:
                    success_status, response_status, _ = self.make_request(
                        'PUT',
                        f'/service-requests/{new_request_id}/status',
                        data={'status': 'assigned'}
                    )
                    
                    if success_status:
                        print(f"   ✅ Status update successful")
                        
                        # Verify status change is immediately visible
                        success_verify, response_verify, _ = self.make_request('GET', '/service-requests/all')
                        if success_verify:
                            updated_requests = response_verify.get('requests', [])
                            for req in updated_requests:
                                if req.get('id') == new_request_id:
                                    if req.get('status') == 'assigned':
                                        print(f"   ✅ Status change immediately reflected in data")
                                        break
            
            details = f"Request count increased: {count_increased}, Before: {count_before}, After: {count_after}"
            self.log_result("Real-time Data Accuracy", count_increased, details)
            return count_increased
        else:
            self.log_result("Real-time Data Accuracy", False, f"Failed to create test request: {status_code_create}")
            return False

    def run_comprehensive_test(self):
        """Run all tests in sequence"""
        print("🚨 COMPREHENSIVE TESTING - MECHANIC REGISTRATION AND ADMIN STATUS MANAGEMENT")
        print("=" * 80)
        print("🎯 Testing Requirements:")
        print("1. Mechanic Registration System")
        print("2. Service Request Status Management") 
        print("3. Admin Dashboard Integration")
        print("=" * 80)
        
        # Initialize tracking variables
        self.initial_mechanic_count = 0
        self.test_mechanic_id = None
        self.test_request_id = None
        self.service_requests = []
        
        # Run tests in sequence
        test_sequence = [
            ("Get Current Mechanic Count", self.test_mechanic_count_before_registration),
            ("Register New Mechanic", self.test_mechanic_registration),
            ("Verify Count Increase", self.test_mechanic_count_after_registration),
            ("Get All Service Requests", self.test_get_all_service_requests),
            ("Test Status Updates", self.test_service_request_status_updates),
            ("Admin Dashboard Integration", self.test_admin_dashboard_integration),
            ("Real-time Data Accuracy", self.test_real_time_data_accuracy)
        ]
        
        for test_name, test_func in test_sequence:
            try:
                print(f"\n{'='*60}")
                test_func()
            except Exception as e:
                self.log_result(test_name, False, f"Exception: {str(e)}")
                print(f"❌ {test_name} failed with exception: {str(e)}")
        
        # Print comprehensive results
        self.print_final_results()

    def print_final_results(self):
        """Print comprehensive test results"""
        print("\n" + "="*80)
        print("📊 COMPREHENSIVE TEST RESULTS")
        print("="*80)
        
        print(f"Total Tests Run: {self.tests_run}")
        print(f"Tests Passed: {self.tests_passed}")
        print(f"Tests Failed: {self.tests_run - self.tests_passed}")
        print(f"Success Rate: {(self.tests_passed/self.tests_run)*100:.1f}%")
        
        print("\n📋 DETAILED RESULTS:")
        print("-" * 60)
        
        for result in self.test_results:
            status = "✅ PASSED" if result['success'] else "❌ FAILED"
            print(f"{status} - {result['test']}")
            if result['details']:
                print(f"   {result['details']}")
        
        # Critical requirements check
        print("\n🎯 CRITICAL REQUIREMENTS VERIFICATION:")
        print("-" * 50)
        
        mechanic_registration_working = any(r['test'] == 'Register Test Backend Mechanic' and r['success'] for r in self.test_results)
        count_increase_working = any(r['test'] == 'Verify Mechanic Count Increase' and r['success'] for r in self.test_results)
        status_updates_working = any(r['test'] == 'Test All Status Updates' and r['success'] for r in self.test_results)
        dashboard_working = any(r['test'] == 'Admin Dashboard Integration' and r['success'] for r in self.test_results)
        
        print(f"✅ Mechanic Registration: {'WORKING' if mechanic_registration_working else 'FAILED'}")
        print(f"✅ Mechanic Count Increase: {'WORKING' if count_increase_working else 'FAILED'}")
        print(f"✅ Status Updates (all 5 statuses): {'WORKING' if status_updates_working else 'FAILED'}")
        print(f"✅ Admin Dashboard Integration: {'WORKING' if dashboard_working else 'FAILED'}")
        
        # Overall assessment
        critical_working = mechanic_registration_working and count_increase_working and status_updates_working
        
        print("\n🏆 FINAL ASSESSMENT:")
        print("="*50)
        
        if critical_working:
            print("🎉 ALL CRITICAL REQUIREMENTS WORKING!")
            print("✅ Mechanic registration increases count")
            print("✅ Admin can change service request statuses")
            print("✅ All status options work: cancelled, assigned, in_progress, completed")
            if dashboard_working:
                print("✅ Admin dashboard integration confirmed")
            return True
        else:
            print("⚠️  CRITICAL ISSUES FOUND:")
            if not mechanic_registration_working:
                print("❌ Mechanic registration system not working")
            if not count_increase_working:
                print("❌ Mechanic count not increasing after registration")
            if not status_updates_working:
                print("❌ Service request status updates not working")
            if not dashboard_working:
                print("❌ Admin dashboard integration issues")
            return False

def main():
    tester = MechanicAdminTester()
    success = tester.run_comprehensive_test()
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())