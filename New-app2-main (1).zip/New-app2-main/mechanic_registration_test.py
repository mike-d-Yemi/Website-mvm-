import requests
import sys
import json
from datetime import datetime

class MechanicRegistrationFlowTester:
    def __init__(self, base_url="https://fixmeapp.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.mechanic_id = None
        self.tests_run = 0
        self.tests_passed = 0
        self.errors = []

    def log_result(self, test_name, success, details=""):
        """Log test results"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {test_name} - PASSED")
        else:
            print(f"❌ {test_name} - FAILED: {details}")
            self.errors.append(f"{test_name}: {details}")
        
        if details:
            print(f"   Details: {details}")
        print()

    def test_specific_mechanic_registration(self):
        """Test the exact mechanic registration from review request"""
        registration_data = {
            "name": "Test Garage Nigeria",
            "email": "testgarage@gmail.com", 
            "phone": "+234-809-123-4567",
            "role": "mechanic",
            "password": "TestMechanic123"
        }

        try:
            response = requests.post(
                f"{self.api_url}/auth/register",
                json=registration_data,
                timeout=10
            )
            
            success = response.status_code == 200
            details = f"Status: {response.status_code}"
            
            if success:
                data = response.json()
                self.token = data.get('token')
                self.user_data = data.get('user')
                details += f", User ID: {self.user_data.get('id')}, Role: {self.user_data.get('role')}"
                
                # Verify JWT token structure
                if self.token and '.' in self.token:
                    details += ", JWT token format valid"
                else:
                    details += ", JWT token format invalid"
                    success = False
                    
            else:
                try:
                    error_data = response.json()
                    details += f", Error: {error_data.get('detail', 'Unknown error')}"
                except:
                    details += f", Raw response: {response.text[:200]}"
            
            self.log_result("Specific Mechanic Registration (Test Garage Nigeria)", success, details)
            return success
            
        except Exception as e:
            self.log_result("Specific Mechanic Registration (Test Garage Nigeria)", False, str(e))
            return False

    def test_mechanic_login_flow(self):
        """Test mechanic login with registered credentials"""
        if not self.user_data:
            self.log_result("Mechanic Login Flow", False, "No user data from registration")
            return False

        login_data = {
            "email": "testgarage@gmail.com",
            "password": "TestMechanic123"
        }

        try:
            response = requests.post(
                f"{self.api_url}/auth/login",
                json=login_data,
                timeout=10
            )
            
            success = response.status_code == 200
            details = f"Status: {response.status_code}"
            
            if success:
                data = response.json()
                login_token = data.get('token')
                login_user = data.get('user', {})
                
                # Verify role is mechanic
                if login_user.get('role') == 'mechanic':
                    details += f", Role verified: mechanic"
                else:
                    details += f", Role mismatch: {login_user.get('role')}"
                    success = False
                
                # Update token for subsequent tests
                self.token = login_token
                details += f", Token updated for dashboard access"
                
            else:
                try:
                    error_data = response.json()
                    details += f", Error: {error_data.get('detail', 'Unknown error')}"
                except:
                    details += f", Raw response: {response.text[:200]}"
            
            self.log_result("Mechanic Login Flow", success, details)
            return success
            
        except Exception as e:
            self.log_result("Mechanic Login Flow", False, str(e))
            return False

    def test_tier_pricing_for_dashboard(self):
        """Test tier pricing endpoint for mechanic dashboard"""
        try:
            response = requests.get(f"{self.api_url}/payments/tiers", timeout=10)
            
            success = response.status_code == 200
            details = f"Status: {response.status_code}"
            
            if success:
                data = response.json()
                tiers = data.get('tiers', [])
                details += f", Found {len(tiers)} tiers"
                
                # Check for specific pricing: ₦200, ₦500, ₦800/month
                expected_tiers = {
                    'basic': 200,
                    'premium': 500, 
                    'pro': 800
                }
                
                found_tiers = {}
                for tier in tiers:
                    tier_name = tier.get('value', '').lower()
                    tier_price = tier.get('price', 0)
                    found_tiers[tier_name] = tier_price
                
                pricing_correct = True
                for tier_name, expected_price in expected_tiers.items():
                    if tier_name not in found_tiers:
                        details += f", Missing tier: {tier_name}"
                        pricing_correct = False
                    elif found_tiers[tier_name] != expected_price:
                        details += f", Price mismatch for {tier_name}: expected ₦{expected_price}, got ₦{found_tiers[tier_name]}"
                        pricing_correct = False
                
                if pricing_correct:
                    details += f", All tier pricing correct: Basic ₦200, Premium ₦500, Pro ₦800"
                else:
                    success = False
                    
            else:
                try:
                    error_data = response.json()
                    details += f", Error: {error_data.get('detail', 'Unknown error')}"
                except:
                    details += f", Raw response: {response.text[:200]}"
            
            self.log_result("Tier Pricing for Dashboard", success, details)
            return success
            
        except Exception as e:
            self.log_result("Tier Pricing for Dashboard", False, str(e))
            return False

    def test_premium_payment_initialization(self):
        """Test Premium tier payment initialization (₦500/month)"""
        if not self.user_data:
            self.log_result("Premium Payment Initialization", False, "No user data available")
            return False

        payment_data = {
            "tier": "premium",
            "mechanic_id": "demo-mechanic-123"  # Using demo ID as in the frontend code
        }

        try:
            response = requests.post(
                f"{self.api_url}/payments/initialize",
                json=payment_data,
                timeout=10
            )
            
            success = response.status_code == 200
            details = f"Status: {response.status_code}"
            
            if success:
                data = response.json()
                if data.get('status') == 'success':
                    auth_url = data.get('authorization_url', '')
                    reference = data.get('reference', '')
                    amount = data.get('amount', 0)
                    tier = data.get('tier', '')
                    
                    # Verify amount is correct (₦500 = 50000 kobo)
                    if amount == 500:
                        details += f", Amount correct: ₦{amount}"
                    else:
                        details += f", Amount incorrect: expected ₦500, got ₦{amount}"
                        success = False
                    
                    # Verify Paystack URL
                    if 'paystack.co' in auth_url:
                        details += f", Paystack URL generated correctly"
                    else:
                        details += f", Invalid Paystack URL: {auth_url[:50]}..."
                        success = False
                        
                    details += f", Reference: {reference[:20]}..., Tier: {tier}"
                else:
                    details += f", Payment init failed: {data.get('message', 'Unknown error')}"
                    success = False
            else:
                try:
                    error_data = response.json()
                    details += f", Error: {error_data.get('detail', 'Unknown error')}"
                except:
                    details += f", Raw response: {response.text[:200]}"
            
            self.log_result("Premium Payment Initialization (₦500)", success, details)
            return success
            
        except Exception as e:
            self.log_result("Premium Payment Initialization (₦500)", False, str(e))
            return False

    def test_pro_payment_initialization(self):
        """Test Pro tier payment initialization (₦800/month)"""
        payment_data = {
            "tier": "pro",
            "mechanic_id": "demo-mechanic-123"
        }

        try:
            response = requests.post(
                f"{self.api_url}/payments/initialize",
                json=payment_data,
                timeout=10
            )
            
            success = response.status_code == 200
            details = f"Status: {response.status_code}"
            
            if success:
                data = response.json()
                if data.get('status') == 'success':
                    amount = data.get('amount', 0)
                    auth_url = data.get('authorization_url', '')
                    
                    # Verify amount is correct (₦800 = 80000 kobo)
                    if amount == 800:
                        details += f", Amount correct: ₦{amount}"
                    else:
                        details += f", Amount incorrect: expected ₦800, got ₦{amount}"
                        success = False
                    
                    # Verify Paystack URL
                    if 'paystack.co' in auth_url:
                        details += f", Paystack URL generated correctly"
                    else:
                        details += f", Invalid Paystack URL"
                        success = False
                        
                else:
                    details += f", Payment init failed: {data.get('message', 'Unknown error')}"
                    success = False
            else:
                try:
                    error_data = response.json()
                    details += f", Error: {error_data.get('detail', 'Unknown error')}"
                except:
                    details += f", Raw response: {response.text[:200]}"
            
            self.log_result("Pro Payment Initialization (₦800)", success, details)
            return success
            
        except Exception as e:
            self.log_result("Pro Payment Initialization (₦800)", False, str(e))
            return False

    def test_jwt_token_structure(self):
        """Test JWT token structure and payload"""
        if not self.token:
            self.log_result("JWT Token Structure", False, "No token available")
            return False

        try:
            import base64
            
            # Split JWT token
            parts = self.token.split('.')
            if len(parts) != 3:
                self.log_result("JWT Token Structure", False, f"Invalid JWT format: {len(parts)} parts")
                return False
            
            # Decode payload (add padding if needed)
            payload_b64 = parts[1]
            # Add padding if needed
            payload_b64 += '=' * (4 - len(payload_b64) % 4)
            
            payload_json = base64.b64decode(payload_b64).decode('utf-8')
            payload = json.loads(payload_json)
            
            # Check required fields
            required_fields = ['user_id', 'email', 'role']
            missing_fields = [field for field in required_fields if field not in payload]
            
            if missing_fields:
                details = f"Missing fields in JWT: {missing_fields}"
                success = False
            else:
                details = f"JWT valid with fields: {list(payload.keys())}"
                details += f", Role: {payload.get('role')}, Email: {payload.get('email')}"
                success = payload.get('role') == 'mechanic'
                
                if not success:
                    details += f", Role mismatch: expected 'mechanic', got '{payload.get('role')}'"
            
            self.log_result("JWT Token Structure", success, details)
            return success
            
        except Exception as e:
            self.log_result("JWT Token Structure", False, str(e))
            return False

    def run_complete_mechanic_flow_test(self):
        """Run the complete mechanic registration and payment flow"""
        print("🚀 TESTING COMPLETE MECHANIC REGISTRATION & PAYMENT FLOW")
        print("=" * 80)
        print("Testing the PRIMARY BUSINESS FUNCTION as requested in review")
        print()
        
        # Step 1: Test mechanic registration
        if not self.test_specific_mechanic_registration():
            print("❌ CRITICAL: Mechanic registration failed. Stopping tests.")
            return False
        
        # Step 2: Test mechanic login
        if not self.test_mechanic_login_flow():
            print("❌ CRITICAL: Mechanic login failed. Dashboard access will fail.")
            return False
        
        # Step 3: Test JWT token structure
        self.test_jwt_token_structure()
        
        # Step 4: Test tier pricing for dashboard
        if not self.test_tier_pricing_for_dashboard():
            print("❌ CRITICAL: Tier pricing failed. Dashboard won't show pricing.")
            return False
        
        # Step 5: Test payment initialization for Premium tier
        if not self.test_premium_payment_initialization():
            print("❌ CRITICAL: Premium payment initialization failed.")
        
        # Step 6: Test payment initialization for Pro tier  
        if not self.test_pro_payment_initialization():
            print("❌ CRITICAL: Pro payment initialization failed.")
        
        # Print summary
        print("=" * 80)
        print(f"📊 MECHANIC FLOW TEST SUMMARY")
        print(f"Tests Run: {self.tests_run}")
        print(f"Tests Passed: {self.tests_passed}")
        print(f"Tests Failed: {self.tests_run - self.tests_passed}")
        print(f"Success Rate: {(self.tests_passed/self.tests_run)*100:.1f}%")
        
        if self.errors:
            print(f"\n❌ CRITICAL ISSUES FOUND:")
            for error in self.errors:
                print(f"  - {error}")
        else:
            print(f"\n✅ ALL MECHANIC FLOW TESTS PASSED!")
        
        return self.tests_passed == self.tests_run

def main():
    print("🔧 MECHANIC REGISTRATION & PAYMENT FLOW TESTING")
    print("Testing the PRIMARY BUSINESS FUNCTION of the app")
    print()
    
    tester = MechanicRegistrationFlowTester()
    success = tester.run_complete_mechanic_flow_test()
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())