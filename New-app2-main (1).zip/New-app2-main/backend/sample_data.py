#!/usr/bin/env python3
"""
Sample data script to populate the database with mechanics for testing
"""

import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from pathlib import Path
from datetime import datetime, timezone
import uuid

# Load environment variables
ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

async def create_sample_mechanics():
    """Create sample mechanic profiles"""
    
    # Sample mechanic data
    mechanics = [
        {
            "id": str(uuid.uuid4()),
            "user_id": str(uuid.uuid4()),
            "business_name": "Lagos AutoCare Center",
            "description": "Expert automotive repair services with over 15 years experience. Specializing in engine diagnostics and electrical systems.",
            "location": {
                "address": "Victoria Island, Lagos State",
                "latitude": 6.4281,
                "longitude": 3.4219,
                "state": "Lagos",
                "lga": "Eti-Osa"
            },
            "services": ["Engine Repair", "Brake Service", "Oil Change", "Electrical Repair", "Diagnostic Service"],
            "tier": "pro",
            "tier_expires_at": datetime(2025, 12, 31, tzinfo=timezone.utc),
            "rating": 4.8,
            "total_reviews": 127,
            "contact_info": {
                "phone": "+234-801-234-5678",
                "whatsapp": "+234-801-234-5678",
                "email": "info@lagosautocarecom"
            },
            "years_experience": 15,
            "certifications": ["ASE Certified", "Bosch Certified"],
            "working_hours": {
                "monday": "8:00-18:00",
                "tuesday": "8:00-18:00",
                "wednesday": "8:00-18:00",
                "thursday": "8:00-18:00",
                "friday": "8:00-18:00",
                "saturday": "9:00-17:00",
                "sunday": "closed"
            },
            "profile_image_url": "https://images.unsplash.com/photo-1708449474154-e76585464b5e?w=400&h=400&fit=crop",
            "gallery_images": [],
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc),
            "is_verified": True,
            "is_active": True
        },
        {
            "id": str(uuid.uuid4()),
            "user_id": str(uuid.uuid4()),
            "business_name": "Ikeja Motor Works",
            "description": "Family-owned mechanic shop serving Lagos for 20+ years. Quick repairs and honest pricing.",
            "location": {
                "address": "Ikeja, Lagos State",
                "latitude": 6.6018,
                "longitude": 3.3515,
                "state": "Lagos",
                "lga": "Ikeja"
            },
            "services": ["Engine Repair", "Tire Service", "Battery Service", "Oil Change", "Brake Service"],
            "tier": "premium",
            "tier_expires_at": datetime(2025, 8, 15, tzinfo=timezone.utc),
            "rating": 4.3,
            "total_reviews": 89,
            "contact_info": {
                "phone": "+234-802-345-6789",
                "email": "ikejamotorworks@gmail.com"
            },
            "years_experience": 22,
            "certifications": ["Local Business License"],
            "working_hours": {
                "monday": "7:00-19:00",
                "tuesday": "7:00-19:00",
                "wednesday": "7:00-19:00",
                "thursday": "7:00-19:00",
                "friday": "7:00-19:00",
                "saturday": "8:00-18:00",
                "sunday": "closed"
            },
            "profile_image_url": None,
            "gallery_images": [],
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc),
            "is_verified": True,
            "is_active": True
        },
        {
            "id": str(uuid.uuid4()),
            "user_id": str(uuid.uuid4()),
            "business_name": "Surulere Express Auto",
            "description": "Fast and reliable automotive services. Emergency roadside assistance available 24/7.",
            "location": {
                "address": "Surulere, Lagos State",
                "latitude": 6.4969,
                "longitude": 3.3485,
                "state": "Lagos",
                "lga": "Surulere"
            },
            "services": ["Emergency Roadside", "Engine Repair", "Tire Service", "Battery Service", "Towing Service"],
            "tier": "basic",
            "tier_expires_at": datetime(2025, 6, 30, tzinfo=timezone.utc),
            "rating": 4.1,
            "total_reviews": 56,
            "contact_info": {
                "phone": "+234-803-456-7890",
                "whatsapp": "+234-803-456-7890"
            },
            "years_experience": 8,
            "certifications": [],
            "working_hours": {
                "monday": "24/7",
                "tuesday": "24/7",
                "wednesday": "24/7",
                "thursday": "24/7",
                "friday": "24/7",
                "saturday": "24/7",
                "sunday": "24/7"
            },
            "profile_image_url": None,
            "gallery_images": [],
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc),
            "is_verified": False,
            "is_active": True
        },
        {
            "id": str(uuid.uuid4()),
            "user_id": str(uuid.uuid4()),
            "business_name": "Abuja Premium Motors",
            "description": "High-end automotive services for luxury and exotic vehicles. German car specialists.",
            "location": {
                "address": "Maitama, Abuja FCT",
                "latitude": 9.0829,
                "longitude": 7.4951,
                "state": "FCT",
                "lga": "Abuja Municipal"
            },
            "services": ["Engine Repair", "Transmission Repair", "Electrical Repair", "Air Conditioning", "Diagnostic Service"],
            "tier": "pro",
            "tier_expires_at": datetime(2025, 11, 20, tzinfo=timezone.utc),
            "rating": 4.9,
            "total_reviews": 94,
            "contact_info": {
                "phone": "+234-804-567-8901",
                "whatsapp": "+234-804-567-8901",
                "email": "service@abujapremium.ng"
            },
            "years_experience": 12,
            "certifications": ["Mercedes-Benz Certified", "BMW Certified", "Audi Specialist"],
            "working_hours": {
                "monday": "8:00-18:00",
                "tuesday": "8:00-18:00",
                "wednesday": "8:00-18:00",
                "thursday": "8:00-18:00",
                "friday": "8:00-18:00",
                "saturday": "9:00-16:00",
                "sunday": "closed"
            },
            "profile_image_url": "https://images.unsplash.com/photo-1698998881125-b7b8f05a504b?w=400&h=400&fit=crop",
            "gallery_images": [],
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc),
            "is_verified": True,
            "is_active": True
        },
        {
            "id": str(uuid.uuid4()),
            "user_id": str(uuid.uuid4()),
            "business_name": "Port Harcourt Auto Solutions",
            "description": "Complete automotive repair and maintenance services. Experienced with all vehicle types.",
            "location": {
                "address": "Port Harcourt, Rivers State",
                "latitude": 4.8156,
                "longitude": 7.0498,
                "state": "Rivers",
                "lga": "Port Harcourt"
            },
            "services": ["Engine Repair", "Brake Service", "Oil Change", "Suspension Repair", "Exhaust System"],
            "tier": "premium",
            "tier_expires_at": datetime(2025, 9, 10, tzinfo=timezone.utc),
            "rating": 4.5,
            "total_reviews": 73,
            "contact_info": {
                "phone": "+234-805-678-9012",
                "email": "info@phauto.com"
            },
            "years_experience": 18,
            "certifications": ["ASE Certified"],
            "working_hours": {
                "monday": "7:30-18:30",
                "tuesday": "7:30-18:30",
                "wednesday": "7:30-18:30",
                "thursday": "7:30-18:30",
                "friday": "7:30-18:30",
                "saturday": "8:00-17:00",
                "sunday": "closed"
            },
            "profile_image_url": None,
            "gallery_images": [],
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc),
            "is_verified": True,
            "is_active": True
        },
        {
            "id": str(uuid.uuid4()),
            "user_id": str(uuid.uuid4()),
            "business_name": "Kano Auto Repair Hub",
            "description": "Northern Nigeria's trusted automotive service center. Specializing in commercial vehicles.",
            "location": {
                "address": "Kano, Kano State",
                "latitude": 11.9999,
                "longitude": 8.5153,
                "state": "Kano",
                "lga": "Kano Municipal"
            },
            "services": ["Engine Repair", "Transmission Repair", "Tire Service", "Battery Service", "Panel Beating"],
            "tier": "basic",
            "tier_expires_at": datetime(2025, 5, 25, tzinfo=timezone.utc),
            "rating": 4.2,
            "total_reviews": 41,
            "contact_info": {
                "phone": "+234-806-789-0123"
            },
            "years_experience": 14,
            "certifications": [],
            "working_hours": {
                "monday": "6:00-18:00",
                "tuesday": "6:00-18:00",
                "wednesday": "6:00-18:00",
                "thursday": "6:00-18:00",
                "friday": "6:00-12:00",
                "saturday": "8:00-18:00",
                "sunday": "closed"
            },
            "profile_image_url": None,
            "gallery_images": [],
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc),
            "is_verified": False,
            "is_active": True
        }
    ]
    
    # Clear existing data
    await db.mechanic_profiles.delete_many({})
    print("Cleared existing mechanic profiles")
    
    # Insert sample mechanics
    await db.mechanic_profiles.insert_many(mechanics)
    print(f"Inserted {len(mechanics)} sample mechanics")
    
    # Create indexes for efficient searching
    await db.mechanic_profiles.create_index([("location.latitude", 1), ("location.longitude", 1)])
    await db.mechanic_profiles.create_index([("tier", 1)])
    await db.mechanic_profiles.create_index([("services", 1)])
    await db.mechanic_profiles.create_index([("is_active", 1)])
    print("Created database indexes")
    
    return mechanics

async def main():
    """Main function to populate sample data"""
    try:
        mechanics = await create_sample_mechanics()
        print("\n✅ Sample data created successfully!")
        print(f"Created {len(mechanics)} mechanic profiles across Nigeria:")
        
        for mechanic in mechanics:
            print(f"  • {mechanic['business_name']} ({mechanic['location']['address']}) - {mechanic['tier'].upper()} tier")
        
        print("\nYou can now test the search functionality!")
        
    except Exception as e:
        print(f"❌ Error creating sample data: {e}")
    finally:
        client.close()

if __name__ == "__main__":
    asyncio.run(main())