from fastapi_mail import FastMail, MessageSchema, ConnectionConfig, MessageType
from pydantic import EmailStr, BaseModel
from typing import List, Optional
import os
from dotenv import load_dotenv
from jinja2 import Environment, FileSystemLoader
import logging

load_dotenv()

# Configure logging
logger = logging.getLogger(__name__)

class EmailConfig:
    conf = ConnectionConfig(
        MAIL_USERNAME=os.getenv("MAIL_USERNAME"),
        MAIL_PASSWORD=os.getenv("MAIL_PASSWORD"),
        MAIL_FROM=os.getenv("MAIL_FROM"),
        MAIL_PORT=int(os.getenv("MAIL_PORT", 587)),
        MAIL_SERVER=os.getenv("MAIL_SERVER"),
        MAIL_FROM_NAME=os.getenv("MAIL_FROM_NAME"),
        MAIL_STARTTLS=os.getenv("MAIL_STARTTLS", "True").lower() == "true",
        MAIL_SSL_TLS=os.getenv("MAIL_SSL_TLS", "False").lower() == "true",
        USE_CREDENTIALS=os.getenv("USE_CREDENTIALS", "True").lower() == "true",
        VALIDATE_CERTS=os.getenv("VALIDATE_CERTS", "True").lower() == "true",
        TEMPLATE_FOLDER="./email_templates"
    )

class WelcomeEmailData(BaseModel):
    mechanic_name: str
    email: EmailStr
    subscription_plan: str
    plan_features: List[str]
    profile_completion_date: str

async def send_welcome_email(email_data: WelcomeEmailData):
    """
    Sends a welcome email to newly registered mechanics after profile completion.
    
    Args:
        email_data: WelcomeEmailData object containing mechanic details
        
    Returns:
        dict: Success status and message
    """
    try:
        # Load HTML template
        template_env = Environment(loader=FileSystemLoader('./email_templates'))
        template = template_env.get_template('welcome_email.html')
        
        # Render template with mechanic data
        html_content = template.render(
            mechanic_name=email_data.mechanic_name,
            subscription_plan=email_data.subscription_plan,
            plan_features=email_data.plan_features,
            profile_completion_date=email_data.profile_completion_date
        )
        
        # Create email message
        message = MessageSchema(
            subject="Welcome to MechFinder Nigeria - Your Profile is Ready!",
            recipients=[email_data.email],
            body=html_content,
            subtype=MessageType.html
        )
        
        # Send email
        fm = FastMail(EmailConfig.conf)
        await fm.send_message(message)
        
        logger.info(f"Welcome email sent successfully to {email_data.email}")
        return {"success": True, "message": f"Welcome email sent to {email_data.email}"}
        
    except Exception as e:
        logger.error(f"Failed to send welcome email to {email_data.email}: {str(e)}")
        return {"success": False, "message": f"Failed to send email: {str(e)}"}

async def send_subscription_activated_email(mechanic_name: str, email: EmailStr, subscription_plan: str):
    """
    Sends email when subscription is activated via payment.
    
    Args:
        mechanic_name: Name of the mechanic
        email: Mechanic's email address
        subscription_plan: The activated subscription plan
        
    Returns:
        dict: Success status and message
    """
    try:
        # Plan features mapping
        plan_features_map = {
            "basic": [
                "Up to 50 service requests per month",
                "3-day free trial completed", 
                "Customer review system",
                "Mobile app notifications",
                "Basic profile listing"
            ],
            "pro": [
                "Up to 100 service requests per month",
                "Priority customer support",
                "Featured profile placement",
                "Advanced analytics dashboard",
                "Customer review system",
                "Mobile app notifications"
            ],
            "premium": [
                "Unlimited service requests",
                "Top-tier profile visibility",
                "Instant customer connections",
                "Dedicated account manager",
                "Advanced analytics and insights",
                "Priority customer support",
                "Marketing support tools"
            ]
        }
        
        plan_features = plan_features_map.get(subscription_plan.lower(), plan_features_map["basic"])
        
        # Simple HTML email for subscription activation
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background-color: #008751; color: white; padding: 20px; text-align: center; }}
                .content {{ padding: 20px; }}
                .plan-box {{ background-color: #f8f9fa; border-left: 4px solid #008751; padding: 15px; margin: 20px 0; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🎉 Subscription Activated!</h1>
                    <p>MechFinder Nigeria</p>
                </div>
                <div class="content">
                    <p>Dear {mechanic_name},</p>
                    <p>Congratulations! Your <strong>{subscription_plan.title()} Plan</strong> subscription has been successfully activated.</p>
                    <div class="plan-box">
                        <h3>Your {subscription_plan.title()} Plan Features:</h3>
                        <ul>
                            {"".join([f"<li>{feature}</li>" for feature in plan_features])}
                        </ul>
                    </div>
                    <p>You can now enjoy all the benefits of your subscription and start receiving customer requests!</p>
                    <p><a href="https://fixmeapp.preview.emergentagent.com/#/mechanic-dashboard" 
                         style="background-color: #008751; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
                         Access Your Dashboard
                    </a></p>
                    <p>Best regards,<br>The MechFinder Team</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        # Create email message
        message = MessageSchema(
            subject=f"🎉 Your {subscription_plan.title()} Plan is Now Active - MechFinder Nigeria",
            recipients=[email],
            body=html_content,
            subtype=MessageType.html
        )
        
        # Send email
        fm = FastMail(EmailConfig.conf)
        await fm.send_message(message)
        
        logger.info(f"Subscription activation email sent to {email}")
        return {"success": True, "message": f"Subscription activation email sent to {email}"}
        
    except Exception as e:
        logger.error(f"Failed to send subscription activation email to {email}: {str(e)}")
        return {"success": False, "message": f"Failed to send email: {str(e)}"}