from fastapi import FastAPI, APIRouter, HTTPException, Request, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone
import bcrypt
import jwt
import requests
import secrets
from datetime import timedelta
import urllib.parse
from enum import Enum
import hashlib
import hmac
import json
from paystackapi.paystack import Paystack
from email_service import send_welcome_email, WelcomeEmailData, send_subscription_activated_email


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Constants
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key-change-in-production')
JWT_ALGORITHM = 'HS256'
PAYSTACK_SECRET_KEY = os.environ.get('PAYSTACK_SECRET_KEY', 'sk_test_your_key_here')
WHATSAPP_NUMBER = os.environ.get('WHATSAPP_NUMBER', '+2349042563020')

# Subscription configuration
BASIC_PLAN_CODE = os.environ.get('BASIC_PLAN_CODE', 'PLN_basic_plan_2000')
PRO_PLAN_CODE = os.environ.get('PRO_PLAN_CODE', 'PLN_wrw2ildim97qt9n') 
PREMIUM_PLAN_CODE = os.environ.get('PREMIUM_PLAN_CODE', 'PLN_premium_plan_8900')
BASIC_PAYMENT_URL = os.environ.get('BASIC_PAYMENT_URL', 'https://paystack.shop/pay/b-rg582t-v')
PREMIUM_PAYMENT_URL = os.environ.get('PREMIUM_PAYMENT_URL', 'https://paystack.shop/pay/oqglvsd3re')
WEBHOOK_SECRET = os.environ.get('WEBHOOK_SECRET', 'your-webhook-secret-key-here')

# Initialize Paystack
paystack = Paystack(secret_key=PAYSTACK_SECRET_KEY)

def send_whatsapp_notification(service_request_data):
    """Send WhatsApp notification for new service request"""
    try:
        message = f"""🚗 NEW SERVICE REQUEST - MechFinder
        
👤 Customer: {service_request_data.get('customer_name')}
📞 Phone: {service_request_data.get('customer_phone')}
📍 Address: {service_request_data.get('customer_address')}
🔧 Service: {service_request_data.get('service_type')}
📝 Issue: {service_request_data.get('description')}

Mechanic: {service_request_data.get('mechanic_name', 'Unknown')}
Time: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')} UTC

Please contact customer immediately!"""

        # Create WhatsApp URL
        whatsapp_url = f"https://wa.me/{WHATSAPP_NUMBER.replace('+', '')}?text={urllib.parse.quote(message)}"
        
        # For now, just log the WhatsApp URL (in production, you could use WhatsApp Business API)
        print(f"📱 WhatsApp notification ready: {whatsapp_url}")
        
        return {"whatsapp_url": whatsapp_url, "message": message}
        
    except Exception as e:
        print(f"WhatsApp notification error: {e}")
        return None

# Enums
class UserRole(str, Enum):
    CUSTOMER = "customer"
    MECHANIC = "mechanic"
    ADMIN = "admin"

class MechanicTier(str, Enum):
    BASIC = "basic"     # ₦2,000/month - 50 requests/month - 3-day trial
    PRO = "pro"         # ₦5,000/month - 100 requests/month - no trial  
    PREMIUM = "premium" # ₦8,900/month - unlimited requests - no trial

class SubscriptionStatus(str, Enum):
    TRIAL = "trial"         # Basic plan trial period
    ACTIVE = "active"       # Subscription is active and paid
    EXPIRED = "expired"     # Subscription has expired
    CANCELLED = "cancelled" # Subscription was cancelled
    ATTENTION = "attention" # Payment failed, needs attention

class TierUpgrade(BaseModel):
    mechanic_id: str
    new_tier: MechanicTier

class PaymentInitiation(BaseModel):
    tier: MechanicTier
    mechanic_id: str

class PaymentVerification(BaseModel):
    reference: str
    mechanic_id: str

# Models
class UserBase(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    phone: Optional[str] = None
    name: str
    password: str  # Added password field to UserBase
    role: UserRole
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    is_active: bool = True

class UserCreate(BaseModel):
    email: EmailStr
    phone: Optional[str] = None
    name: str
    password: str
    role: UserRole
    selected_tier: Optional[MechanicTier] = MechanicTier.BASIC  # Plan selection during registration
    city: Optional[str] = None  # City selection
    state: Optional[str] = None  # State selection
    address: Optional[str] = None  # Full address

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: str
    email: str
    phone: Optional[str]
    name: str
    role: str
    created_at: datetime
    is_active: bool

class MechanicProfile(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    business_name: str
    description: str
    location: Dict[str, Any]  # {"address": str, "latitude": float, "longitude": float, "state": str, "lga": str}
    services: List[str]  # ["engine repair", "brake service", "oil change", etc.]
    tier: MechanicTier = MechanicTier.BASIC
    tier_expires_at: Optional[datetime] = None
    rating: float = 0.0
    total_reviews: int = 0
    contact_info: Dict[str, str]  # {"phone": str, "whatsapp": str, "email": str}
    years_experience: int
    certifications: List[str] = []
    working_hours: Dict[str, str] = {}  # {"monday": "8:00-18:00", etc.}
    profile_image_url: Optional[str] = None
    gallery_images: List[str] = []
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    is_verified: bool = False
    is_active: bool = True

class MechanicProfileCreate(BaseModel):
    business_name: str
    description: str
    location: Dict[str, Any]
    services: List[str]
    contact_info: Dict[str, str]
    years_experience: int
    certifications: List[str] = []
    working_hours: Dict[str, str] = {}
    profile_image_url: Optional[str] = None

class ServiceRequest(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    customer_name: str
    customer_phone: str
    customer_address: str
    mechanic_id: Optional[str] = None  # Make optional
    service_type: str
    description: str
    location: Dict[str, Any]
    status: str = "pending"  # pending, accepted, in_progress, completed, cancelled
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    priority: str = "normal"  # low, normal, high, emergency

class ServiceRequestCreate(BaseModel):
    mechanic_id: Optional[str] = None  # Make optional
    customer_name: str
    customer_phone: str
    customer_address: str
    service_type: str
    description: str
    location: Dict[str, Any]

class Review(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    customer_id: str
    mechanic_id: str
    rating: int  # 1-5 stars
    comment: str
    service_request_id: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ReviewCreate(BaseModel):
    mechanic_id: str
    rating: int
    comment: str
    service_request_id: Optional[str] = None

# Subscription Models
class SubscriptionPlan(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    plan_code: str  # Paystack plan code
    name: str
    description: str
    amount: int  # Amount in kobo (₦2,000 = 200000 kobo)
    interval: str = "monthly"
    trial_days: int = 0  # Trial period in days
    request_limit_per_month: int  # Monthly request limit
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Subscription(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str  # Reference to user
    mechanic_profile_id: str  # Reference to mechanic profile
    plan_code: str  # Paystack plan code
    subscription_code: Optional[str] = None  # Paystack subscription code
    authorization_code: Optional[str] = None  # Paystack authorization code
    email_token: Optional[str] = None  # Paystack email token
    status: SubscriptionStatus = SubscriptionStatus.TRIAL
    tier: MechanicTier
    trial_end_date: Optional[datetime] = None  # For Basic plan trial
    current_period_start: Optional[datetime] = None
    current_period_end: Optional[datetime] = None  
    next_payment_date: Optional[datetime] = None
    request_count_this_month: int = 0  # Track monthly usage
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class WebhookEvent(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    event_type: str  # e.g., charge.success, subscription.create
    event_data: Dict[str, Any]  # Complete webhook payload
    signature: str  # Webhook signature for verification
    processed: bool = False
    processed_at: Optional[datetime] = None
    error_message: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Request Models for Subscription Operations
class SubscriptionCreateRequest(BaseModel):
    user_id: str
    tier: MechanicTier
    
class SubscriptionUpgradeRequest(BaseModel):
    user_id: str  
    new_tier: MechanicTier

class PaystackService:
    def __init__(self):
        self.base_url = "https://api.paystack.co"
        self.headers = {
            "Authorization": f"Bearer {PAYSTACK_SECRET_KEY}",
            "Content-Type": "application/json"
        }
        self.paystack = Paystack(secret_key=PAYSTACK_SECRET_KEY)
    
    async def initialize_payment(self, email: str, amount: int, metadata: dict = None):
        """Initialize payment transaction"""
        url = f"{self.base_url}/transaction/initialize"
        data = {
            "email": email,
            "amount": amount,  # Amount in kobo
            "currency": "NGN",
            "metadata": metadata or {}
        }
        
        response = requests.post(url, headers=self.headers, json=data)
        return response.json()
    
    async def verify_payment(self, reference: str):
        """Verify payment transaction"""
        url = f"{self.base_url}/transaction/verify/{reference}"
        response = requests.get(url, headers=self.headers)
        return response.json()
    
    async def create_subscription(self, customer_email: str, plan_code: str, authorization_code: str, start_date: Optional[str] = None):
        """Create subscription with Paystack"""
        url = f"{self.base_url}/subscription"
        data = {
            "customer": customer_email,
            "plan": plan_code,
            "authorization": authorization_code
        }
        if start_date:
            data["start_date"] = start_date
            
        response = requests.post(url, headers=self.headers, json=data)
        return response.json()
    
    async def disable_subscription(self, subscription_code: str, email_token: str):
        """Cancel/disable subscription"""
        url = f"{self.base_url}/subscription/disable"
        data = {
            "code": subscription_code,
            "token": email_token
        }
        response = requests.post(url, headers=self.headers, json=data)
        return response.json()
    
    async def get_subscription(self, subscription_id_or_code: str):
        """Get subscription details"""
        url = f"{self.base_url}/subscription/{subscription_id_or_code}"
        response = requests.get(url, headers=self.headers)
        return response.json()
    
    def verify_webhook_signature(self, payload: bytes, signature: str) -> bool:
        """Verify webhook signature from Paystack"""
        expected_signature = hmac.new(
            WEBHOOK_SECRET.encode('utf-8'),
            payload,
            hashlib.sha512
        ).hexdigest()
        return hmac.compare_digest(expected_signature, signature)

# Create Paystack service instance
paystack_service = PaystackService()

# Helper functions
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_access_token(data: dict) -> str:
    return jwt.encode(data, JWT_SECRET, algorithm=JWT_ALGORITHM)

def get_plan_config(tier: MechanicTier) -> dict:
    """Get subscription plan configuration"""
    plans = {
        MechanicTier.BASIC: {
            "plan_code": BASIC_PLAN_CODE,
            "amount": 200000,  # ₦2,000 in kobo
            "trial_days": 3,
            "request_limit": 50,
            "payment_url": BASIC_PAYMENT_URL,
            "name": "Basic Plan",
            "description": "₦2,000/month - 50 requests/month - 3-day trial"
        },
        MechanicTier.PRO: {
            "plan_code": PRO_PLAN_CODE,
            "amount": 500000,  # ₦5,000 in kobo  
            "trial_days": 0,
            "request_limit": 100,
            "payment_url": None,  # Uses plan code for subscription
            "name": "Pro Plan",
            "description": "₦5,000/month - 100 requests/month"
        },
        MechanicTier.PREMIUM: {
            "plan_code": PREMIUM_PLAN_CODE,
            "amount": 890000,  # ₦8,900 in kobo
            "trial_days": 0,
            "request_limit": -1,  # Unlimited
            "payment_url": PREMIUM_PAYMENT_URL,
            "name": "Premium Plan", 
            "description": "₦8,900/month - Unlimited requests"
        }
    }
    return plans.get(tier)

def is_subscription_active(subscription: dict) -> bool:
    """Check if subscription is active and within limits"""
    if not subscription:
        return False
        
    status = subscription.get('status')
    if status == SubscriptionStatus.CANCELLED or status == SubscriptionStatus.EXPIRED:
        return False
        
    # Check trial expiry for Basic plan
    if status == SubscriptionStatus.TRIAL:
        trial_end = subscription.get('trial_end_date')
        if trial_end and datetime.now(timezone.utc) > datetime.fromisoformat(trial_end):
            return False
            
    # Check subscription expiry  
    if status == SubscriptionStatus.ACTIVE:
        expiry_date = subscription.get('current_period_end')
        if expiry_date and datetime.now(timezone.utc) > datetime.fromisoformat(expiry_date):
            return False
            
    return True

def can_receive_requests(subscription: dict) -> bool:
    """Check if mechanic can receive more requests based on subscription"""
    if not is_subscription_active(subscription):
        return False
        
    plan_config = get_plan_config(subscription['tier'])
    if not plan_config:
        return False
        
    # Premium has unlimited requests
    if plan_config['request_limit'] == -1:
        return True
        
    # Check monthly limit
    return subscription.get('request_count_this_month', 0) < plan_config['request_limit']

async def create_trial_subscription(user_id: str, mechanic_profile_id: str) -> dict:
    """Create trial subscription for Basic plan"""
    trial_end = datetime.now(timezone.utc) + timedelta(days=3)
    
    subscription = {
        "id": str(uuid.uuid4()),
        "user_id": user_id,
        "mechanic_profile_id": mechanic_profile_id,
        "plan_code": BASIC_PLAN_CODE,
        "status": SubscriptionStatus.TRIAL,
        "tier": MechanicTier.BASIC,
        "trial_end_date": trial_end.isoformat(),
        "request_count_this_month": 0,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.subscriptions.insert_one(subscription)
    return subscription

def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Simple distance calculation in kilometers using Haversine formula"""
    import math
    
    # Convert latitude and longitude from degrees to radians
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    
    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    # Radius of earth in kilometers
    r = 6371
    return c * r

# Routes

@api_router.get("/")
async def root():
    return {"message": "Nigerian Mechanic Finder API"}

# Authentication Routes
@api_router.post("/auth/register")
async def register_user(user_data: UserCreate):
    try:
        # Check if user already exists
        existing_user = await db.users.find_one({"email": user_data.email})
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already registered")
        
        # Hash password
        hashed_password = hash_password(user_data.password)
        
        # Create user record
        user_dict = {
            "id": str(uuid.uuid4()),
            "name": user_data.name,
            "email": user_data.email,
            "phone": user_data.phone,
            "password": hashed_password,
            "role": user_data.role,
            "selected_tier": user_data.selected_tier,
            "city": user_data.city,
            "state": user_data.state,
            "address": user_data.address,
            "is_active": True,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
        # Insert user
        await db.users.insert_one(user_dict)
        
        # If user is a mechanic, create mechanic profile automatically
        if user_data.role == 'mechanic':
            mechanic_profile = {
                "id": str(uuid.uuid4()),
                "user_id": user_dict["id"],
                "business_name": f"{user_data.name}'s Workshop",  # Default business name
                "description": "Professional automotive services",
                "location": {
                    "address": user_data.address or f"{user_data.city}, {user_data.state}",
                    "city": user_data.city,
                    "state": user_data.state,
                    "latitude": 6.5244,  # Default Lagos coordinates
                    "longitude": 3.3792
                },
                "contact_info": {
                    "phone": user_data.phone,
                    "email": user_data.email,
                    "whatsapp": user_data.phone
                },
                "services": ["General Maintenance", "Engine Repair"],  # Default services
                "tier": user_data.selected_tier or "basic",
                "years_experience": 0,
                "is_verified": False,
                "is_active": True,
                "status": "active",
                "working_hours": {
                    "monday": "8:00-18:00",
                    "tuesday": "8:00-18:00",
                    "wednesday": "8:00-18:00",
                    "thursday": "8:00-18:00",
                    "friday": "8:00-18:00",
                    "saturday": "8:00-16:00",
                    "sunday": "Closed"
                },
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
            
            # Insert mechanic profile
            await db.mechanic_profiles.insert_one(mechanic_profile)
            
            # Create trial subscription for Basic plan mechanics
            if user_data.selected_tier == MechanicTier.BASIC:
                await create_trial_subscription(user_dict["id"], mechanic_profile["id"])
            
            # For Premium/Pro tier mechanics, create inactive subscription record for tracking
            elif user_data.selected_tier in [MechanicTier.PRO, MechanicTier.PREMIUM]:
                subscription = {
                    "id": str(uuid.uuid4()),
                    "user_id": user_dict["id"],
                    "mechanic_profile_id": mechanic_profile["id"],
                    "plan_code": get_plan_config(user_data.selected_tier)["plan_code"],
                    "status": SubscriptionStatus.EXPIRED,  # Requires payment to activate
                    "tier": user_data.selected_tier,
                    "request_count_this_month": 0,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }
                await db.subscriptions.insert_one(subscription)
            logger.info(f"Created mechanic profile for user {user_dict['id']}")
        
        # Create access token
        token = create_access_token({"user_id": user_dict["id"], "email": user_data.email, "user_type": user_data.role})
        
        return {
            "message": "User registered successfully",
            "token": token,
            "user": {
                "id": user_dict["id"],
                "email": user_data.email,
                "phone": user_data.phone,
                "name": user_data.name,
                "role": user_data.role,
                "created_at": user_dict["created_at"],
                "is_active": True
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Registration error: {str(e)}")
        raise HTTPException(status_code=500, detail="Registration failed")

@api_router.post("/auth/login")
async def login_user(login_data: UserLogin):
    try:
        # Find user
        user = await db.users.find_one({"email": login_data.email})
        if not user:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        # Check if password field exists and verify password
        stored_password = user.get('password') or user.get('hashed_password')
        if not stored_password or not verify_password(login_data.password, stored_password):
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        if not user.get('is_active', True):
            raise HTTPException(status_code=401, detail="Account is deactivated")
        
        # Create access token
        token = create_access_token({"user_id": user['id'], "email": user['email'], "user_type": user['role']})
        
        return {
            "message": "Login successful",
            "token": token,
            "user": {
                "id": user['id'],
                "name": user['name'],
                "email": user['email'],
                "role": user['role'],
                "created_at": user.get('created_at', ''),
                "is_active": user.get('is_active', True)
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        raise HTTPException(status_code=500, detail="Login failed")

# Mechanic Routes
@api_router.post("/mechanics/profile")
async def create_mechanic_profile(profile_data: MechanicProfileCreate, user_id: str):
    # Verify user is a mechanic
    user = await db.users.find_one({"id": user_id, "role": "mechanic"})
    if not user:
        raise HTTPException(status_code=403, detail="Only mechanics can create profiles")
    
    # Check if profile already exists
    existing_profile = await db.mechanic_profiles.find_one({"user_id": user_id})
    if existing_profile:
        raise HTTPException(status_code=400, detail="Profile already exists")
    
    profile_dict = profile_data.dict()
    profile_dict['user_id'] = user_id
    profile_obj = MechanicProfile(**profile_dict)
    
    await db.mechanic_profiles.insert_one(profile_obj.dict())
    
    return {"message": "Mechanic profile created successfully", "profile": profile_obj}

@api_router.get("/mechanics/search")
async def search_mechanics(
    latitude: float,
    longitude: float,
    radius: float = 50.0,  # km
    service_type: Optional[str] = None,
    tier: Optional[str] = None
):
    # Build query
    query = {"is_active": True}
    if service_type:
        query["services"] = {"$in": [service_type]}
    if tier:
        query["tier"] = tier
    
    # Get all active mechanics
    mechanics = await db.mechanic_profiles.find(query).to_list(length=None)
    
    # Filter by distance and calculate distances
    nearby_mechanics = []
    for mechanic in mechanics:
        if 'location' in mechanic and 'latitude' in mechanic['location'] and 'longitude' in mechanic['location']:
            distance = calculate_distance(
                latitude, longitude,
                mechanic['location']['latitude'], mechanic['location']['longitude']
            )
            
            if distance <= radius:
                # Remove MongoDB ObjectId for JSON serialization
                if '_id' in mechanic:
                    del mechanic['_id']
                
                # Convert datetime objects to ISO strings
                if 'created_at' in mechanic and mechanic['created_at']:
                    if hasattr(mechanic['created_at'], 'isoformat'):
                        mechanic['created_at'] = mechanic['created_at'].isoformat()
                if 'updated_at' in mechanic and mechanic['updated_at']:
                    if hasattr(mechanic['updated_at'], 'isoformat'):
                        mechanic['updated_at'] = mechanic['updated_at'].isoformat()
                if 'tier_expires_at' in mechanic and mechanic['tier_expires_at']:
                    if hasattr(mechanic['tier_expires_at'], 'isoformat'):
                        mechanic['tier_expires_at'] = mechanic['tier_expires_at'].isoformat()
                
                mechanic['distance'] = round(distance, 2)
                nearby_mechanics.append(mechanic)
    
    # Sort by tier priority then by distance
    tier_priority = {"pro": 1, "premium": 2, "basic": 3}
    nearby_mechanics.sort(key=lambda x: (tier_priority.get(x['tier'], 4), x['distance']))
    
    return {"mechanics": nearby_mechanics, "total": len(nearby_mechanics)}

@api_router.get("/mechanics/{mechanic_id}")
async def get_mechanic_profile(mechanic_id: str):
    mechanic = await db.mechanic_profiles.find_one({"id": mechanic_id, "is_active": True})
    if not mechanic:
        raise HTTPException(status_code=404, detail="Mechanic not found")
    
    return {"mechanic": mechanic}

# Service Request Routes
@api_router.post("/service-requests")
async def create_service_request(request_data: ServiceRequestCreate):
    """Create service request without customer account (customers don't register)"""
    
    # If no specific mechanic is selected, auto-assign or set to pending
    mechanic = None
    if request_data.mechanic_id:
        # Verify mechanic exists if one was specified
        mechanic = await db.mechanic_profiles.find_one({"id": request_data.mechanic_id, "is_active": True})
        if not mechanic:
            # Don't fail - just proceed without specific mechanic
            request_data.mechanic_id = None
    
    request_obj = ServiceRequest(**request_data.dict())
    
    # Clean for MongoDB storage
    request_data_for_db = request_obj.dict()
    if 'created_at' in request_data_for_db:
        request_data_for_db['created_at'] = request_data_for_db['created_at'].isoformat()
    if 'updated_at' in request_data_for_db:
        request_data_for_db['updated_at'] = request_data_for_db['updated_at'].isoformat()
    
    await db.service_requests.insert_one(request_data_for_db)
    
    # Send WhatsApp notification (general notification if no specific mechanic)
    whatsapp_data = {
        'customer_name': request_data.customer_name,
        'customer_phone': request_data.customer_phone,
        'customer_address': request_data.customer_address,
        'service_type': request_data.service_type,
        'description': request_data.description,
        'mechanic_name': mechanic.get("business_name", "Auto-assigned") if mechanic else "Auto-assigned"
    }
    
    whatsapp_result = send_whatsapp_notification(whatsapp_data)
    
    # Response based on whether specific mechanic was assigned
    if mechanic:
        return {
            "message": "Service request sent successfully! The mechanic will contact you within 30 minutes.",
            "request": request_obj,
            "mechanic_contact": {
                "business_name": mechanic["business_name"],
                "phone": mechanic.get("contact_info", {}).get("phone", "")
            },
            "whatsapp_notification": whatsapp_result
        }
    else:
        return {
            "message": "Service request received successfully! We will find a qualified mechanic in your area to help you.",
            "request": request_obj,
            "mechanic_contact": {
                "business_name": "Auto-assigned",
                "phone": "Will be provided"
            },
            "whatsapp_notification": whatsapp_result
        }

@api_router.get("/service-requests/customer/{customer_id}")
async def get_customer_requests(customer_id: str):
    requests = await db.service_requests.find({"customer_id": customer_id}).to_list(length=None)
    return {"requests": requests}

@api_router.get("/service-requests/mechanic/{mechanic_id}")
async def get_mechanic_requests(mechanic_id: str):
    requests = await db.service_requests.find({"mechanic_id": mechanic_id}).to_list(length=None)
    return {"requests": requests}

# Payment Routes
@api_router.post("/payments/initialize")
async def initialize_payment(payment_data: PaymentInitiation):
    """Initialize payment for mechanic tier upgrade"""
    
    # Get tier pricing (MONTHLY)
    tier_pricing = {
        MechanicTier.BASIC: 20000,    # ₦200 per month in kobo
        MechanicTier.PREMIUM: 50000,  # ₦500 per month in kobo
        MechanicTier.PRO: 80000       # ₦800 per month in kobo
    }
    
    amount = tier_pricing.get(payment_data.tier)
    if not amount:
        raise HTTPException(status_code=400, detail="Invalid tier")
    
    # Find mechanic profile
    mechanic = await db.mechanic_profiles.find_one({"id": payment_data.mechanic_id})
    if not mechanic:
        raise HTTPException(status_code=404, detail="Mechanic not found")
    
    # Find user email
    user = await db.users.find_one({"id": mechanic["user_id"]})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    try:
        # Initialize payment with Paystack
        metadata = {
            "mechanic_id": payment_data.mechanic_id,
            "new_tier": payment_data.tier,
            "upgrade_type": "tier_subscription"
        }
        
        response = await paystack_service.initialize_payment(
            email=user["email"],
            amount=amount,
            metadata=metadata
        )
        
        if response.get("status"):
            return {
                "status": "success",
                "authorization_url": response["data"]["authorization_url"],
                "reference": response["data"]["reference"],
                "amount": amount / 100,  # Convert to Naira for display
                "tier": payment_data.tier
            }
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Payment initialization failed: {response.get('message')}"
            )
    
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Payment initialization error: {str(e)}"
        )

@api_router.post("/payments/verify")
async def verify_payment(payment_data: PaymentVerification):
    """Verify payment and upgrade mechanic tier"""
    
    try:
        # Verify payment with Paystack
        response = await paystack_service.verify_payment(payment_data.reference)
        
        if not response.get("status"):
            raise HTTPException(
                status_code=400,
                detail="Payment verification failed"
            )
        
        transaction_data = response["data"]
        
        if transaction_data["status"] != "success":
            raise HTTPException(
                status_code=400,
                detail=f"Payment not successful: {transaction_data.get('gateway_response')}"
            )
        
        # Get metadata
        metadata = transaction_data.get("metadata", {})
        mechanic_id = metadata.get("mechanic_id")
        new_tier = metadata.get("new_tier")
        
        if mechanic_id != payment_data.mechanic_id:
            raise HTTPException(
                status_code=400,
                detail="Mechanic ID mismatch"
            )
        
        # Update mechanic tier (MONTHLY subscription)
        tier_expires_at = datetime.now(timezone.utc) + timedelta(days=30)  # 1 month subscription
        
        update_result = await db.mechanic_profiles.update_one(
            {"id": mechanic_id},
            {
                "$set": {
                    "tier": new_tier,
                    "tier_expires_at": tier_expires_at,
                    "updated_at": datetime.now(timezone.utc)
                }
            }
        )
        
        if update_result.modified_count == 0:
            raise HTTPException(
                status_code=404,
                detail="Mechanic not found or already updated"
            )
        
        # Get updated mechanic profile
        updated_mechanic = await db.mechanic_profiles.find_one({"id": mechanic_id})
        
        return {
            "status": "success",
            "message": f"Payment verified and tier upgraded to {new_tier}",
            "mechanic": {
                "id": updated_mechanic["id"],
                "business_name": updated_mechanic["business_name"],
                "tier": updated_mechanic["tier"],
                "tier_expires_at": updated_mechanic["tier_expires_at"].isoformat() if updated_mechanic.get("tier_expires_at") else None
            },
            "payment": {
                "reference": payment_data.reference,
                "amount": transaction_data["amount"] / 100,  # Convert to Naira
                "paid_at": transaction_data["paid_at"]
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Payment verification error: {str(e)}"
        )

@api_router.get("/payments/tiers")
async def get_tier_pricing():
    """Get pricing for all mechanic tiers"""
    return {
        "tiers": [
            {
                "name": "Basic",
                "value": "basic",
                "price": 200,
                "price_kobo": 20000,
                "duration": "1 month",
                "features": [
                    "Basic business listing",
                    "Customer contact via support agent",
                    "Basic profile information"
                ]
            },
            {
                "name": "Premium",
                "value": "premium", 
                "price": 500,
                "price_kobo": 50000,
                "duration": "1 month",
                "features": [
                    "Priority listing in search results",
                    "Enhanced business profile",
                    "Customer contact via support agent",
                    "Working hours display"
                ]
            },
            {
                "name": "Pro",
                "value": "pro",
                "price": 800,
                "price_kobo": 80000,
                "duration": "1 month", 
                "features": [
                    "Top priority in search results",
                    "Direct messaging with customers",
                    "Premium support",
                    "Featured business profile",
                    "Advanced analytics"
                ]
            }
        ]
    }

# Data Management Routes
@api_router.get("/data/mechanics/export")
async def export_mechanics_data(
    format: str = "json",  # json, csv, excel
    include_stats: bool = True
):
    """Export mechanics data for analysis"""
    try:
        # Get all mechanics with stats
        pipeline = [
            {
                "$lookup": {
                    "from": "reviews",
                    "localField": "id",
                    "foreignField": "mechanic_id",
                    "as": "reviews"
                }
            },
            {
                "$lookup": {
                    "from": "service_requests", 
                    "localField": "id",
                    "foreignField": "mechanic_id",
                    "as": "service_requests"
                }
            },
            {
                "$addFields": {
                    "total_requests": {"$size": "$service_requests"},
                    "completed_requests": {
                        "$size": {
                            "$filter": {
                                "input": "$service_requests",
                                "cond": {"$eq": ["$$this.status", "completed"]}
                            }
                        }
                    }
                }
            }
        ]
        
        mechanics_cursor = db.mechanic_profiles.aggregate(pipeline)
        mechanics = await mechanics_cursor.to_list(length=None)
        
        # Clean data for export
        export_data = []
        for mechanic in mechanics:
            if '_id' in mechanic:
                del mechanic['_id']
            if 'created_at' in mechanic and mechanic['created_at']:
                mechanic['created_at'] = mechanic['created_at'].isoformat()
            if 'updated_at' in mechanic and mechanic['updated_at']:
                mechanic['updated_at'] = mechanic['updated_at'].isoformat()
            if 'tier_expires_at' in mechanic and mechanic['tier_expires_at']:
                mechanic['tier_expires_at'] = mechanic['tier_expires_at'].isoformat()
            
            export_data.append(mechanic)
        
        return {
            "data": export_data,
            "total_records": len(export_data),
            "export_date": datetime.now(timezone.utc).isoformat(),
            "format": format
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Export failed: {str(e)}"
        )

@api_router.get("/data/analytics/overview")
async def get_analytics_overview():
    """Get platform analytics overview"""
    try:
        # Mechanic stats by tier
        tier_stats = await db.mechanic_profiles.aggregate([
            {"$group": {
                "_id": "$tier",
                "count": {"$sum": 1},
                "avg_rating": {"$avg": "$rating"},
                "total_reviews": {"$sum": "$total_reviews"}
            }}
        ]).to_list(length=None)
        
        # Location distribution
        location_stats = await db.mechanic_profiles.aggregate([
            {"$group": {
                "_id": "$location.state",
                "count": {"$sum": 1}
            }},
            {"$sort": {"count": -1}},
            {"$limit": 10}
        ]).to_list(length=None)
        
        # Service distribution
        service_stats = await db.mechanic_profiles.aggregate([
            {"$unwind": "$services"},
            {"$group": {
                "_id": "$services",
                "count": {"$sum": 1}
            }},
            {"$sort": {"count": -1}},
            {"$limit": 15}
        ]).to_list(length=None)
        
        # Monthly registration trends (last 12 months)
        twelve_months_ago = datetime.now(timezone.utc) - timedelta(days=365)
        monthly_registrations = await db.mechanic_profiles.aggregate([
            {"$match": {"created_at": {"$gte": twelve_months_ago}}},
            {"$group": {
                "_id": {
                    "year": {"$year": "$created_at"},
                    "month": {"$month": "$created_at"}
                },
                "count": {"$sum": 1}
            }},
            {"$sort": {"_id.year": 1, "_id.month": 1}}
        ]).to_list(length=None)
        
        # Total counts
        total_mechanics = await db.mechanic_profiles.count_documents({"is_active": True})
        total_customers = await db.users.count_documents({"role": "customer", "is_active": True})
        total_service_requests = await db.service_requests.count_documents({})
        total_reviews = await db.reviews.count_documents({})
        
        return {
            "summary": {
                "total_mechanics": total_mechanics,
                "total_customers": total_customers,
                "total_service_requests": total_service_requests,
                "total_reviews": total_reviews
            },
            "tier_distribution": tier_stats,
            "location_distribution": location_stats,
            "popular_services": service_stats,
            "monthly_trends": monthly_registrations,
            "generated_at": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Analytics generation failed: {str(e)}"
        )

@api_router.post("/data/mechanics/bulk-update")
async def bulk_update_mechanics(updates: List[dict]):
    """Bulk update mechanic data"""
    try:
        updated_count = 0
        errors = []
        
        for update in updates:
            mechanic_id = update.get('id')
            if not mechanic_id:
                errors.append({"error": "Missing mechanic ID", "data": update})
                continue
                
            update_data = {k: v for k, v in update.items() if k != 'id'}
            update_data['updated_at'] = datetime.now(timezone.utc)
            
            result = await db.mechanic_profiles.update_one(
                {"id": mechanic_id},
                {"$set": update_data}
            )
            
            if result.modified_count > 0:
                updated_count += 1
            else:
                errors.append({"error": "Mechanic not found or no changes", "id": mechanic_id})
        
        return {
            "updated_count": updated_count,
            "total_requests": len(updates),
            "errors": errors,
            "success_rate": (updated_count / len(updates)) * 100 if updates else 0
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Bulk update failed: {str(e)}"
        )

@api_router.get("/data/mechanics/inactive")
async def get_inactive_mechanics():
    """Get mechanics who haven't been active recently"""
    try:
        thirty_days_ago = datetime.now(timezone.utc) - timedelta(days=30)
        
        # Find mechanics with no recent service requests
        inactive_mechanics = await db.mechanic_profiles.aggregate([
            {
                "$lookup": {
                    "from": "service_requests",
                    "localField": "id", 
                    "foreignField": "mechanic_id",
                    "as": "recent_requests",
                    "pipeline": [
                        {"$match": {"created_at": {"$gte": thirty_days_ago}}}
                    ]
                }
            },
            {
                "$match": {
                    "is_active": True,
                    "recent_requests": {"$size": 0}
                }
            },
            {
                "$project": {
                    "id": 1,
                    "business_name": 1,
                    "location": 1,
                    "tier": 1,
                    "created_at": 1,
                    "last_login": 1,
                    "contact_info": 1
                }
            }
        ]).to_list(length=None)
        
        return {
            "inactive_mechanics": inactive_mechanics,
            "count": len(inactive_mechanics),
            "threshold_days": 30,
            "generated_at": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get inactive mechanics: {str(e)}"
        )

@api_router.get("/data/revenue/overview")
async def get_revenue_overview():
    """Get revenue analytics from subscriptions"""
    try:
        # Revenue by tier (MONTHLY)
        tier_pricing = {
            "basic": 20000,    # ₦200 per month in kobo
            "premium": 50000,  # ₦500 per month in kobo
            "pro": 80000       # ₦800 per month in kobo
        }
        
        # Current active subscriptions
        active_mechanics = await db.mechanic_profiles.find({
            "is_active": True,
            "tier_expires_at": {"$gt": datetime.now(timezone.utc)}
        }).to_list(length=None)
        
        revenue_by_tier = {}
        total_annual_revenue = 0
        
        for tier, price in tier_pricing.items():
            count = len([m for m in active_mechanics if m.get('tier') == tier])
            revenue = (count * price) / 100  # Convert to Naira
            revenue_by_tier[tier] = {
                "subscribers": count,
                "annual_revenue": revenue,
                "price_per_year": price / 100
            }
            total_annual_revenue += revenue
        
        # Subscription trends (if we had payment records)
        # This would need actual payment data for accurate trends
        
        return {
            "total_annual_revenue": total_annual_revenue,
            "revenue_by_tier": revenue_by_tier,
            "active_subscriptions": len(active_mechanics),
            "average_revenue_per_user": total_annual_revenue / len(active_mechanics) if active_mechanics else 0,
            "generated_at": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Revenue analysis failed: {str(e)}"
        )

@api_router.get("/service-requests/all")
async def get_all_service_requests():
    """Get all service requests for admin dashboard"""
    try:
        # Fetch all service requests
        cursor = db.service_requests.find({}).sort("created_at", -1)
        requests = await cursor.to_list(length=None)
        
        # Clean and convert data for JSON serialization
        for request in requests:
            # Remove MongoDB ObjectId for JSON serialization
            if '_id' in request:
                del request['_id']
            
            # Convert datetime objects to ISO strings for JSON serialization
            if 'created_at' in request and request['created_at']:
                request['created_at'] = request['created_at'] if isinstance(request['created_at'], str) else request['created_at'].isoformat()
            if 'updated_at' in request and request['updated_at']:
                request['updated_at'] = request['updated_at'] if isinstance(request['updated_at'], str) else request['updated_at'].isoformat()
        
        return {"requests": requests}
        
    except Exception as e:
        logger.error(f"Error fetching service requests: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to fetch service requests")

@api_router.put("/service-requests/{request_id}/status")
async def update_service_request_status(request_id: str, status_data: dict):
    """Update service request status - Admin only"""
    try:
        new_status = status_data.get('status')
        if not new_status:
            raise HTTPException(status_code=400, detail="Status is required")
        
        # Validate status
        valid_statuses = ['pending', 'assigned', 'in_progress', 'completed', 'cancelled']
        if new_status not in valid_statuses:
            raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {valid_statuses}")
        
        # Update the service request
        update_result = await db.service_requests.update_one(
            {"id": request_id},
            {
                "$set": {
                    "status": new_status,
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }
            }
        )
        
        if update_result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Service request not found")
        
        # Get updated request
        updated_request = await db.service_requests.find_one({"id": request_id})
        
        return {
            "message": f"Service request status updated to {new_status}",
            "request_id": request_id,
            "new_status": new_status,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating service request status: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to update service request status")



@api_router.put("/service-requests/{request_id}/assign-mechanic")
async def assign_mechanic_to_request(request_id: str, mechanic_data: dict):
    """Assign a mechanic to a service request"""
    mechanic_id = mechanic_data.get("mechanic_id")
    
    if not mechanic_id:
        raise HTTPException(status_code=400, detail="mechanic_id is required")
    
    # Get the mechanic details
    mechanic = await db.mechanic_profiles.find_one({"id": mechanic_id})
    if not mechanic:
        raise HTTPException(status_code=404, detail="Mechanic not found")
    
    # Update the service request with assigned mechanic
    result = await db.service_requests.update_one(
        {"id": request_id},
        {
            "$set": {
                "mechanic_id": mechanic_id,
                "mechanic_contact": {
                    "business_name": mechanic.get("business_name"),
                    "phone": mechanic.get("contact_info", {}).get("phone"),
                    "email": mechanic.get("contact_info", {}).get("email")
                },
                "status": "assigned",
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
        }
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Service request not found")
    
    return {
        "message": "Mechanic assigned successfully",
        "mechanic_id": mechanic_id,
        "mechanic_name": mechanic.get("business_name")
    }

# Review Routes
@api_router.post("/reviews")
async def create_review(review_data: ReviewCreate, customer_id: str):
    # Verify customer exists
    customer = await db.users.find_one({"id": customer_id, "role": "customer"})
    if not customer:
        raise HTTPException(status_code=403, detail="Only customers can create reviews")
    
    # Verify mechanic exists
    mechanic = await db.mechanic_profiles.find_one({"id": review_data.mechanic_id, "is_active": True})
    if not mechanic:
        raise HTTPException(status_code=404, detail="Mechanic not found")
    
    review_dict = review_data.dict()
    review_dict['customer_id'] = customer_id
    review_obj = Review(**review_dict)
    
    await db.reviews.insert_one(review_obj.dict())
    
    # Update mechanic's rating
    reviews = await db.reviews.find({"mechanic_id": review_data.mechanic_id}).to_list(length=None)
    avg_rating = sum(r['rating'] for r in reviews) / len(reviews)
    
    await db.mechanic_profiles.update_one(
        {"id": review_data.mechanic_id},
        {"$set": {"rating": round(avg_rating, 1), "total_reviews": len(reviews)}}
    )
    
    return {"message": "Review created successfully", "review": review_obj}

@api_router.get("/reviews/mechanic/{mechanic_id}")
async def get_mechanic_reviews(mechanic_id: str):
    reviews = await db.reviews.find({"mechanic_id": mechanic_id}).to_list(length=None)
    return {"reviews": reviews}

# Utility Routes
@api_router.get("/services")
async def get_available_services():
    services = [
        "Engine Repair", "Brake Service", "Oil Change", "Tire Service",
        "Battery Service", "Air Conditioning", "Electrical Repair",
        "Transmission Repair", "Suspension Repair", "Exhaust System",
        "Car Wash", "Diagnostic Service", "Welding", "Panel Beating",
        "Towing Service", "Emergency Roadside"
    ]
    return {"services": services}

@api_router.get("/cities")
async def get_nigerian_cities():
    """Get major Nigerian cities organized by state - All 36 states + FCT"""
    cities_by_state = [
        {
            "state": "Abia",
            "cities": ["Umuahia", "Aba", "Arochukwu", "Bende", "Ikwuano", "Isiala Ngwa North", "Isiala Ngwa South"]
        },
        {
            "state": "Adamawa",
            "cities": ["Yola", "Jimeta", "Mubi", "Numan", "Ganye", "Gombi", "Song"]
        },
        {
            "state": "Akwa Ibom",
            "cities": ["Uyo", "Ikot Ekpene", "Eket", "Oron", "Abak", "Ikot Abasi", "Etinan"]
        },
        {
            "state": "Anambra",
            "cities": ["Awka", "Onitsha", "Nnewi", "Ekwulobia", "Ihiala", "Agulu", "Ozubulu"]
        },
        {
            "state": "Bauchi",
            "cities": ["Bauchi", "Azare", "Jama'are", "Misau", "Katagum", "Ningi", "Tafawa Balewa"]
        },
        {
            "state": "Bayelsa",
            "cities": ["Yenagoa", "Brass", "Sagbama", "Ogbia", "Nembe", "Southern Ijaw", "Ekeremor"]
        },
        {
            "state": "Benue",
            "cities": ["Makurdi", "Gboko", "Katsina-Ala", "Vandeikya", "Adoka", "Aliade", "Otukpo"]
        },
        {
            "state": "Borno",
            "cities": ["Maiduguri", "Biu", "Bama", "Dikwa", "Gubio", "Gwoza", "Konduga"]
        },
        {
            "state": "Cross River",
            "cities": ["Calabar", "Ugep", "Ikom", "Ogoja", "Obudu", "Abi", "Akamkpa"]
        },
        {
            "state": "Delta",
            "cities": ["Asaba", "Warri", "Sapele", "Ughelli", "Agbor", "Ozoro", "Koko"]
        },
        {
            "state": "Ebonyi",
            "cities": ["Abakaliki", "Afikpo", "Onueke", "Ezza", "Ikwo", "Ishielu", "Ivo"]
        },
        {
            "state": "Edo",
            "cities": ["Benin City", "Auchi", "Ekpoma", "Uromi", "Igarra", "Okada", "Sabongida-Ora"]
        },
        {
            "state": "Ekiti",
            "cities": ["Ado-Ekiti", "Ikere", "Oye", "Aramoko", "Ijero", "Emure", "Ikole"]
        },
        {
            "state": "Enugu",
            "cities": ["Enugu", "Nsukka", "Oji River", "Awgu", "Ezeagu", "Udi", "Nkanu East"]
        },
        {
            "state": "FCT",
            "cities": ["Abuja", "Garki", "Wuse", "Maitama", "Asokoro", "Gwarinpa", "Kubwa"]
        },
        {
            "state": "Gombe",
            "cities": ["Gombe", "Billiri", "Kaltungo", "Dukku", "Nafada", "Shongom", "Yamaltu/Deba"]
        },
        {
            "state": "Imo",
            "cities": ["Owerri", "Orlu", "Okigwe", "Mbaise", "Oguta", "Ngor Okpala", "Ihitte/Uboma"]
        },
        {
            "state": "Jigawa",
            "cities": ["Dutse", "Hadejia", "Kazaure", "Gumel", "Birnin Kudu", "Ringim", "Jahun"]
        },
        {
            "state": "Kaduna",
            "cities": ["Kaduna", "Zaria", "Kafanchan", "Sabon Gari", "Soba", "Makarfi", "Ikara"]
        },
        {
            "state": "Kano",
            "cities": ["Kano", "Wudil", "Bichi", "Karaye", "Gaya", "Rano", "Kumbotso"]
        },
        {
            "state": "Katsina",
            "cities": ["Katsina", "Daura", "Funtua", "Malumfashi", "Dutsin-Ma", "Kankia", "Mashi"]
        },
        {
            "state": "Kebbi",
            "cities": ["Birnin Kebbi", "Argungu", "Yauri", "Zuru", "Bunza", "Maiyama", "Gwandu"]
        },
        {
            "state": "Kogi",
            "cities": ["Lokoja", "Okene", "Kabba", "Anyigba", "Idah", "Dekina", "Ankpa"]
        },
        {
            "state": "Kwara",
            "cities": ["Ilorin", "Offa", "Jebba", "Lafiagi", "Pategi", "Kaiama", "Baruten"]
        },
        {
            "state": "Lagos",
            "cities": ["Lagos", "Ikeja", "Epe", "Badagry", "Ikorodu", "Victoria Island", "Lekki", "Ajah"]
        },
        {
            "state": "Nasarawa",
            "cities": ["Lafia", "Keffi", "Akwanga", "Nasarawa", "Doma", "Karu", "Obi"]
        },
        {
            "state": "Niger",
            "cities": ["Minna", "Bida", "Kontagora", "Suleja", "New Bussa", "Lapai", "Agaie"]
        },
        {
            "state": "Ogun",
            "cities": ["Abeokuta", "Sagamu", "Ijebu Ode", "Ilaro", "Ota", "Ayetoro", "Ipokia"]
        },
        {
            "state": "Ondo",
            "cities": ["Akure", "Ondo", "Owo", "Okitipupa", "Ikare", "Ore", "Igbokoda"]
        },
        {
            "state": "Osun",
            "cities": ["Osogbo", "Ile-Ife", "Ilesa", "Ede", "Iwo", "Ikire", "Ejigbo"]
        },
        {
            "state": "Oyo",
            "cities": ["Ibadan", "Ogbomoso", "Oyo", "Iseyin", "Saki", "Shaki", "Igboho"]
        },
        {
            "state": "Plateau",
            "cities": ["Jos", "Bukuru", "Mangu", "Vom", "Pankshin", "Shendam", "Langtang"]
        },
        {
            "state": "Rivers",
            "cities": ["Port Harcourt", "Bonny", "Obio-Akpor", "Ahoada", "Bori", "Eleme", "Degema"]
        },
        {
            "state": "Sokoto",
            "cities": ["Sokoto", "Tambuwal", "Gwadabawa", "Illela", "Rabah", "Wamako", "Goronyo"]
        },
        {
            "state": "Taraba",
            "cities": ["Jalingo", "Wukari", "Bali", "Gembu", "Serti", "Zing", "Takum"]
        },
        {
            "state": "Yobe",
            "cities": ["Damaturu", "Gashua", "Nguru", "Potiskum", "Buni Yadi", "Geidam", "Fika"]
        },
        {
            "state": "Zamfara",
            "cities": ["Gusau", "Kaura Namoda", "Anka", "Tsafe", "Talata Mafara", "Zurmi", "Bungudu"]
        }
    ]
    return {"cities_by_state": cities_by_state}

@api_router.get("/states")
async def get_nigerian_states():
    states = [
        "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa",
        "Benue", "Borno", "Cross River", "Delta", "Ebonyi", "Edo",
        "Ekiti", "Enugu", "Gombe", "Imo", "Jigawa", "Kaduna",
        "Kano", "Katsina", "Kebbi", "Kogi", "Kwara", "Lagos",
        "Nasarawa", "Niger", "Ogun", "Ondo", "Osun", "Oyo",
        "Plateau", "Rivers", "Sokoto", "Taraba", "Yobe", "Zamfara",
        "FCT"  # Federal Capital Territory
    ]
    return {"states": states}

# Add test page route (before API router)
@app.get("/test-service-request")
async def serve_test_page():
    """Serve the service request test page"""
    try:
        # Read the test HTML file
        test_file_path = Path(__file__).parent.parent / "frontend" / "src" / "TestServiceRequest.html"
        with open(test_file_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        return HTMLResponse(content=html_content)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Test page not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error serving test page: {str(e)}")

# Add dedicated testing API endpoint
@api_router.post("/test/service-request")
async def test_service_request_endpoint():
    """Dedicated endpoint for testing service request functionality"""
    try:
        # Get a random mechanic for testing
        mechanics_cursor = db.mechanic_profiles.find({"status": "active"}).limit(1)
        mechanics = await mechanics_cursor.to_list(length=1)
        
        if not mechanics:
            raise HTTPException(status_code=404, detail="No active mechanics found for testing")
        
        mechanic = mechanics[0]
        
        # Create a test service request
        test_request = {
            "id": str(uuid.uuid4()),
            "customer_name": "Test Customer",
            "customer_phone": "+234-801-TEST-001",
            "customer_address": "Test Address, Lagos State",
            "service_type": "Engine Repair",
            "description": "Backend API test - verifying service request functionality",
            "location": {
                "address": "Test Address, Lagos State",
                "coordinates": [6.5244, 3.3792],
                "state": "Lagos",
                "lga": "Lagos Island"
            },
            "mechanic_id": mechanic["id"],
            "status": "pending",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
        # Insert test request
        await db.service_requests.insert_one(test_request)
        
        # Get updated count
        total_requests = await db.service_requests.count_documents({})
        
        return {
            "success": True,
            "message": "Test service request created successfully",
            "test_request_id": test_request["id"],
            "mechanic_assigned": mechanic["business_name"],
            "total_requests_count": total_requests,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        logger.error(f"Test endpoint error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Test failed: {str(e)}")

@api_router.post("/test/create-sample-mechanics")
async def create_sample_mechanics():
    """Create sample mechanics in different states for testing"""
    try:
        sample_mechanics = [
            {
                "id": str(uuid.uuid4()),
                "business_name": "Lagos Auto Experts",
                "email": "lagos@autoexperts.ng",
                "contact_info": {"phone": "+234-801-234-5670"},
                "location": {
                    "address": "123 Ikeja Industrial Estate, Lagos",
                    "state": "Lagos",
                    "city": "Ikeja",
                    "latitude": 6.5244,
                    "longitude": 3.3792
                },
                "services": ["Engine Repair", "Oil Change", "Brake Service"],
                "tier": "premium",
                "years_experience": 8,
                "is_verified": True,
                "is_active": True,
                "status": "active",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "business_name": "Abuja Motors Hub",
                "email": "abuja@motorshub.ng", 
                "contact_info": {"phone": "+234-809-876-5432"},
                "location": {
                    "address": "45 Garki Business District, Abuja",
                    "state": "FCT",
                    "city": "Garki",
                    "latitude": 9.0579,
                    "longitude": 7.4951
                },
                "services": ["Electrical Repair", "AC Repair", "Battery Service"],
                "tier": "pro",
                "years_experience": 12,
                "is_verified": True,
                "is_active": True,
                "status": "active",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "business_name": "Kano Vehicle Care",
                "email": "kano@vehiclecare.ng",
                "contact_info": {"phone": "+234-803-123-4567"},
                "location": {
                    "address": "67 Sabon Gari Market Road, Kano",
                    "state": "Kano",
                    "city": "Sabon Gari",
                    "latitude": 12.0022,
                    "longitude": 8.5919
                },
                "services": ["Tire Service", "General Maintenance", "Engine Repair"],
                "tier": "basic",
                "years_experience": 5,
                "is_verified": False,
                "is_active": True,
                "status": "active",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "business_name": "Port Harcourt Auto Solutions",
                "email": "ph@autosolutions.ng",
                "contact_info": {"phone": "+234-807-987-6543"},
                "location": {
                    "address": "12 Trans Amadi Industrial Layout, Port Harcourt",
                    "state": "Rivers",
                    "city": "Port Harcourt",
                    "latitude": 4.8156,
                    "longitude": 7.0498
                },
                "services": ["Brake Service", "Oil Change", "Electrical Repair"],
                "tier": "premium",
                "years_experience": 10,
                "is_verified": True,
                "is_active": True,
                "status": "active",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "business_name": "Ibadan Quick Fix",
                "email": "ibadan@quickfix.ng",
                "contact_info": {"phone": "+234-805-345-6789"},
                "location": {
                    "address": "34 Ring Road, Ibadan",
                    "state": "Oyo",
                    "city": "Ibadan",
                    "latitude": 7.3775,
                    "longitude": 3.9470
                },
                "services": ["Emergency Roadside", "Tire Service", "Battery Service"],
                "tier": "basic",
                "years_experience": 3,
                "is_verified": False,
                "is_active": True,
                "status": "active",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
        ]
        
        # Insert all sample mechanics
        await db.mechanic_profiles.insert_many(sample_mechanics)
        
        return {
            "success": True,
            "message": f"Created {len(sample_mechanics)} sample mechanics across different states",
            "mechanics": [m["business_name"] for m in sample_mechanics],
            "states_covered": list(set([m["location"]["state"] for m in sample_mechanics]))
        }
        
    except Exception as e:
        logger.error(f"Sample mechanics creation error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to create sample mechanics: {str(e)}")

@api_router.get("/mechanics/{user_id}/requests")
async def get_mechanic_requests(user_id: str):
    """Get all requests assigned to a specific mechanic"""
    try:
        # First, find the mechanic profile to get the profile ID
        mechanic_profile = await db.mechanic_profiles.find_one({"user_id": user_id})
        if not mechanic_profile:
            return {"requests": []}
        
        mechanic_profile_id = mechanic_profile.get("id")
        
        # Find requests assigned to this mechanic using profile ID
        cursor = db.service_requests.find({"mechanic_id": mechanic_profile_id}).sort("created_at", -1)
        requests = await cursor.to_list(length=None)
        
        # Clean data for JSON serialization
        for request in requests:
            if '_id' in request:
                del request['_id']
            if 'created_at' in request and request['created_at']:
                request['created_at'] = request['created_at'] if isinstance(request['created_at'], str) else request['created_at'].isoformat()
            if 'updated_at' in request and request['updated_at']:
                request['updated_at'] = request['updated_at'] if isinstance(request['updated_at'], str) else request['updated_at'].isoformat()
        
        return {"requests": requests}
        
    except Exception as e:
        logger.error(f"Error fetching mechanic requests: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to fetch mechanic requests")

@api_router.get("/mechanics/{user_id}/profile")
async def get_mechanic_profile(user_id: str):
    """Get mechanic profile information"""
    try:
        # Find mechanic profile
        profile = await db.mechanic_profiles.find_one({"user_id": user_id})
        
        if not profile:
            raise HTTPException(status_code=404, detail="Mechanic profile not found")
        
        # Clean data for JSON serialization
        if '_id' in profile:
            del profile['_id']
        if 'created_at' in profile and profile['created_at']:
            profile['created_at'] = profile['created_at'] if isinstance(profile['created_at'], str) else profile['created_at'].isoformat()
        if 'updated_at' in profile and profile['updated_at']:
            profile['updated_at'] = profile['updated_at'] if isinstance(profile['updated_at'], str) else profile['updated_at'].isoformat()
        
        return {"profile": profile}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching mechanic profile: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to fetch mechanic profile")

@api_router.get("/mechanics/{user_id}/stats")
async def get_mechanic_stats(user_id: str):
    """Get mechanic dashboard statistics"""
    try:
        # Get current date for monthly calculations
        current_date = datetime.now(timezone.utc)
        month_start = current_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        
        # Find mechanic profile to get tier
        profile = await db.mechanic_profiles.find_one({"user_id": user_id})
        tier = profile.get('tier', 'basic') if profile else 'basic'
        
        # Count requests by status
        total_requests = await db.service_requests.count_documents({"mechanic_id": user_id})
        accepted_requests = await db.service_requests.count_documents({"mechanic_id": user_id, "status": "accepted"})
        completed_requests = await db.service_requests.count_documents({"mechanic_id": user_id, "status": "completed"})
        pending_requests = await db.service_requests.count_documents({"mechanic_id": user_id, "status": "pending"})
        
        # Count this month's requests
        this_month_requests = await db.service_requests.count_documents({
            "mechanic_id": user_id,
            "created_at": {"$gte": month_start.isoformat()}
        })
        
        # Calculate monthly limit based on tier
        monthly_limits = {
            'basic': 50,
            'pro': 100,
            'premium': 'unlimited'
        }
        monthly_limit = monthly_limits.get(tier, 50)
        
        # Calculate revenue (mock calculation - could be integrated with payment system)
        # For now, assume ₦5000 per completed request
        total_revenue = completed_requests * 5000
        
        stats = {
            "total_requests": total_requests,
            "accepted_requests": accepted_requests,
            "completed_requests": completed_requests,
            "pending_requests": pending_requests,
            "this_month_requests": this_month_requests,
            "monthly_limit": monthly_limit,
            "total_revenue": total_revenue,
            "tier": tier
        }
        
        return {"stats": stats}
        
    except Exception as e:
        logger.error(f"Error fetching mechanic stats: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to fetch mechanic stats")

@api_router.put("/mechanics/requests/{request_id}/status")
async def update_mechanic_request_status(request_id: str, status_data: dict):
    """Update service request status by mechanic"""
    try:
        new_status = status_data.get('status')
        if not new_status:
            raise HTTPException(status_code=400, detail="Status is required")
        
        # Validate status - mechanics can only use certain statuses
        valid_statuses = ['pending', 'accepted', 'in_progress', 'completed']
        if new_status not in valid_statuses:
            raise HTTPException(status_code=400, detail=f"Invalid status. Mechanics can use: {valid_statuses}")
        
        # Update the service request
        update_result = await db.service_requests.update_one(
            {"id": request_id},
            {
                "$set": {
                    "status": new_status,
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }
            }
        )
        
        if update_result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Service request not found")
        
        return {
            "message": f"Service request status updated to {new_status}",
            "request_id": request_id,
            "new_status": new_status,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating mechanic request status: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to update request status")

@api_router.post("/admin/assign-request")
async def admin_assign_request(assignment_data: dict):
    """Admin assigns a service request to a specific mechanic"""
    try:
        request_id = assignment_data.get('request_id')
        mechanic_user_id = assignment_data.get('mechanic_id')  # This is actually user_id from frontend
        
        if not request_id or not mechanic_user_id:
            raise HTTPException(status_code=400, detail="Both request_id and mechanic_id are required")
        
        # Check if request exists
        request = await db.service_requests.find_one({"id": request_id})
        if not request:
            raise HTTPException(status_code=404, detail="Service request not found")
        
        # Find mechanic profile by user_id to get the correct profile_id
        mechanic_profile = await db.mechanic_profiles.find_one({"user_id": mechanic_user_id})
        if not mechanic_profile:
            raise HTTPException(status_code=404, detail="Mechanic profile not found")
        
        mechanic_profile_id = mechanic_profile.get('id')  # This is the actual mechanic profile ID
        
        # Check mechanic's monthly limit (except for premium)
        subscription = await db.subscriptions.find_one({"user_id": mechanic_user_id})
        can_receive, message = await check_subscription_limits(mechanic_user_id)
        
        if not can_receive:
            raise HTTPException(status_code=400, detail=message)
        
        # Increment monthly usage counter
        if subscription:
            await db.subscriptions.update_one(
                {"user_id": mechanic_user_id},
                {
                    "$inc": {"request_count_this_month": 1},
                    "$set": {"updated_at": datetime.now(timezone.utc).isoformat()}
                }
            )
        
        # Update the service request with mechanic profile ID (not user ID)
        update_result = await db.service_requests.update_one(
            {"id": request_id},
            {
                "$set": {
                    "mechanic_id": mechanic_profile_id,  # Use profile ID
                    "mechanic_user_id": mechanic_user_id,  # Store user ID for reference
                    "status": "assigned",
                    "assigned_at": datetime.now(timezone.utc).isoformat(),
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }
            }
        )
        
        if update_result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Failed to assign request")
        
        return {
            "message": "Service request assigned successfully",
            "request_id": request_id,
            "mechanic_user_id": mechanic_user_id,
            "mechanic_profile_id": mechanic_profile_id,
            "mechanic_name": mechanic_profile.get('business_name', 'Unknown'),
            "assigned_at": datetime.now(timezone.utc).isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error assigning request: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to assign request")

# Subscription Management Routes
@api_router.get("/subscriptions/plans")
async def get_subscription_plans():
    """Get available subscription plans"""
    try:
        plans = []
        for tier in [MechanicTier.BASIC, MechanicTier.PRO, MechanicTier.PREMIUM]:
            config = get_plan_config(tier)
            if config:
                plans.append({
                    "tier": tier,
                    "plan_code": config["plan_code"],
                    "name": config["name"],
                    "description": config["description"],
                    "amount": config["amount"],
                    "amount_naira": config["amount"] / 100,
                    "trial_days": config["trial_days"],
                    "request_limit": config["request_limit"],
                    "payment_url": config["payment_url"]
                })
        
        return {"plans": plans}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get subscription plans: {str(e)}")

@api_router.get("/subscriptions/user/{user_id}")
async def get_user_subscription(user_id: str):
    """Get user's current subscription"""
    try:
        subscription = await db.subscriptions.find_one({"user_id": user_id})
        
        if not subscription:
            return {"subscription": None, "has_active_subscription": False}
        
        # Clean data for JSON serialization
        if '_id' in subscription:
            del subscription['_id']
            
        # Convert datetime strings if needed
        for date_field in ['trial_end_date', 'current_period_start', 'current_period_end', 'next_payment_date', 'created_at', 'updated_at']:
            if date_field in subscription and subscription[date_field]:
                if not isinstance(subscription[date_field], str):
                    subscription[date_field] = subscription[date_field].isoformat()
        
        is_active = is_subscription_active(subscription)
        can_receive = can_receive_requests(subscription)
        
        return {
            "subscription": subscription,
            "has_active_subscription": is_active,
            "can_receive_requests": can_receive,
            "subscription_status": subscription.get('status'),
            "tier": subscription.get('tier'),
            "monthly_usage": subscription.get('request_count_this_month', 0)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get subscription: {str(e)}")

@api_router.post("/subscriptions/create")
async def create_subscription(subscription_data: SubscriptionCreateRequest):
    """Create or upgrade subscription"""
    try:
        # Check if user exists
        user = await db.users.find_one({"id": subscription_data.user_id, "role": "mechanic"})
        if not user:
            raise HTTPException(status_code=404, detail="Mechanic user not found")
        
        # Get mechanic profile
        mechanic_profile = await db.mechanic_profiles.find_one({"user_id": subscription_data.user_id})
        if not mechanic_profile:
            raise HTTPException(status_code=404, detail="Mechanic profile not found")
        
        # Check for existing subscription
        existing_subscription = await db.subscriptions.find_one({"user_id": subscription_data.user_id})
        
        plan_config = get_plan_config(subscription_data.tier)
        if not plan_config:
            raise HTTPException(status_code=400, detail="Invalid subscription tier")
        
        # For Basic tier, create trial subscription
        if subscription_data.tier == MechanicTier.BASIC:
            if existing_subscription:
                # Update existing subscription
                trial_end = datetime.now(timezone.utc) + timedelta(days=3)
                await db.subscriptions.update_one(
                    {"user_id": subscription_data.user_id},
                    {
                        "$set": {
                            "tier": MechanicTier.BASIC,
                            "status": SubscriptionStatus.TRIAL,
                            "trial_end_date": trial_end.isoformat(),
                            "request_count_this_month": 0,
                            "updated_at": datetime.now(timezone.utc).isoformat()
                        }
                    }
                )
            else:
                # Create new trial subscription
                await create_trial_subscription(subscription_data.user_id, mechanic_profile["id"])
            
            return {
                "message": "Trial subscription activated",
                "tier": MechanicTier.BASIC,
                "trial_days": 3,
                "payment_url": plan_config["payment_url"]
            }
        
        # For Pro and Premium tiers, return payment information
        else:
            return {
                "message": "Subscription plan selected",
                "tier": subscription_data.tier,
                "plan_code": plan_config["plan_code"],
                "amount": plan_config["amount"],
                "payment_url": plan_config["payment_url"],
                "requires_payment": True
            }
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create subscription: {str(e)}")

@api_router.post("/subscriptions/upgrade")
async def upgrade_subscription(upgrade_data: SubscriptionUpgradeRequest):
    """Upgrade existing subscription"""
    try:
        # Check current subscription
        subscription = await db.subscriptions.find_one({"user_id": upgrade_data.user_id})
        if not subscription:
            raise HTTPException(status_code=404, detail="No existing subscription found")
        
        plan_config = get_plan_config(upgrade_data.new_tier)
        if not plan_config:
            raise HTTPException(status_code=400, detail="Invalid subscription tier")
        
        return {
            "message": "Upgrade plan selected",
            "current_tier": subscription.get('tier'),
            "new_tier": upgrade_data.new_tier,
            "plan_code": plan_config["plan_code"],
            "amount": plan_config["amount"],
            "payment_url": plan_config["payment_url"],
            "requires_payment": True
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to upgrade subscription: {str(e)}")

@api_router.post("/webhooks/paystack")
async def paystack_webhook(request: Request):
    """Handle Paystack webhook events"""
    try:
        # Get raw body and signature
        body = await request.body()
        signature = request.headers.get('x-paystack-signature', '')
        
        # Verify webhook signature
        if not paystack_service.verify_webhook_signature(body, signature):
            raise HTTPException(status_code=400, detail="Invalid webhook signature")
        
        # Parse webhook data
        webhook_data = json.loads(body.decode('utf-8'))
        event_type = webhook_data.get('event')
        event_data = webhook_data.get('data', {})
        
        # Store webhook event for audit
        webhook_event = {
            "id": str(uuid.uuid4()),
            "event_type": event_type,
            "event_data": event_data,
            "signature": signature,
            "processed": False,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.webhook_events.insert_one(webhook_event)
        
        # Process webhook events
        if event_type == "charge.success":
            await handle_charge_success(event_data)
        elif event_type == "subscription.create":
            await handle_subscription_create(event_data)
        elif event_type == "subscription.disable":
            await handle_subscription_disable(event_data)
        elif event_type == "invoice.payment_failed":
            await handle_payment_failed(event_data)
        
        # Mark webhook as processed
        await db.webhook_events.update_one(
            {"id": webhook_event["id"]},
            {
                "$set": {
                    "processed": True,
                    "processed_at": datetime.now(timezone.utc).isoformat()
                }
            }
        )
        
        return {"message": "Webhook processed successfully"}
        
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON in webhook payload")
    except Exception as e:
        logger.error(f"Webhook processing error: {str(e)}")
        
        # Mark webhook as failed
        if 'webhook_event' in locals():
            await db.webhook_events.update_one(
                {"id": webhook_event["id"]},
                {
                    "$set": {
                        "processed": True,
                        "processed_at": datetime.now(timezone.utc).isoformat(),
                        "error_message": str(e)
                    }
                }
            )
        
        raise HTTPException(status_code=500, detail=f"Webhook processing failed: {str(e)}")

# Webhook event handlers
async def handle_charge_success(event_data):
    """Handle successful charge event"""
    try:
        # Extract transaction details
        reference = event_data.get('reference')
        customer_email = event_data.get('customer', {}).get('email')
        amount = event_data.get('amount')  # in kobo
        authorization_code = event_data.get('authorization', {}).get('authorization_code')
        
        # Find subscription by email or reference
        user = await db.users.find_one({"email": customer_email, "role": "mechanic"})
        if not user:
            logger.warning(f"No mechanic user found for email: {customer_email}")
            return
        
        subscription = await db.subscriptions.find_one({"user_id": user["id"]})
        if not subscription:
            logger.warning(f"No subscription found for user: {user['id']}")
            return
        
        # Determine tier based on amount
        tier = None
        if amount == 200000:  # ₦2,000
            tier = MechanicTier.BASIC
        elif amount == 500000:  # ₦5,000
            tier = MechanicTier.PRO
        elif amount == 890000:  # ₦8,900
            tier = MechanicTier.PREMIUM
        
        if tier:
            # Update subscription to active
            next_month = datetime.now(timezone.utc) + timedelta(days=30)
            await db.subscriptions.update_one(
                {"user_id": user["id"]},
                {
                    "$set": {
                        "status": SubscriptionStatus.ACTIVE,
                        "tier": tier,
                        "authorization_code": authorization_code,
                        "current_period_start": datetime.now(timezone.utc).isoformat(),
                        "current_period_end": next_month.isoformat(),
                        "next_payment_date": next_month.isoformat(),
                        "updated_at": datetime.now(timezone.utc).isoformat()
                    }
                }
            )
            
            # Update mechanic profile tier
            await db.mechanic_profiles.update_one(
                {"user_id": user["id"]},
                {"$set": {"tier": tier, "updated_at": datetime.now(timezone.utc).isoformat()}}
            )
            
            # Send subscription activation email
            try:
                await send_subscription_activated_email(
                    mechanic_name=user.get('name', 'Mechanic'),
                    email=user.get('email'),
                    subscription_plan=tier
                )
                logger.info(f"Subscription activation email sent to {user['email']}")
            except Exception as email_error:
                logger.error(f"Failed to send subscription activation email: {str(email_error)}")
            
            logger.info(f"Subscription activated for user {user['id']}, tier: {tier}")
        
    except Exception as e:
        logger.error(f"Error handling charge success: {str(e)}")

async def handle_subscription_create(event_data):
    """Handle subscription creation event"""
    try:
        subscription_code = event_data.get('subscription_code')
        customer_email = event_data.get('customer', {}).get('email')
        plan_code = event_data.get('plan', {}).get('plan_code')
        
        # Find user and update subscription
        user = await db.users.find_one({"email": customer_email, "role": "mechanic"})
        if user:
            await db.subscriptions.update_one(
                {"user_id": user["id"]},
                {
                    "$set": {
                        "subscription_code": subscription_code,
                        "plan_code": plan_code,
                        "updated_at": datetime.now(timezone.utc).isoformat()
                    }
                }
            )
            logger.info(f"Subscription code updated for user {user['id']}: {subscription_code}")
        
    except Exception as e:
        logger.error(f"Error handling subscription create: {str(e)}")

async def handle_subscription_disable(event_data):
    """Handle subscription cancellation event"""
    try:
        subscription_code = event_data.get('subscription_code')
        
        # Find and cancel subscription
        result = await db.subscriptions.update_one(
            {"subscription_code": subscription_code},
            {
                "$set": {
                    "status": SubscriptionStatus.CANCELLED,
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }
            }
        )
        
        if result.modified_count > 0:
            logger.info(f"Subscription cancelled: {subscription_code}")
        
    except Exception as e:
        logger.error(f"Error handling subscription disable: {str(e)}")

async def handle_payment_failed(event_data):
    """Handle failed payment event"""
    try:
        customer_email = event_data.get('customer', {}).get('email')
        
        # Find user and mark subscription as needs attention
        user = await db.users.find_one({"email": customer_email, "role": "mechanic"})
        if user:
            await db.subscriptions.update_one(
                {"user_id": user["id"]},
                {
                    "$set": {
                        "status": SubscriptionStatus.ATTENTION,
                        "updated_at": datetime.now(timezone.utc).isoformat()
                    }
                }
            )
            logger.warning(f"Payment failed for user {user['id']}, subscription needs attention")
        
    except Exception as e:
        logger.error(f"Error handling payment failed: {str(e)}")

# Email Service Routes
@api_router.post("/email/send-welcome")
async def send_welcome_email_endpoint(
    email_data: WelcomeEmailData,
    background_tasks: BackgroundTasks
):
    """
    Send welcome email to mechanic after profile completion
    """
    try:
        # Send email in background to avoid blocking the response
        background_tasks.add_task(send_welcome_email, email_data)
        
        return {
            "success": True,
            "message": f"Welcome email will be sent to {email_data.email}",
            "mechanic_name": email_data.mechanic_name
        }
        
    except Exception as e:
        logger.error(f"Error sending welcome email: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to send welcome email: {str(e)}")

@api_router.post("/email/test-welcome")
async def test_welcome_email(background_tasks: BackgroundTasks):
    """
    Test endpoint to send a sample welcome email
    """
    try:
        test_email_data = WelcomeEmailData(
            mechanic_name="Test Mechanic",
            email="contact@mechfinder.services",  # Send to your own email for testing
            subscription_plan="Basic",
            plan_features=[
                "Up to 50 service requests per month",
                "3-day free trial",
                "Customer review system", 
                "Mobile app notifications",
                "Basic profile listing"
            ],
            profile_completion_date=datetime.now().strftime("%B %d, %Y at %I:%M %p")
        )
        
        background_tasks.add_task(send_welcome_email, test_email_data)
        
        return {
            "success": True,
            "message": "Test welcome email will be sent shortly",
            "test_email": "contact@mechfinder.services"
        }
        
    except Exception as e:
        logger.error(f"Error sending test email: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to send test email: {str(e)}")

@api_router.post("/mechanics/profile-complete")
async def complete_mechanic_profile(
    profile_data: dict,
    background_tasks: BackgroundTasks
):
    """
    Endpoint triggered after mechanic completes profile setup.
    Sends welcome email with subscription details in background.
    """
    try:
        user_id = profile_data.get('user_id')
        
        if not user_id:
            raise HTTPException(status_code=400, detail="user_id is required")
        
        # Get mechanic user and profile data
        user = await db.users.find_one({"id": user_id, "role": "mechanic"})
        if not user:
            raise HTTPException(status_code=404, detail="Mechanic user not found")
            
        mechanic_profile = await db.mechanic_profiles.find_one({"user_id": user_id})
        if not mechanic_profile:
            raise HTTPException(status_code=404, detail="Mechanic profile not found")
        
        # Get subscription info
        subscription = await db.subscriptions.find_one({"user_id": user_id})
        subscription_plan = subscription.get('tier', 'Basic') if subscription else 'Basic'
        
        # Define plan features based on subscription
        plan_features_map = {
            "basic": [
                "Profile listing on MechFinder platform",
                "Up to 50 service requests per month",
                "3-day free trial",
                "Customer review system",
                "Mobile app notifications"
            ],
            "pro": [
                "Featured profile placement",
                "Up to 100 service requests per month",
                "Priority customer inquiries",
                "Advanced analytics dashboard", 
                "Customer review system",
                "Mobile app notifications",
                "24/7 priority support"
            ],
            "premium": [
                "Top-tier profile visibility",
                "Unlimited service requests",
                "Instant customer connections",
                "Advanced analytics and insights",
                "Featured in search results",
                "Customer review management",
                "Mobile app notifications",
                "Dedicated account manager",
                "Marketing support tools"
            ]
        }
        
        plan_features = plan_features_map.get(
            subscription_plan.lower(), 
            plan_features_map["basic"]
        )
        
        # Prepare email data
        email_data = WelcomeEmailData(
            mechanic_name=user.get('name', 'Mechanic'),
            email=user.get('email'),
            subscription_plan=subscription_plan.title(),
            plan_features=plan_features,
            profile_completion_date=datetime.now().strftime("%B %d, %Y at %I:%M %p")
        )
        
        # Send email in background
        background_tasks.add_task(send_welcome_email, email_data)
        
        return {
            "success": True,
            "message": "Profile completed successfully. Welcome email will be sent shortly.",
            "mechanic_email": user.get('email'),
            "subscription_plan": subscription_plan
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Profile completion error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Profile completion failed: {str(e)}"
        )

# Middleware to check subscription limits
async def check_subscription_limits(user_id: str):
    """Middleware to check if mechanic can receive requests"""
    subscription = await db.subscriptions.find_one({"user_id": user_id})
    
    if not subscription:
        return False, "No active subscription found"
    
    if not is_subscription_active(subscription):
        if subscription.get('status') == SubscriptionStatus.TRIAL:
            return False, "Your free trial has ended. Renew your subscription to continue."
        elif subscription.get('status') == SubscriptionStatus.EXPIRED:
            return False, "Your subscription has expired. Renew to continue receiving requests."
        else:
            return False, "Subscription is not active"
    
    if not can_receive_requests(subscription):
        plan_config = get_plan_config(subscription['tier'])
        limit = plan_config['request_limit'] if plan_config else 50
        return False, f"You have reached your monthly limit of {limit} requests. Upgrade your plan for more requests."
    
    return True, "Subscription is active"

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()