#!/usr/bin/env python3
"""
Enhanced Mechanic Dashboard Status Management Test
FINAL TESTING - As requested in review

This test specifically focuses on:
1. Mechanic Dashboard Status Changes (pending → accepted → in_progress → completed)
2. Status Workflow Testing
3. Enhanced Dashboard Features
4. GET /api/mechanics/{user_id}/requests for assigned requests
5. PUT /api/mechanics/requests/{request_id}/status for status updates
6. Enhanced UI elements and visual progress indicators testing
"""

import requests
import json
import sys
from datetime import datetime

class EnhancedMechanicDashboardTester:
    def __init__(self, base_url="https://fixmeapp.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.mechanic_token = None
        self.admin_token = None
        self.test_mechanic_id = None
        self.mechanic_profile_id = None
        self.test_requests = []
        self.tests_run = 0
        self.tests_passed = 0

    def log_test(self, name, success, details=""):
        """Log test results"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name}")
            if details:
                print(f"   {details}")
        else:
            print(f"❌ {name}")
            if details:
                print(f"   {details}")

    def api_request(self, method, endpoint, data=None, token=None):
        """Make API request with proper headers"""
        url = f"{self.api_url}{endpoint}"
        headers = {'Content-Type': 'application/json'}
        
        if token:
            headers['Authorization'] = f'Bearer {token}'
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=10)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=headers, timeout=10)
            
            return response.status_code, response.json() if response.content else {}
        except Exception as e:
            return 500, {"error": str(e)}

    def setup_test_mechanic(self):
        """Create a test mechanic for dashboard testing"""
        print("\n🔧 Setting up test mechanic for enhanced dashboard testing...")
        
        timestamp = datetime.now().strftime('%H%M%S')
        mechanic_data = {
            "name": f"Enhanced Dashboard Mechanic {timestamp}",
            "email": f"enhanced.dashboard{timestamp}@test.com",
            "phone": "+234-808-999-1111",
            "password": "EnhancedDash123",
            "role": "mechanic",
            "selected_tier": "premium",  # Premium for unlimited requests
            "city": "Lagos",
            "state": "Lagos"
        }
        
        status, response = self.api_request('POST', '/auth/register', mechanic_data)
        
        if status == 200 and 'user' in response and 'token' in response:
            self.test_mechanic_id = response['user']['id']
            self.mechanic_token = response['token']
            
            # Get the mechanic profile ID (different from user ID)
            search_status, search_response = self.api_request(
                'GET', 
                f'/mechanics/search?latitude=6.5244&longitude=3.3792&radius=1000'
            )
            
            if search_status == 200:
                mechanics = search_response.get('mechanics', [])
                our_mechanic = next((m for m in mechanics if m.get('user_id') == self.test_mechanic_id), None)
                
                if our_mechanic:
                    self.mechanic_profile_id = our_mechanic['id']
                    self.log_test(
                        "Test Mechanic Setup", 
                        True, 
                        f"User ID: {self.test_mechanic_id}, Profile ID: {self.mechanic_profile_id}, Tier: premium"
                    )
                    return True
                else:
                    self.log_test("Test Mechanic Setup", False, "Could not find mechanic profile")
                    return False
            else:
                self.log_test("Test Mechanic Setup", False, "Could not search for mechanic profile")
                return False
        else:
            self.log_test("Test Mechanic Setup", False, f"Failed: {response}")
            return False

    def create_test_service_requests(self):
        """Create multiple service requests for status progression testing"""
        print("\n📋 Creating test service requests for status progression...")
        
        request_templates = [
            {
                "customer_name": "Enhanced Test Customer 1",
                "customer_phone": "+234-801-111-2222",
                "customer_address": "Enhanced Test Address 1, Lagos",
                "service_type": "Engine Repair",
                "description": "Enhanced dashboard test - engine repair needed"
            },
            {
                "customer_name": "Enhanced Test Customer 2", 
                "customer_phone": "+234-801-111-3333",
                "customer_address": "Enhanced Test Address 2, Lagos",
                "service_type": "Brake Service",
                "description": "Enhanced dashboard test - brake service needed"
            },
            {
                "customer_name": "Enhanced Test Customer 3",
                "customer_phone": "+234-801-111-4444", 
                "customer_address": "Enhanced Test Address 3, Lagos",
                "service_type": "Oil Change",
                "description": "Enhanced dashboard test - oil change needed"
            }
        ]
        
        for i, template in enumerate(request_templates):
            request_data = {
                **template,
                "mechanic_id": self.mechanic_profile_id,  # Use profile ID, not user ID
                "location": {
                    "address": template["customer_address"],
                    "latitude": 6.5244,
                    "longitude": 3.3792,
                    "state": "Lagos",
                    "lga": "Lagos Island"
                }
            }
            
            status, response = self.api_request('POST', '/service-requests', request_data)
            
            if status == 200 and 'request' in response:
                request_id = response['request']['id']
                self.test_requests.append({
                    'id': request_id,
                    'customer_name': template['customer_name'],
                    'service_type': template['service_type'],
                    'status': 'pending'
                })
                self.log_test(
                    f"Test Request {i+1} Created",
                    True,
                    f"ID: {request_id}, Service: {template['service_type']}"
                )
            else:
                self.log_test(f"Test Request {i+1} Creation", False, f"Failed: {response}")
                return False
        
        return len(self.test_requests) == 3

    def test_mechanic_dashboard_requests_api(self):
        """Test GET /api/mechanics/{user_id}/requests - Core requirement"""
        print("\n🎯 Testing GET /api/mechanics/{user_id}/requests...")
        
        status, response = self.api_request(
            'GET', 
            f'/mechanics/{self.test_mechanic_id}/requests',
            token=self.mechanic_token
        )
        
        if status == 200 and 'requests' in response:
            requests = response['requests']
            assigned_requests = [r for r in requests if r.get('mechanic_id') == self.mechanic_profile_id]
            
            self.log_test(
                "Mechanic Dashboard Requests API",
                True,
                f"Found {len(assigned_requests)} assigned requests out of {len(requests)} total"
            )
            
            # Verify request data structure
            if assigned_requests:
                sample_request = assigned_requests[0]
                required_fields = ['id', 'customer_name', 'service_type', 'status', 'created_at']
                missing_fields = [field for field in required_fields if field not in sample_request]
                
                if not missing_fields:
                    self.log_test(
                        "Request Data Structure",
                        True,
                        "All required fields present in request data"
                    )
                else:
                    self.log_test(
                        "Request Data Structure",
                        False,
                        f"Missing fields: {missing_fields}"
                    )
            
            return True
        else:
            self.log_test("Mechanic Dashboard Requests API", False, f"Status: {status}, Response: {response}")
            return False

    def test_status_progression_workflow(self):
        """Test complete status progression: pending → accepted → in_progress → completed"""
        print("\n🔄 Testing Enhanced Status Progression Workflow...")
        
        if not self.test_requests:
            self.log_test("Status Progression", False, "No test requests available")
            return False
        
        # Test status progression for each request
        status_flows = [
            ['pending', 'accepted', 'in_progress', 'completed'],  # Full workflow
            ['pending', 'accepted', 'in_progress'],               # Partial workflow
            ['pending', 'accepted']                               # Early stage
        ]
        
        for i, (request, flow) in enumerate(zip(self.test_requests, status_flows)):
            request_id = request['id']
            customer_name = request['customer_name']
            
            print(f"\n   📝 Testing status flow for {customer_name}:")
            
            # Skip 'pending' as it's the initial status, start from 'accepted'
            for status in flow[1:]:  # Skip first status (pending)
                status_data = {"status": status}
                
                api_status, api_response = self.api_request(
                    'PUT',
                    f'/mechanics/requests/{request_id}/status',
                    status_data,
                    token=self.mechanic_token
                )
                
                if api_status == 200:
                    self.log_test(
                        f"Status Update to {status}",
                        True,
                        f"Request {request_id[:8]}... → {status}"
                    )
                    
                    # Verify the status was actually updated
                    verify_status, verify_response = self.api_request(
                        'GET',
                        f'/mechanics/{self.test_mechanic_id}/requests',
                        token=self.mechanic_token
                    )
                    
                    if verify_status == 200:
                        requests = verify_response.get('requests', [])
                        updated_request = next((r for r in requests if r['id'] == request_id), None)
                        
                        if updated_request and updated_request.get('status') == status:
                            self.log_test(
                                f"Status Verification ({status})",
                                True,
                                f"Status correctly updated in database"
                            )
                        else:
                            self.log_test(
                                f"Status Verification ({status})",
                                False,
                                f"Status not updated in database"
                            )
                else:
                    self.log_test(
                        f"Status Update to {status}",
                        False,
                        f"API Error: {api_response}"
                    )
                    return False
        
        return True

    def test_enhanced_dashboard_features(self):
        """Test enhanced dashboard features and visual indicators"""
        print("\n🎨 Testing Enhanced Dashboard Features...")
        
        # Test mechanic profile endpoint
        status, response = self.api_request(
            'GET',
            f'/mechanics/{self.test_mechanic_id}/profile',
            token=self.mechanic_token
        )
        
        if status == 200 and 'profile' in response:
            profile = response['profile']
            
            # Check for enhanced profile fields
            enhanced_fields = ['tier', 'business_name', 'rating', 'total_reviews', 'services']
            present_fields = [field for field in enhanced_fields if field in profile]
            
            self.log_test(
                "Enhanced Profile Data",
                len(present_fields) >= 4,
                f"Enhanced fields present: {present_fields}"
            )
        else:
            self.log_test("Enhanced Profile Data", False, f"Profile API failed: {response}")
        
        # Test dashboard statistics with tier information
        status, response = self.api_request(
            'GET',
            f'/mechanics/{self.test_mechanic_id}/stats',
            token=self.mechanic_token
        )
        
        if status == 200 and 'stats' in response:
            stats = response['stats']
            
            # Check for enhanced stats fields
            required_stats = ['total_requests', 'accepted_requests', 'completed_requests', 
                            'pending_requests', 'monthly_limit', 'tier', 'total_revenue']
            present_stats = [field for field in required_stats if field in stats]
            
            self.log_test(
                "Enhanced Dashboard Stats",
                len(present_stats) >= 6,
                f"Stats fields present: {present_stats}"
            )
            
            # Verify tier-specific monthly limits
            tier = stats.get('tier')
            monthly_limit = stats.get('monthly_limit')
            
            if tier == 'premium' and monthly_limit == 'unlimited':
                self.log_test(
                    "Tier-Based Monthly Limits",
                    True,
                    f"Premium tier correctly shows unlimited requests"
                )
            else:
                self.log_test(
                    "Tier-Based Monthly Limits",
                    False,
                    f"Tier: {tier}, Limit: {monthly_limit}"
                )
        else:
            self.log_test("Enhanced Dashboard Stats", False, f"Stats API failed: {response}")

    def test_admin_dashboard_integration(self):
        """Test that status updates are reflected in admin dashboard"""
        print("\n👨‍💼 Testing Admin Dashboard Integration...")
        
        # Get all service requests from admin perspective
        status, response = self.api_request('GET', '/service-requests/all')
        
        if status == 200 and 'requests' in response:
            all_requests = response['requests']
            
            # Find our test requests
            our_requests = [r for r in all_requests if r['id'] in [tr['id'] for tr in self.test_requests]]
            
            if our_requests:
                # Check status distribution
                status_counts = {}
                for request in our_requests:
                    status = request.get('status', 'unknown')
                    status_counts[status] = status_counts.get(status, 0) + 1
                
                self.log_test(
                    "Admin Dashboard Integration",
                    True,
                    f"Status distribution: {status_counts}"
                )
                
                # Verify real-time updates (check if completed requests are visible)
                completed_requests = [r for r in our_requests if r.get('status') == 'completed']
                if completed_requests:
                    self.log_test(
                        "Real-time Status Updates",
                        True,
                        f"Found {len(completed_requests)} completed requests in admin dashboard"
                    )
                else:
                    self.log_test(
                        "Real-time Status Updates",
                        True,
                        "No completed requests yet (expected for partial workflow test)"
                    )
            else:
                self.log_test("Admin Dashboard Integration", False, "Test requests not found in admin dashboard")
        else:
            self.log_test("Admin Dashboard Integration", False, f"Admin API failed: {response}")

    def test_quick_action_buttons(self):
        """Test quick action functionality for status changes"""
        print("\n⚡ Testing Quick Action Status Changes...")
        
        if not self.test_requests:
            self.log_test("Quick Actions", False, "No test requests available")
            return False
        
        # Test quick status changes (simulating UI quick action buttons)
        quick_actions = [
            ('pending', 'accepted', 'Quick Accept'),
            ('accepted', 'in_progress', 'Quick Start Work'),
            ('in_progress', 'completed', 'Quick Complete')
        ]
        
        # Use the first request for quick action testing
        test_request = self.test_requests[0]
        request_id = test_request['id']
        
        # Reset request to pending first
        reset_status, reset_response = self.api_request(
            'PUT',
            f'/service-requests/{request_id}/status',
            {"status": "pending"}
        )
        
        if reset_status != 200:
            self.log_test("Quick Actions Setup", False, "Could not reset request status")
            return False
        
        # Test each quick action
        for from_status, to_status, action_name in quick_actions:
            status, response = self.api_request(
                'PUT',
                f'/mechanics/requests/{request_id}/status',
                {"status": to_status},
                token=self.mechanic_token
            )
            
            if status == 200:
                self.log_test(
                    action_name,
                    True,
                    f"{from_status} → {to_status}"
                )
            else:
                self.log_test(
                    action_name,
                    False,
                    f"Failed: {response}"
                )
                return False
        
        return True

    def test_visual_progress_indicators(self):
        """Test data for visual progress indicators"""
        print("\n📊 Testing Visual Progress Indicator Data...")
        
        # Get current stats for progress calculation
        status, response = self.api_request(
            'GET',
            f'/mechanics/{self.test_mechanic_id}/stats',
            token=self.mechanic_token
        )
        
        if status == 200 and 'stats' in response:
            stats = response['stats']
            
            # Calculate progress percentages (data that would drive visual indicators)
            total_requests = stats.get('total_requests', 0)
            completed_requests = stats.get('completed_requests', 0)
            accepted_requests = stats.get('accepted_requests', 0)
            in_progress_requests = stats.get('pending_requests', 0)  # This might be wrong in API
            
            if total_requests > 0:
                completion_rate = (completed_requests / total_requests) * 100
                acceptance_rate = (accepted_requests / total_requests) * 100
                
                self.log_test(
                    "Progress Indicator Data",
                    True,
                    f"Completion: {completion_rate:.1f}%, Acceptance: {acceptance_rate:.1f}%"
                )
                
                # Test monthly progress
                monthly_limit = stats.get('monthly_limit')
                this_month_requests = stats.get('this_month_requests', 0)
                
                if monthly_limit == 'unlimited':
                    monthly_progress = "Unlimited (Premium)"
                else:
                    monthly_progress = f"{this_month_requests}/{monthly_limit} ({(this_month_requests/monthly_limit)*100:.1f}%)"
                
                self.log_test(
                    "Monthly Progress Data",
                    True,
                    f"Monthly usage: {monthly_progress}"
                )
            else:
                self.log_test(
                    "Progress Indicator Data",
                    True,
                    "No requests yet - progress indicators would show 0%"
                )
        else:
            self.log_test("Progress Indicator Data", False, f"Stats API failed: {response}")

    def run_all_tests(self):
        """Run all enhanced mechanic dashboard tests"""
        print("🚀 ENHANCED MECHANIC DASHBOARD STATUS MANAGEMENT TEST")
        print("=" * 70)
        print("🎯 FOCUS: Enhanced mechanic dashboard status change functionality")
        print("📋 TESTING: Status progression, dashboard APIs, visual indicators")
        print("-" * 70)
        
        # Setup
        if not self.setup_test_mechanic():
            print("❌ Test setup failed - cannot continue")
            return False
        
        if not self.create_test_service_requests():
            print("❌ Test request creation failed - cannot continue")
            return False
        
        # Core tests
        test_results = []
        
        test_results.append(self.test_mechanic_dashboard_requests_api())
        test_results.append(self.test_status_progression_workflow())
        test_results.append(self.test_enhanced_dashboard_features())
        test_results.append(self.test_admin_dashboard_integration())
        test_results.append(self.test_quick_action_buttons())
        test_results.append(self.test_visual_progress_indicators())
        
        # Results
        print("\n" + "=" * 70)
        print("📊 ENHANCED MECHANIC DASHBOARD TEST RESULTS")
        print(f"Tests Run: {self.tests_run}")
        print(f"Tests Passed: {self.tests_passed}")
        print(f"Tests Failed: {self.tests_run - self.tests_passed}")
        print(f"Success Rate: {(self.tests_passed/self.tests_run)*100:.1f}%")
        
        all_passed = self.tests_passed == self.tests_run
        
        if all_passed:
            print("\n🎉 ENHANCED MECHANIC DASHBOARD STATUS MANAGEMENT: WORKING!")
            print("✅ Status progression workflow: OPERATIONAL")
            print("✅ Dashboard APIs: FUNCTIONAL")
            print("✅ Admin integration: CONFIRMED")
            print("✅ Enhanced features: VERIFIED")
            print("✅ Visual indicators: DATA AVAILABLE")
            return True
        else:
            print("\n⚠️  ISSUES FOUND IN ENHANCED MECHANIC DASHBOARD")
            print("❌ Some enhanced features need attention")
            return False

def main():
    tester = EnhancedMechanicDashboardTester()
    success = tester.run_all_tests()
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())