import requests
import sys
import json
from datetime import datetime

class PaymentSystemTester:
    def __init__(self, base_url="https://fixmeapp.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None):
        """Run a single API test"""
        url = f"{self.api_url}{endpoint}"
        headers = {'Content-Type': 'application/json'}

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=15)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=15)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict):
                        # Print key parts of response for payment tests
                        if 'authorization_url' in response_data:
                            print(f"   ✅ Payment URL generated: {response_data['authorization_url'][:50]}...")
                        elif 'tiers' in response_data:
                            print(f"   ✅ Found {len(response_data['tiers'])} pricing tiers")
                        elif 'summary' in response_data:
                            print(f"   ✅ Analytics data retrieved")
                        else:
                            print(f"   Response keys: {list(response_data.keys())}")
                    return True, response_data
                except:
                    return True, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {json.dumps(error_data, indent=2)}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_tier_pricing(self):
        """Test tier pricing endpoint"""
        success, response = self.run_test(
            "Tier Pricing",
            "GET",
            "/payments/tiers",
            200
        )
        
        if success and 'tiers' in response:
            tiers = response['tiers']
            print(f"   ✅ Found tiers: {[tier['name'] for tier in tiers]}")
            print(f"   ✅ Pricing: Basic=₦{tiers[0]['price']}, Premium=₦{tiers[1]['price']}, Pro=₦{tiers[2]['price']}")
            return True
        return False

    def test_payment_initialization_premium(self):
        """Test payment initialization for Premium tier"""
        test_data = {
            "tier": "premium",
            "mechanic_id": "demo-mechanic-123"
        }
        
        success, response = self.run_test(
            "Payment Initialization (Premium)",
            "POST",
            "/payments/initialize",
            200,  # Should work with real Paystack keys
            data=test_data
        )
        
        if success and 'authorization_url' in response:
            print(f"   ✅ Paystack URL generated successfully")
            print(f"   ✅ Amount: ₦{response.get('amount', 'N/A')}")
            print(f"   ✅ Reference: {response.get('reference', 'N/A')}")
            return True
        return False

    def test_payment_initialization_pro(self):
        """Test payment initialization for Pro tier"""
        test_data = {
            "tier": "pro",
            "mechanic_id": "demo-mechanic-123"
        }
        
        success, response = self.run_test(
            "Payment Initialization (Pro)",
            "POST",
            "/payments/initialize",
            200,
            data=test_data
        )
        
        if success and 'authorization_url' in response:
            print(f"   ✅ Paystack URL generated successfully")
            print(f"   ✅ Amount: ₦{response.get('amount', 'N/A')}")
            return True
        return False

    def test_payment_initialization_invalid_tier(self):
        """Test payment initialization with invalid tier"""
        test_data = {
            "tier": "invalid_tier",
            "mechanic_id": "demo-mechanic-123"
        }
        
        return self.run_test(
            "Payment Initialization (Invalid Tier)",
            "POST",
            "/payments/initialize",
            400,
            data=test_data
        )

    def test_payment_initialization_invalid_mechanic(self):
        """Test payment initialization with invalid mechanic"""
        test_data = {
            "tier": "premium",
            "mechanic_id": "invalid-mechanic-id"
        }
        
        return self.run_test(
            "Payment Initialization (Invalid Mechanic)",
            "POST",
            "/payments/initialize",
            404,
            data=test_data
        )

    def test_analytics_overview(self):
        """Test analytics overview"""
        success, response = self.run_test(
            "Analytics Overview",
            "GET",
            "/data/analytics/overview",
            200
        )
        
        if success and 'summary' in response:
            summary = response['summary']
            print(f"   ✅ Total mechanics: {summary.get('total_mechanics', 0)}")
            print(f"   ✅ Total customers: {summary.get('total_customers', 0)}")
            print(f"   ✅ Total service requests: {summary.get('total_service_requests', 0)}")
            return True
        return False

    def test_revenue_overview(self):
        """Test revenue overview"""
        success, response = self.run_test(
            "Revenue Overview",
            "GET",
            "/data/revenue/overview",
            200
        )
        
        if success and 'total_annual_revenue' in response:
            print(f"   ✅ Total annual revenue: ₦{response.get('total_annual_revenue', 0)}")
            print(f"   ✅ Active subscriptions: {response.get('active_subscriptions', 0)}")
            return True
        return False

    def test_mechanics_export(self):
        """Test mechanics data export"""
        success, response = self.run_test(
            "Mechanics Data Export",
            "GET",
            "/data/mechanics/export",
            200
        )
        
        if success and 'data' in response:
            print(f"   ✅ Exported {response.get('total_records', 0)} mechanic records")
            return True
        return False

def main():
    print("🚀 Starting Payment System & Analytics Tests")
    print("=" * 60)
    
    tester = PaymentSystemTester()
    
    # Test sequence focusing on payment system
    tests = [
        ("Tier Pricing", tester.test_tier_pricing),
        ("Payment Init (Premium)", tester.test_payment_initialization_premium),
        ("Payment Init (Pro)", tester.test_payment_initialization_pro),
        ("Payment Init (Invalid Tier)", tester.test_payment_initialization_invalid_tier),
        ("Payment Init (Invalid Mechanic)", tester.test_payment_initialization_invalid_mechanic),
        ("Analytics Overview", tester.test_analytics_overview),
        ("Revenue Overview", tester.test_revenue_overview),
        ("Mechanics Export", tester.test_mechanics_export),
    ]
    
    # Run all tests
    for test_name, test_func in tests:
        try:
            test_func()
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {str(e)}")
    
    # Print final results
    print("\n" + "=" * 60)
    print(f"📊 PAYMENT SYSTEM TEST RESULTS")
    print(f"Tests Run: {tester.tests_run}")
    print(f"Tests Passed: {tester.tests_passed}")
    print(f"Tests Failed: {tester.tests_run - tester.tests_passed}")
    print(f"Success Rate: {(tester.tests_passed/tester.tests_run)*100:.1f}%")
    
    if tester.tests_passed == tester.tests_run:
        print("🎉 All payment system tests passed!")
        return 0
    else:
        print("⚠️  Some payment tests failed. Check the details above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())