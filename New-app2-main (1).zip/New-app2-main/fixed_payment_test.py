import requests
import sys
import json
from datetime import datetime

class FixedPaymentTester:
    def __init__(self, base_url="https://fixmeapp.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.tests_run = 0
        self.tests_passed = 0
        self.mechanic_token = None
        self.mechanic_user_id = None
        self.mechanic_profile_id = None

    def run_test(self, name, method, endpoint, expected_status, data=None):
        """Run a single API test"""
        url = f"{self.api_url}{endpoint}"
        headers = {'Content-Type': 'application/json'}

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=15)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=15)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    return True, response_data
                except:
                    return True, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {json.dumps(error_data, indent=2)}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_mechanic_registration(self):
        """Register a new mechanic"""
        timestamp = datetime.now().strftime('%H%M%S')
        test_data = {
            "name": f"Test Mechanic {timestamp}",
            "email": f"testmechanic{timestamp}@gmail.com",
            "phone": "+234-808-765-4321",
            "password": "MechanicTest456",
            "role": "mechanic"
        }
        
        success, response = self.run_test(
            "Mechanic Registration",
            "POST",
            "/auth/register",
            200,
            data=test_data
        )
        
        if success and 'token' in response:
            self.mechanic_token = response['token']
            self.mechanic_user_id = response['user']['id']
            print(f"   ✅ Mechanic registered with user ID: {self.mechanic_user_id}")
            return True
        return False

    def test_mechanic_profile_creation(self):
        """Create mechanic profile"""
        if not self.mechanic_user_id:
            print("   ❌ No mechanic user ID available")
            return False
            
        test_data = {
            "business_name": "Test Auto Services",
            "description": "Professional automotive repair services",
            "location": {
                "address": "Lagos, Nigeria",
                "latitude": 6.5244,
                "longitude": 3.3792,
                "state": "Lagos",
                "lga": "Lagos Island"
            },
            "services": ["Engine Repair", "Brake Service", "Oil Change"],
            "contact_info": {
                "phone": "+234-808-765-4321",
                "email": "testmechanic@gmail.com"
            },
            "years_experience": 5
        }
        
        success, response = self.run_test(
            "Mechanic Profile Creation",
            "POST",
            f"/mechanics/profile?user_id={self.mechanic_user_id}",
            200,
            data=test_data
        )
        
        if success and 'profile' in response:
            self.mechanic_profile_id = response['profile']['id']
            print(f"   ✅ Mechanic profile created with ID: {self.mechanic_profile_id}")
            return True
        return False

    def test_payment_initialization_premium(self):
        """Test payment initialization for Premium tier with correct profile ID"""
        if not self.mechanic_profile_id:
            print("   ❌ No mechanic profile ID available")
            return False
            
        test_data = {
            "tier": "premium",
            "mechanic_id": self.mechanic_profile_id  # Use profile ID, not user ID
        }
        
        success, response = self.run_test(
            "Payment Initialization (Premium)",
            "POST",
            "/payments/initialize",
            200,
            data=test_data
        )
        
        if success and 'authorization_url' in response:
            print(f"   ✅ Paystack URL generated successfully")
            print(f"   ✅ Amount: ₦{response.get('amount', 'N/A')}")
            print(f"   ✅ Reference: {response.get('reference', 'N/A')}")
            print(f"   ✅ URL: {response['authorization_url'][:80]}...")
            
            # Verify it's a real Paystack URL
            if 'paystack.co' in response['authorization_url']:
                print(f"   ✅ Valid Paystack URL confirmed")
            return True
        return False

    def test_payment_initialization_pro(self):
        """Test payment initialization for Pro tier"""
        if not self.mechanic_profile_id:
            print("   ❌ No mechanic profile ID available")
            return False
            
        test_data = {
            "tier": "pro",
            "mechanic_id": self.mechanic_profile_id
        }
        
        success, response = self.run_test(
            "Payment Initialization (Pro)",
            "POST",
            "/payments/initialize",
            200,
            data=test_data
        )
        
        if success and 'authorization_url' in response:
            print(f"   ✅ Paystack URL generated successfully")
            print(f"   ✅ Amount: ₦{response.get('amount', 'N/A')}")
            print(f"   ✅ Reference: {response.get('reference', 'N/A')}")
            
            # Verify it's a real Paystack URL
            if 'paystack.co' in response['authorization_url']:
                print(f"   ✅ Valid Paystack URL confirmed")
            return True
        return False

    def test_service_request_creation(self):
        """Test creating a service request with correct mechanic profile ID"""
        if not self.mechanic_profile_id:
            print("   ❌ No mechanic profile ID available")
            return False
            
        test_data = {
            "mechanic_id": self.mechanic_profile_id,
            "service_type": "Engine Repair",
            "description": "My car engine is making strange noises",
            "location": {
                "address": "Victoria Island, Lagos",
                "latitude": 6.4281,
                "longitude": 3.4219,
                "state": "Lagos",
                "lga": "Lagos Island"
            }
        }
        
        success, response = self.run_test(
            "Service Request Creation",
            "POST",
            "/service-requests",
            200,
            data=test_data
        )
        
        if success:
            print(f"   ✅ Service request created successfully")
            return True
        return False

def main():
    print("🚀 Testing Payment System with Correct IDs")
    print("=" * 60)
    
    tester = FixedPaymentTester()
    
    # Test sequence
    tests = [
        ("1. Mechanic Registration", tester.test_mechanic_registration),
        ("2. Mechanic Profile Creation", tester.test_mechanic_profile_creation),
        ("3. Service Request Creation", tester.test_service_request_creation),
        ("4. Payment Init (Premium)", tester.test_payment_initialization_premium),
        ("5. Payment Init (Pro)", tester.test_payment_initialization_pro),
    ]
    
    # Run all tests
    for test_name, test_func in tests:
        try:
            result = test_func()
            if not result:
                print(f"   ⚠️  {test_name} failed")
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {str(e)}")
    
    # Print final results
    print("\n" + "=" * 60)
    print(f"📊 PAYMENT SYSTEM TEST RESULTS")
    print(f"Tests Run: {tester.tests_run}")
    print(f"Tests Passed: {tester.tests_passed}")
    print(f"Tests Failed: {tester.tests_run - tester.tests_passed}")
    print(f"Success Rate: {(tester.tests_passed/tester.tests_run)*100:.1f}%")
    
    if tester.tests_passed >= 4:
        print("🎉 Payment system is working correctly!")
        print("✅ Real Paystack integration confirmed")
        return 0
    else:
        print("⚠️  Payment system has issues")
        return 1

if __name__ == "__main__":
    sys.exit(main())