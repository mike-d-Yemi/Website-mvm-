#!/usr/bin/env python3

import requests
import json
from datetime import datetime

def test_service_request_workflow():
    """Test the specific service request workflow mentioned in the review request"""
    base_url = "https://fixmeapp.preview.emergentagent.com"
    api_url = f"{base_url}/api"
    
    print("🎯 FOCUSED SERVICE REQUEST WORKFLOW TEST")
    print("=" * 60)
    print("Testing: Service Request Creation → Admin Dashboard Visibility")
    print("User concern: 'new requests are not reflecting properly in the Admin Dashboard'")
    print()
    
    # Test 1: Service Request Creation Testing
    print("1. 🔍 SERVICE REQUEST CREATION TESTING")
    print("-" * 40)
    
    # Create multiple test requests with realistic data
    test_requests = []
    for i in range(3):
        request_data = {
            "customer_name": f"Test Customer {i+1}",
            "customer_phone": f"+234-801-555-{1000+i}",
            "customer_address": f"Test Address {i+1}, Lagos State",
            "service_type": ["Engine Repair", "Brake Service", "Oil Change"][i],
            "description": f"Service request {i+1} - testing admin dashboard visibility",
            "location": {
                "address": f"Test Address {i+1}, Lagos State",
                "latitude": 6.5244 + (i * 0.01),
                "longitude": 3.3792 + (i * 0.01),
                "state": "Lagos",
                "lga": "Lagos Island"
            }
        }
        
        print(f"   Creating request {i+1}...")
        response = requests.post(f"{api_url}/service-requests", json=request_data, timeout=10)
        
        if response.status_code == 200:
            request_id = response.json()['request']['id']
            test_requests.append({
                'id': request_id,
                'customer_name': request_data['customer_name'],
                'service_type': request_data['service_type']
            })
            print(f"   ✅ Request {i+1} created: {request_id}")
        else:
            print(f"   ❌ Request {i+1} failed: {response.status_code} - {response.text}")
            return False
    
    print(f"   ✅ All {len(test_requests)} requests created successfully")
    
    # Test 2: Service Request Retrieval Testing
    print(f"\n2. 🔍 SERVICE REQUEST RETRIEVAL TESTING")
    print("-" * 40)
    
    print("   Testing GET /api/service-requests/all...")
    response = requests.get(f"{api_url}/service-requests/all", timeout=10)
    
    if response.status_code != 200:
        print(f"   ❌ Failed to retrieve requests: {response.status_code}")
        return False
    
    all_requests = response.json().get('requests', [])
    print(f"   ✅ Retrieved {len(all_requests)} total requests from admin dashboard")
    
    # Verify our test requests appear immediately
    found_requests = []
    for test_req in test_requests:
        for admin_req in all_requests:
            if admin_req.get('id') == test_req['id']:
                found_requests.append(test_req)
                print(f"   ✅ Found request: {test_req['customer_name']} - {test_req['service_type']}")
                break
    
    if len(found_requests) == len(test_requests):
        print(f"   ✅ ALL {len(test_requests)} test requests appear immediately in admin dashboard")
    else:
        print(f"   ❌ Only {len(found_requests)}/{len(test_requests)} requests found in admin dashboard")
        return False
    
    # Test 3: Cities/States Data Testing
    print(f"\n3. 🔍 CITIES/STATES DATA TESTING")
    print("-" * 40)
    
    print("   Testing GET /api/cities...")
    response = requests.get(f"{api_url}/cities", timeout=10)
    
    if response.status_code != 200:
        print(f"   ❌ Failed to get cities data: {response.status_code}")
        return False
    
    cities_data = response.json().get('cities_by_state', [])
    print(f"   ✅ Cities data loaded: {len(cities_data)} states")
    
    # Verify key states are present
    states_dict = {state['state']: state['cities'] for state in cities_data}
    key_states = ['Lagos', 'FCT', 'Rivers', 'Kano']
    
    for state in key_states:
        if state in states_dict:
            cities_count = len(states_dict[state])
            print(f"   ✅ {state}: {cities_count} cities")
        else:
            print(f"   ❌ {state}: Not found")
            return False
    
    # Test 4: End-to-End Request Flow
    print(f"\n4. 🔍 END-TO-END REQUEST FLOW")
    print("-" * 40)
    
    # Use the first test request for end-to-end testing
    test_request = test_requests[0]
    request_id = test_request['id']
    
    print(f"   Using request: {request_id}")
    
    # Find a mechanic for assignment
    print("   Finding mechanic for assignment...")
    response = requests.get(f"{api_url}/mechanics/search?latitude=6.5244&longitude=3.3792&radius=100", timeout=10)
    
    if response.status_code != 200:
        print(f"   ❌ Failed to find mechanics: {response.status_code}")
        return False
    
    mechanics = response.json().get('mechanics', [])
    if not mechanics:
        print("   ❌ No mechanics available")
        return False
    
    mechanic = mechanics[0]
    mechanic_id = mechanic['id']
    mechanic_name = mechanic.get('business_name', 'Unknown')
    print(f"   ✅ Selected mechanic: {mechanic_name}")
    
    # Assign request to mechanic
    print("   Assigning request to mechanic...")
    assignment_data = {"mechanic_id": mechanic_id}
    response = requests.put(f"{api_url}/service-requests/{request_id}/assign-mechanic", json=assignment_data, timeout=10)
    
    if response.status_code != 200:
        print(f"   ❌ Assignment failed: {response.status_code} - {response.text}")
        return False
    
    print(f"   ✅ Request assigned successfully")
    
    # Verify assignment appears immediately in admin dashboard
    print("   Verifying assignment in admin dashboard...")
    response = requests.get(f"{api_url}/service-requests/all", timeout=10)
    
    if response.status_code != 200:
        print(f"   ❌ Failed to check admin dashboard: {response.status_code}")
        return False
    
    admin_requests = response.json().get('requests', [])
    assigned_request = None
    for req in admin_requests:
        if req.get('id') == request_id:
            assigned_request = req
            break
    
    if assigned_request:
        status = assigned_request.get('status')
        assigned_mechanic_id = assigned_request.get('mechanic_id')
        print(f"   ✅ Assignment visible in admin dashboard")
        print(f"       - Status: {status}")
        print(f"       - Assigned to: {assigned_mechanic_id}")
        
        if status == 'assigned' and assigned_mechanic_id == mechanic_id:
            print(f"   ✅ Assignment data correct")
        else:
            print(f"   ❌ Assignment data incorrect")
            return False
    else:
        print(f"   ❌ Assigned request not found in admin dashboard")
        return False
    
    # Test 5: Verify immediate visibility (the main user concern)
    print(f"\n5. 🔍 IMMEDIATE VISIBILITY VERIFICATION")
    print("-" * 40)
    
    # Create one more request and immediately check if it appears
    final_request_data = {
        "customer_name": "Immediate Visibility Test",
        "customer_phone": "+234-801-555-9999",
        "customer_address": "Immediate Test Address, Lagos State",
        "service_type": "Emergency Roadside",
        "description": "Testing immediate visibility in admin dashboard",
        "location": {
            "address": "Immediate Test Address, Lagos State",
            "latitude": 6.5244,
            "longitude": 3.3792,
            "state": "Lagos",
            "lga": "Lagos Island"
        }
    }
    
    print("   Creating final test request...")
    response = requests.post(f"{api_url}/service-requests", json=final_request_data, timeout=10)
    
    if response.status_code != 200:
        print(f"   ❌ Failed to create final request: {response.status_code}")
        return False
    
    final_request_id = response.json()['request']['id']
    print(f"   ✅ Final request created: {final_request_id}")
    
    # Immediately check admin dashboard
    print("   Immediately checking admin dashboard...")
    response = requests.get(f"{api_url}/service-requests/all", timeout=10)
    
    if response.status_code != 200:
        print(f"   ❌ Failed to check admin dashboard: {response.status_code}")
        return False
    
    immediate_requests = response.json().get('requests', [])
    final_request_found = False
    
    for req in immediate_requests:
        if req.get('id') == final_request_id:
            final_request_found = True
            print(f"   ✅ Final request appears IMMEDIATELY in admin dashboard")
            print(f"       - Customer: {req.get('customer_name')}")
            print(f"       - Status: {req.get('status')}")
            break
    
    if not final_request_found:
        print(f"   ❌ Final request NOT found immediately in admin dashboard")
        return False
    
    # Summary
    print(f"\n🎉 WORKFLOW TEST RESULTS")
    print("=" * 60)
    print("✅ Service Request Creation: WORKING")
    print("✅ Service Request Retrieval: WORKING") 
    print("✅ Cities/States Data: WORKING")
    print("✅ End-to-End Request Flow: WORKING")
    print("✅ Immediate Visibility: WORKING")
    print()
    print("🎯 USER CONCERN RESOLUTION:")
    print("   'New requests are not reflecting properly in the Admin Dashboard'")
    print("   → RESOLVED: All requests appear immediately in admin dashboard")
    print("   → Backend APIs are fully functional")
    print("   → Issue was likely frontend-related (React Router)")
    
    return True

if __name__ == "__main__":
    success = test_service_request_workflow()
    if success:
        print(f"\n✅ ALL TESTS PASSED - Service request workflow is working correctly")
    else:
        print(f"\n❌ TESTS FAILED - Issues found in service request workflow")